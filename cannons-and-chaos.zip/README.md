# Cannons and Chaos

A complete spelljammer ship combat system module for **Foundry VTT V13** and **D&D 5e 5.2.x**.

## Contents

- **Rules PDF** — The full Cannons and Chaos rulebook, embedded as a journal entry
- **12 Pre-Built Ship Actors** — One vehicle actor per ship across all four tiers, fully configured with weapons, components, consumables, and tactical notes
- **Command Bridge Macro** — The War Helm ship combat console macro, ready to drag to your hotbar

## Installation

This is a **premium module** available for **$10** via the [LaserW1tch Patreon](https://www.patreon.com/LaserW1tch).

### Via The Forge (Import Wizard)
1. Go to `forge-vtt.com/setup` → **Summon Import Wizard**
2. Toggle **off** "Install found packages from the Bazaar"
3. Upload `cannons-and-chaos.zip`
4. Analyze and complete the import
5. Restart your Foundry server
6. Enable **Cannons and Chaos** in your world's Manage Modules settings

### Via Foundry VTT (self-hosted)
1. Extract `cannons-and-chaos.zip` into `Data/modules/` so the path reads `Data/modules/cannons-and-chaos/module.json`
2. Restart Foundry and enable the module in your world

## Usage

After enabling the module, click the **⚓ anchor icon** in the sidebar tab strip to open the Cannons and Chaos panel. From there you can:

- **Open Rules PDF** — Opens the full rulebook journal entry
- **Command Bridge** — Executes the War Helm macro (select a ship token first)
- **Import All Ships** — Imports all 12 ship actors into a "Cannons and Chaos — Ships" folder
- **Import individual ships** — Import only the ships you need

### Ship Actors

Each ship actor includes:

- Full vehicle stats (HP, AC, Damage Threshold, Speed, ability scores)
- All weapons as individual items with arc placement in the name (Fore, Port, Starboard, Stern)
- All components (Helm, Engines, Utility Modules) as equipment with their own HP and AC
- A **Performance Profile** feature showing Speed, Turn Rate, Power Points Pool, and hardpoint counts
- A **Helm Special Action** feature with the full ability description
- Four consumables: **Active Fires**, **Power Points**, **Drift Tokens (max 3)**, **Party Member Actions**
- Full tactical notes in the actor description

### Command Bridge Macro

The Command Bridge (War Helm) macro provides a full ship combat console. To use it:
1. Import the ship actor you want to run
2. Place a token for that actor on the canvas
3. Select the token
4. Execute the Command Bridge macro from your hotbar

## Compatibility

| Foundry VTT | D&D 5e System | Status |
|---|---|---|
| V13 | 5.2.x | ✅ Verified |

## License

Copyright © LaserW1tch. All Rights Reserved.

This module may not be copied, modified, redistributed, or sold without explicit written permission from the author.
