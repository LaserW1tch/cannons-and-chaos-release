# Cannons & Chaos

A Foundry VTT module for spelljammer ship combat, ship systems, and supporting gameplay tools.

## Status
Private development repository. Release packaging and marketplace prep in progress.