Hooks.once("ready", () => {
  console.log("C&C | Initializing API bootstrap");

  const root = game.cannonsAndChaos ?? (game.cannonsAndChaos = {});

  const resolveActorReference = async (reference) => {
    if (!reference) return null;
    if (reference.documentName === "Actor") return reference;
    if (typeof reference === "string") {
      const byId = game.actors?.get?.(reference);
      if (byId) return byId;
      try {
        const byUuid = await fromUuid(reference);
        if (byUuid?.documentName === "Actor") return byUuid;
      } catch (err) {
        console.warn("C&C | Failed to resolve actor reference", err);
      }
    }
    return null;
  };

  root.TreasuryAPI = {
    addTransaction: async ({ actor, actorId, actorUuid, amount = 0, source = "Manual Adjustment", type = "manual", notes = "" } = {}) => {
      const mod = await import("./helpers/derived.js");
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("TreasuryAPI.addTransaction could not resolve the target ship actor.");
      return mod.addTreasuryTransaction(resolvedActor, { amount, source, type, notes });
    },
    transferTreasuryToShip: async (sourceReference, targetReference, options = {}) => {
      const mod = await import("./helpers/derived.js");
      const sourceActor = await resolveActorReference(sourceReference);
      const targetActor = await resolveActorReference(targetReference);
      if (!sourceActor || !targetActor) throw new Error("TreasuryAPI.transferTreasuryToShip could not resolve one or both ship actors.");
      return mod.transferTreasuryToShip(sourceActor, targetActor, options);
    },
    ensureState: async (reference) => {
      const mod = await import("./helpers/derived.js");
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.ensureState could not resolve the target ship actor.");
      return mod.ensureTreasuryState(actor);
    },
    setPrimaryShip: async (reference) => {
      const mod = await import("./helpers/derived.js");
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.setPrimaryShip could not resolve the target ship actor.");
      await mod.ensureTreasuryState(actor);
      await mod.setPrimaryTreasuryShip(actor);
      return actor;
    },
    getPrimaryShipUuid: async () => {
      const mod = await import("./helpers/derived.js");
      return mod.getPrimaryTreasuryShipUuid();
    },
    getPrimaryShip: async () => {
      const mod = await import("./helpers/derived.js");
      return mod.getPrimaryTreasuryShipActor();
    }
  };

  root.SalvageAPI = {
    calculate: async ({ actor, actorId, actorUuid, rollTotal = null, source = null, notes = "" } = {}) => {
      const mod = await import("./helpers/derived.js");
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.calculate could not resolve the target ship actor.");
      return mod.calculateSalvageOutcome(resolvedActor, { rollTotal, source, notes });
    },
    salvageShip: async ({ actor, actorId, actorUuid, source = null, notes = "", createChatMessage = true, whisper = null } = {}) => {
      const mod = await import("./helpers/derived.js");
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.salvageShip could not resolve the target ship actor.");
      return mod.salvageShipToTreasury(resolvedActor, { source, notes, createChatMessage, whisper });
    },
    salvageSelectedShip: async ({ createChatMessage = true, notes = "", source = null, whisper = null } = {}) => {
      const mod = await import("./helpers/derived.js");
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one ship token to salvage.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return mod.salvageShipToTreasury(actor, { source, notes, createChatMessage, whisper });
    }
  };

  root.CharterAPI = {
    quoteForCurrentShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const mod = await import("./helpers/derived.js");
      const primary = await mod.getPrimaryTreasuryShipActor();
      if (primary) return mod.createRecoveryCharterQuote(primary, { treasuryActor: primary, createChatMessage, whisper, preferPrimary: true });
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return mod.createRecoveryCharterQuote(actor, { treasuryActor: actor, createChatMessage, whisper, preferPrimary: false });
    }
  };

  root.CharterPayoutAPI = {
    payoutSelectedShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const mod = await import("./helpers/derived.js");
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return mod.createRecoveryCharterPayoutCard(actor, { createChatMessage, whisper });
    }
  };

  root.ChopShopAPI = {
    openForCurrentShip: async () => {
      const mod = await import("./helpers/derived.js");
      const primary = await mod.getPrimaryTreasuryShipActor();
      if (primary) return mod.openChopShopForActor(primary);
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return mod.openChopShopForActor(actor);
    }
  };

  root.HullGeneratorAPI = {
    createHull: async ({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) => {
      const mod = await import("./helpers/hull-generator.js");
      return mod.createHull({ shipClass, civilianCargo, renderSheet, createChatMessage });
    },
    openDialog: async () => {
      const mod = await import("./helpers/hull-generator.js");
      return mod.openDialog();
    }
  };

  console.log("C&C | API bootstrap ready", game.cannonsAndChaos);
});
