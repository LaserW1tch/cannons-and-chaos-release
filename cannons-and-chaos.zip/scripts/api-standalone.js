
import {
  MODULE_ID,
  addTreasuryTransaction,
  calculateChopShopOutcome,
  calculateRecoveryCharterPayout,
  calculateRecoveryCharterQuote,
  calculateSalvageOutcome,
  createRecoveryCharterPayoutCard,
  createRecoveryCharterQuote,
  ensureTreasuryState,
  getChopShopComponents,
  getPrimaryTreasuryShipActor,
  getPrimaryTreasuryShipUuid,
  openChopShopForActor,
  processAllChopShopComponents,
  processChopShopComponent,
  salvageShipToTreasury,
  setPrimaryTreasuryShip,
  transferTreasuryToShip
} from "./helpers/derived.js";
import { createHull as createGeneratedHull, openDialog as openHullGeneratorDialog } from "./helpers/hull-generator.js";

function ensureApiRoot() {
  game.cannonsAndChaos ??= {};
  return game.cannonsAndChaos;
}

async function resolveActorReference(reference) {
  if (!reference) return null;
  if (reference.documentName === "Actor") return reference;
  if (typeof reference === "string") {
    const byId = game.actors?.get?.(reference);
    if (byId) return byId;
    try {
      const byUuid = await fromUuid(reference);
      if (byUuid?.documentName === "Actor") return byUuid;
    } catch (err) {
      console.warn(`${MODULE_ID} | Failed to resolve actor reference`, err);
    }
  }
  return null;
}

Hooks.once("init", () => {
  const api = ensureApiRoot();
  api.HullGeneratorAPI = {
    createHull: async ({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) =>
      createGeneratedHull({ shipClass, civilianCargo, renderSheet, createChatMessage }),
    openDialog: async () => openHullGeneratorDialog()
  };
});

Hooks.once("ready", () => {
  const api = ensureApiRoot();

  api.TreasuryAPI = {
    addTransaction: async ({ actor, actorId, actorUuid, amount = 0, source = "Manual Adjustment", type = "manual", notes = "" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("TreasuryAPI.addTransaction could not resolve the target ship actor.");
      return addTreasuryTransaction(resolvedActor, { amount, source, type, notes });
    },
    transferTreasuryToShip: async (sourceReference, targetReference, options = {}) => {
      const sourceActor = await resolveActorReference(sourceReference);
      const targetActor = await resolveActorReference(targetReference);
      if (!sourceActor || !targetActor) throw new Error("TreasuryAPI.transferTreasuryToShip could not resolve one or both ship actors.");
      return transferTreasuryToShip(sourceActor, targetActor, options);
    },
    ensureState: async (reference) => {
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.ensureState could not resolve the target ship actor.");
      return ensureTreasuryState(actor);
    },
    setPrimaryShip: async (reference) => {
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.setPrimaryShip could not resolve the target ship actor.");
      await ensureTreasuryState(actor);
      await setPrimaryTreasuryShip(actor);
      return actor;
    },
    getPrimaryShipUuid: () => getPrimaryTreasuryShipUuid(),
    getPrimaryShip: async () => getPrimaryTreasuryShipActor()
  };

  api.CharterAPI = {
    calculate: async ({ actor, actorId, actorUuid, treasuryActor = null, treasuryActorId = null, treasuryActorUuid = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterAPI.calculate could not resolve the target ship actor.");
      const resolvedTreasuryActor = await resolveActorReference(treasuryActor ?? treasuryActorUuid ?? treasuryActorId) ?? await getPrimaryTreasuryShipActor() ?? resolvedActor;
      return calculateRecoveryCharterQuote(resolvedActor, { treasuryActor: resolvedTreasuryActor });
    },
    quoteForShip: async ({ actor, actorId, actorUuid, treasuryActor = null, treasuryActorId = null, treasuryActorUuid = null, createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterAPI.quoteForShip could not resolve the target ship actor.");
      const resolvedTreasuryActor = await resolveActorReference(treasuryActor ?? treasuryActorUuid ?? treasuryActorId) ?? await getPrimaryTreasuryShipActor() ?? resolvedActor;
      return createRecoveryCharterQuote(resolvedActor, { treasuryActor: resolvedTreasuryActor, createChatMessage, whisper, preferPrimary: true });
    },
    quoteSelectedShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      const treasuryActor = await getPrimaryTreasuryShipActor() ?? actor;
      return createRecoveryCharterQuote(actor, { treasuryActor, createChatMessage, whisper, preferPrimary: true });
    },
    quoteForCurrentShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const primary = await getPrimaryTreasuryShipActor();
      if (primary) return createRecoveryCharterQuote(primary, { treasuryActor: primary, createChatMessage, whisper, preferPrimary: true });
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return createRecoveryCharterQuote(actor, { treasuryActor: actor, createChatMessage, whisper, preferPrimary: false });
    }
  };

  api.CharterPayoutAPI = {
    calculate: async ({ actor, actorId, actorUuid } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterPayoutAPI.calculate could not resolve the target ship actor.");
      return calculateRecoveryCharterPayout(resolvedActor);
    },
    payoutForShip: async ({ actor, actorId, actorUuid, createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterPayoutAPI.payoutForShip could not resolve the target ship actor.");
      return createRecoveryCharterPayoutCard(resolvedActor, { createChatMessage, whisper });
    },
    payoutSelectedShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return createRecoveryCharterPayoutCard(actor, { createChatMessage, whisper });
    }
  };

  api.SalvageAPI = {
    calculate: async ({ actor, actorId, actorUuid, rollTotal = null, source = null, notes = "" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.calculate could not resolve the target ship actor.");
      return calculateSalvageOutcome(resolvedActor, { rollTotal, source, notes });
    },
    salvageShip: async ({ actor, actorId, actorUuid, source = null, notes = "", createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.salvageShip could not resolve the target ship actor.");
      return salvageShipToTreasury(resolvedActor, { source, notes, createChatMessage, whisper });
    },
    salvageSelectedShip: async ({ createChatMessage = true, notes = "", source = null, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one ship token to salvage.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return salvageShipToTreasury(actor, { source, notes, createChatMessage, whisper });
    }
  };

  api.ChopShopAPI = {
    getCurrentShip: async () => {
      const primary = await getPrimaryTreasuryShipActor();
      if (primary) return primary;
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return actor;
    },
    calculate: async ({ actor, actorId, actorUuid, item, itemId, shopTier = "established" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.calculate could not resolve the target ship actor.");
      const resolvedItem = item ?? (itemId ? resolvedActor.items.get(itemId) : null);
      if (!resolvedItem) throw new Error("ChopShopAPI.calculate could not resolve the target component item.");
      return calculateChopShopOutcome(resolvedActor, resolvedItem, { shopTier });
    },
    getComponents: async ({ actor, actorId, actorUuid, includeDestroyed = false } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId) ?? await api.ChopShopAPI.getCurrentShip();
      return getChopShopComponents(resolvedActor, { includeDestroyed });
    },
    processComponent: async ({ actor, actorId, actorUuid, item, itemId, shopTier = "established", createChatMessage = true } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.processComponent could not resolve the target ship actor.");
      const resolvedItem = item ?? (itemId ? resolvedActor.items.get(itemId) : null);
      if (!resolvedItem) throw new Error("ChopShopAPI.processComponent could not resolve the target component item.");
      return processChopShopComponent(resolvedActor, resolvedItem, { shopTier, createChatMessage });
    },
    processAll: async ({ actor, actorId, actorUuid, shopTier = "established", createChatMessage = true } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.processAll could not resolve the target ship actor.");
      return processAllChopShopComponents(resolvedActor, { shopTier, createChatMessage });
    },
    openForShip: async ({ actor, actorId, actorUuid } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.openForShip could not resolve the target ship actor.");
      return openChopShopForActor(resolvedActor);
    },
    openForCurrentShip: async () => {
      const actor = await api.ChopShopAPI.getCurrentShip();
      return openChopShopForActor(actor);
    }
  };

  api.HullGeneratorAPI = {
    createHull: async ({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) =>
      createGeneratedHull({ shipClass, civilianCargo, renderSheet, createChatMessage }),
    openDialog: async () => openHullGeneratorDialog()
  };

  console.log(`${MODULE_ID} | API registered`, Object.keys(api));
});
