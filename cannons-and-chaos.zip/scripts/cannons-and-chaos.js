/**
 * cannons-and-chaos.js
 * Main module script for Cannons and Chaos.
 * Handles: sidebar button, journal/macro setup, ship import UI, crew NPC import UI, component item import UI.
 *
 * Folder structure in Actors tab:
 *   Cannons and Chaos - Ships        (purple)
 *   Cannons and Chaos - Crews        (purple)
 *     └─ Crew — Shrike
 *     └─ Crew — Stonewall
 *     └─ Crew — Windcutter
 *     └─ ... (one subfolder per ship, 12 total)
 */

const MODULE_ID = "cannons-and-chaos";
const PURPLE    = "#6B21A8";

const SHIP_TIERS = [
  { label: "Tier I — Civilian Vessels", flag: "shipTierFolder_1", ships: ["Shrike", "Stonewall", "Windcutter"] },
  { label: "Tier II — Frigates",         flag: "shipTierFolder_2", ships: ["Cinderline", "Ironclasp", "Blackhook"] },
  { label: "Tier III — Cruisers",        flag: "shipTierFolder_3", ships: ["Nullpoint", "Shearpoint", "Cascade"] },
  { label: "Tier IV — Dreadnoughts",     flag: "shipTierFolder_4", ships: ["Exotherm", "Ablation", "Iron Mausoleum"] },
];

// Flat list derived from tiers — used wherever we just need all ship names
const SHIP_NAMES = SHIP_TIERS.flatMap(t => t.ships);

const ROLES = ["Captain", "Helm Officer", "Engineer", "Navigator", "Gunner"];


function cncGetShipTierByName(name) {
  const shipName = String(name ?? "").trim();
  const entry = SHIP_TIERS.find(t => t.ships.includes(shipName));
  return entry ? (SHIP_TIERS.indexOf(entry) + 1) : null;
}

function cncCollectTierViolations(classifiedItems, shipTier, caps = {}) {
  const violations = [];
  const weaponCap = Math.min(Number(caps.maxWeaponTier || shipTier || 0) || 0, Number(shipTier || 0) || 0) || Number(shipTier || 0) || 0;
  const utilityCap = Math.min(Number(caps.maxUtilityTier || shipTier || 0) || 0, Number(shipTier || 0) || 0) || Number(shipTier || 0) || 0;
  for (const entry of classifiedItems) {
    const t = Number(entry?.tier ?? 0) || 0;
    const ct = entry?.componentType ?? null;
    if (!ct || !t || !shipTier) continue;
    if (ct === "helm" && t > shipTier) violations.push(`${entry.item?.name ?? "Unknown"} (helm T${t} on ship T${shipTier})`);
    if (ct === "powerCore" && t > shipTier) violations.push(`${entry.item?.name ?? "Unknown"} (power core T${t} on ship T${shipTier})`);
    if (ct === "weapon" && weaponCap > 0 && t > weaponCap) violations.push(`${entry.item?.name ?? "Unknown"} (weapon T${t} above cap T${weaponCap})`);
    if (ct === "utility" && utilityCap > 0 && t > utilityCap) violations.push(`${entry.item?.name ?? "Unknown"} (utility T${t} above cap T${utilityCap})`);
  }
  return violations;
}

const ITEM_CATEGORIES = [
  {
    "label": "Helms",
    "flag": "itemFolder_helms",
    "items": [
      {
        "name": "Combat-Hardened Helm Enhancement",
        "file": "combat-hardened-helm-enhancement-t2.json"
      },
      {
        "name": "Corderian Labs Pinnacle MK I",
        "file": "corderian-labs-pinnacle-mk-i-t1.json"
      },
      {
        "name": "Gravemind Siege Helm MK XXXI",
        "file": "gravemind-siege-helm-mk-xxxi-t4.json"
      },
      {
        "name": "Irongrasp Helm MK XXIX",
        "file": "irongrasp-helm-mk-xxix-t4.json"
      },
      {
        "name": "Ixion Zephyr MK XII",
        "file": "ixion-zephyr-mk-xii-t3.json"
      },
      {
        "name": "Nexxyr MK IV",
        "file": "nexxyr-mk-iv-t2.json"
      },
      {
        "name": "Viatrax Tradehelm MK I",
        "file": "viatrax-tradehelm-mk-i-t1.json"
      }
    ]
  },
  {
    "label": "Power Cores",
    "flag": "itemFolder_power_cores",
    "items": [
      {
        "name": "Auxiliary Power Core",
        "file": "auxiliary-power-core-t2.json"
      },
      {
        "name": "Blue Power Core Faceted",
        "file": "blue-power-core-faceted-t3.json"
      },
      {
        "name": "Blue Power Core Unfaceted",
        "file": "blue-power-core-unfaceted-t3.json"
      },
      {
        "name": "Green Power Core Faceted",
        "file": "green-power-core-faceted-t2.json"
      },
      {
        "name": "Green Power Core Unfaceted",
        "file": "green-power-core-unfaceted-t2.json"
      },
      {
        "name": "Orange Power Core Faceted",
        "file": "orange-power-core-faceted-t1.json"
      },
      {
        "name": "Orange Power Core Unfaceted",
        "file": "orange-power-core-unfaceted-t1.json"
      },
      {
        "name": "Violet Power Core Faceted",
        "file": "violet-power-core-faceted-t4.json"
      },
      {
        "name": "Violet Power Core Unfaceted",
        "file": "violet-power-core-unfaceted-t4.json"
      }
    ]
  },
  {
    "label": "Engines",
    "flag": "itemFolder_engines",
    "items": [
      {
        "name": "Arcane Jet",
        "file": "arcane-jet.json"
      },
      {
        "name": "Arcane Sails",
        "file": "arcane-sails.json"
      },
      {
        "name": "Arcane Thruster",
        "file": "arcane-thruster.json"
      },
      {
        "name": "Chrono-Stabilization Engine",
        "file": "chrono-stabilization-engine-t4.json"
      },
      {
        "name": "Propeller Engine",
        "file": "propeller-engine.json"
      }
    ]
  },
  {
    "label": "Utilities",
    "flag": "itemFolder_utilities",
    "items": [
      {
        "name": "Adamantine Ramming Prow",
        "file": "adamantine-ramming-prow-t3.json"
      },
      {
        "name": "Aegis Harmonic Barrier Lattice",
        "file": "aegis-harmonic-barrier-lattice-t4.json"
      },
      {
        "name": "Aetherex MK I",
        "file": "aetherex-mk-i-t1.json"
      },
      {
        "name": "Arcane Capacitor Bank (overloaded)",
        "file": "arcane-capacitor-bank-overloaded-t4.json"
      },
      {
        "name": "Arcane Shield Projector",
        "file": "arcane-shield-projector-t3.json"
      },
      {
        "name": "Arcanomech Fire Suppression Matrix",
        "file": "arcanomech-fire-suppression-matrix-t1.json"
      },
      {
        "name": "Arcanomech Repair Matrix",
        "file": "arcanomech-repair-matrix-t1.json"
      },
      {
        "name": "Arcanomech Targeting Matrix +1",
        "file": "arcanomech-targeting-matrix-plus-1-t1.json"
      },
      {
        "name": "Arcanomech Targeting Matrix +2",
        "file": "arcanomech-targeting-matrix-plus-2-t2.json"
      },
      {
        "name": "Arcanomech Targeting Matrix +3",
        "file": "arcanomech-targeting-matrix-plus-3-t4.json"
      },
      {
        "name": "Boarding Defense Grid",
        "file": "boarding-defense-grid-t2.json"
      },
      {
        "name": "Dimensional Anchor Array",
        "file": "dimensional-anchor-array-t4.json"
      },
      {
        "name": "Hidden Cargo Storage",
        "file": "hidden-cargo-storage-t1.json"
      },
      {
        "name": "Improved Rudder Array",
        "file": "improved-rudder-array-t2.json"
      },
      {
        "name": "Ixion Assault Rig v3.01.157",
        "file": "ixion-assault-rig-v3-01-157-t2.json"
      },
      {
        "name": "Kaelithar MK XVII",
        "file": "kaelithar-mk-xvii-t3.json"
      },
      {
        "name": "Luminarch MK XXX",
        "file": "luminarch-mk-xxx-t4.json"
      },
      {
        "name": "Nexyron MK XIII",
        "file": "nexyron-mk-xiii-t3.json"
      },
      {
        "name": "Orphidrex MK XXI",
        "file": "orphidrex-mk-xxi-t3.json"
      },
      {
        "name": "Reinforced Hull Plating",
        "file": "reinforced-hull-plating-t1.json"
      },
      {
        "name": "Self-Repair Organism",
        "file": "self-repair-organism-t3.json"
      },
      {
        "name": "Serathium MK XXVIII",
        "file": "serathium-mk-xxviii-t4.json"
      },
      {
        "name": "Sironics Speedster MK II",
        "file": "sironics-speedster-mk-ii-t1.json"
      },
      {
        "name": "Verithain MK VII",
        "file": "verithain-mk-vii-t2.json"
      },
      {
        "name": "Virelith MK IV",
        "file": "virelith-mk-iv-t2.json"
      }
    ]
  },
  {
    "label": "Weapons",
    "flag": "itemFolder_weapons",
    "items": [
      {
        "name": "Aether Torpedo Launcher",
        "file": "aether-torpedo-launcher-t4.json"
      },
      {
        "name": "Aetheric Lance",
        "file": "aetheric-lance-t3.json"
      },
      {
        "name": "Arcane Flak Array",
        "file": "arcane-flak-array-t3.json"
      },
      {
        "name": "Ballista",
        "file": "ballista-t1.json"
      },
      {
        "name": "Dragonfire Launcher",
        "file": "dragonfire-launcher-t2.json"
      },
      {
        "name": "Graviton Mortar",
        "file": "graviton-mortar-t3.json"
      },
      {
        "name": "Heavy Cannon",
        "file": "heavy-cannon-t2.json"
      },
      {
        "name": "Hivemind Tentacles",
        "file": "hivemind-tentacles-t4.json"
      },
      {
        "name": "Hookshot Cannon",
        "file": "hookshot-cannon-t2.json"
      },
      {
        "name": "Light Ballista",
        "file": "light-ballista-t1.json"
      },
      {
        "name": "Light Cannon",
        "file": "light-cannon-t1.json"
      },
      {
        "name": "Mangonel",
        "file": "mangonel-t2.json"
      },
      {
        "name": "Prism Lance",
        "file": "prism-lance-t4.json"
      },
      {
        "name": "Radiant Spell Cannon",
        "file": "radiant-spell-cannon-t4.json"
      },
      {
        "name": "Spell Canon",
        "file": "spell-cannon-t3.json"
      },
      {
        "name": "Stormcall Harpoon",
        "file": "stormcall-harpoon-t2.json"
      },
      {
        "name": "Thunderhead Bomb Rack",
        "file": "thunderhead-bomb-rack-t4.json"
      },
      {
        "name": "Twin Spell Canon",
        "file": "twin-spell-cannon-t3.json"
      },
      {
        "name": "Void Flare Projector",
        "file": "void-flare-projector-t4.json"
      }
    ]
  }
];


function npcFilename(shipName, role) {
  return `${shipName.toLowerCase()}_${role.toLowerCase().replace(/ /g, "_")}.json`;
}

// ── SETUP ─────────────────────────────────────────────────────────────────────

Hooks.once("ready", async () => {

  if (game.user.isGM) {
    await ensureJournal();
    const legacyBridge = game.macros.find(m => m.getFlag(MODULE_ID, "commandBridge") === true);
    if (legacyBridge) {
      await legacyBridge.delete();
      console.log(`${MODULE_ID} | Removed legacy Command Bridge macro.`);
    }
    await ensureShipRootFolder();
    // Pre-create all 4 tier subfolders under Ships
    for (const tier of SHIP_TIERS) {
      await ensureShipTierFolder(tier);
    }
    await ensureCrewRootFolder();
    // Pre-create all 12 crew subfolders under Crews
    for (const name of SHIP_NAMES) {
      await ensureShipCrewFolder(name);
    }
    await ensureItemRootFolder();
    for (const category of ITEM_CATEGORIES) {
      await ensureItemCategoryFolder(category);
    }
  }

  if (!document.querySelector("#cnc-sidebar-btn")) {
    const menu = document.querySelector("#sidebar-tabs menu");
    if (menu) {
      const li = document.createElement("li");
      li.innerHTML = `
        <button type="button"
                id="cnc-sidebar-btn"
                class="ui-control plain icon fa-solid fa-anchor"
                title="Cannons and Chaos"
                aria-label="Cannons and Chaos"
                data-tooltip="Cannons and Chaos">
        </button>
      `;
      li.querySelector("button").addEventListener("click", () => openCNCPanel());
      menu.appendChild(li);
      console.log(`${MODULE_ID} | Sidebar button injected.`);
    }
  }

  if (!document.querySelector("#cnc-role-sidebar-btn")) {
    const menu = document.querySelector("#sidebar-tabs menu");
    if (menu) {
      const li = document.createElement("li");
      li.innerHTML = `
        <button type="button"
                id="cnc-role-sidebar-btn"
                class="ui-control plain icon fa-solid fa-user-gear"
                title="Ship Role Manager"
                aria-label="Ship Role Manager"
                data-tooltip="Ship Role Manager">
        </button>
      `;
      li.querySelector("button").addEventListener("click", async () => {
        await game.cannonsAndChaos?.RoleManagerAPI?.openForCurrentUser?.();
      });
      menu.appendChild(li);
      console.log(`${MODULE_ID} | Role sidebar button injected.`);
    }
  }

  game.modules.get(MODULE_ID).api = {
    openPanel:      () => openCNCPanel(),
    importShip:     (name) => importShip(name),
    importAllShips: () => importAllShips(),
    importCrew:     (shipName) => importCrew(shipName),
    importAllCrews: () => importAllCrews(),
    importItem:     (filename) => importItem(filename),
    importAllItems: () => importAllItems(),
  };

  console.log(`${MODULE_ID} | Ready.`);
});

// ── JOURNAL ───────────────────────────────────────────────────────────────────

async function ensureJournal() {
  const existing = game.journal.find(j => j.getFlag(MODULE_ID, "rules") === true);
  if (existing) return;
  try {
    const response = await fetch(`modules/${MODULE_ID}/packs/journal/rules.json`);
    const data = await response.json();
    const journal = await JournalEntry.create({
      name:      data.name,
      ownership: { default: 2 },
      pages:     data.pages,
    });
    await journal.setFlag(MODULE_ID, "rules", true);
    console.log(`${MODULE_ID} | Rules journal created.`);
  } catch(e) {
    console.warn(`${MODULE_ID} | Could not create rules journal:`, e);
  }
}

// ── FOLDERS ───────────────────────────────────────────────────────────────────

// ── SHIP FOLDERS ──────────────────────────────────────────────────────────────

// Root folder: "Cannons and Chaos - Ships"
async function ensureShipRootFolder() {
  const existing = game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, "shipRootFolder") === true
  );
  if (existing) return existing;
  const folder = await Folder.create({
    name:  "Cannons and Chaos - Ships",
    type:  "Actor",
    color: PURPLE,
  });
  await folder.setFlag(MODULE_ID, "shipRootFolder", true);
  console.log(`${MODULE_ID} | Ship root folder created.`);
  return folder;
}

async function getShipRootFolder() {
  return game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, "shipRootFolder") === true
  );
}

// Tier subfolder: "Tier I — Civilian Vessels", etc., nested inside Ships root
async function ensureShipTierFolder(tier) {
  const existing = game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, tier.flag) === true
  );
  if (existing) return existing;
  const root = await ensureShipRootFolder();
  const folder = await Folder.create({
    name:   tier.label,
    type:   "Actor",
    color:  PURPLE,
    folder: root.id,
  });
  await folder.setFlag(MODULE_ID, tier.flag, true);
  console.log(`${MODULE_ID} | Ship tier folder created: ${tier.label}`);
  return folder;
}

async function getShipTierFolder(shipName) {
  const tier = SHIP_TIERS.find(t => t.ships.includes(shipName));
  if (!tier) return null;
  return game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, tier.flag) === true
  );
}

// The root "Cannons and Chaos - Crews" parent folder
async function ensureCrewRootFolder() {
  const existing = game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, "crewRootFolder") === true
  );
  if (existing) return existing;
  const folder = await Folder.create({
    name:  "Cannons and Chaos - Crews",
    type:  "Actor",
    color: PURPLE,
  });
  await folder.setFlag(MODULE_ID, "crewRootFolder", true);
  console.log(`${MODULE_ID} | Crew root folder created.`);
  return folder;
}

async function getCrewRootFolder() {
  return game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, "crewRootFolder") === true
  );
}

// Per-ship subfolder: "Crew — Shrike", "Crew — Ironclasp", etc.
// Parented inside the Crews root folder.
async function ensureShipCrewFolder(shipName) {
  const flagKey = `crewFolder_${shipName.toLowerCase()}`;
  const existing = game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, flagKey) === true
  );
  if (existing) return existing;

  const root = await ensureCrewRootFolder();
  const folder = await Folder.create({
    name:   `Crew — ${shipName}`,
    type:   "Actor",
    color:  PURPLE,
    folder: root.id,       // nested inside the Crews root
  });
  await folder.setFlag(MODULE_ID, flagKey, true);
  console.log(`${MODULE_ID} | Crew subfolder created: Crew — ${shipName}`);
  return folder;
}

async function getShipCrewFolder(shipName) {
  const flagKey = `crewFolder_${shipName.toLowerCase()}`;
  return game.folders.find(
    f => f.type === "Actor" && f.getFlag(MODULE_ID, flagKey) === true
  );
}


// ── ITEM FOLDERS ──────────────────────────────────────────────────────────────

async function ensureItemRootFolder() {
  const existing = game.folders.find(
    f => f.type === "Item" && f.getFlag(MODULE_ID, "itemRootFolder") === true
  );
  if (existing) return existing;
  const folder = await Folder.create({
    name:  "Cannons and Chaos - Components",
    type:  "Item",
    color: PURPLE,
  });
  await folder.setFlag(MODULE_ID, "itemRootFolder", true);
  console.log(`${MODULE_ID} | Item root folder created.`);
  return folder;
}

async function getItemRootFolder() {
  return game.folders.find(
    f => f.type === "Item" && f.getFlag(MODULE_ID, "itemRootFolder") === true
  );
}

async function ensureItemCategoryFolder(category) {
  const existing = game.folders.find(
    f => f.type === "Item" && f.getFlag(MODULE_ID, category.flag) === true
  );
  if (existing) return existing;
  const root = await ensureItemRootFolder();
  const folder = await Folder.create({
    name:   category.label,
    type:   "Item",
    color:  PURPLE,
    folder: root.id,
  });
  await folder.setFlag(MODULE_ID, category.flag, true);
  console.log(`${MODULE_ID} | Item category folder created: ${category.label}`);
  return folder;
}

function cncTierLabelFromNumber(tier) {
  const t = Number(tier);
  if (![1,2,3,4].includes(t)) return null;
  return `Tier ${["I","II","III","IV"][t-1]}`;
}

async function ensureItemTierFolder(category, tier) {
  const tierLabel = cncTierLabelFromNumber(tier);
  if (!tierLabel) return await ensureItemCategoryFolder(category);

  const parent = await ensureItemCategoryFolder(category);
  const flagKey = `${category.flag}_tier_${tier}`;
  const existing = game.folders.find(
    f => f.type === "Item" && f.folder?.id === parent.id && f.getFlag(MODULE_ID, flagKey) === true
  );
  if (existing) return existing;

  const folder = await Folder.create({
    name: tierLabel,
    type: "Item",
    color: PURPLE,
    folder: parent.id
  });
  await folder.setFlag(MODULE_ID, flagKey, true);
  console.log(`${MODULE_ID} | Item tier folder created: ${category.label} > ${tierLabel}`);
  return folder;
}

async function getItemCategoryFolderByFilename(filename, tier=null) {
  const category = ITEM_CATEGORIES.find(cat => cat.items.some(i => i.file === filename));
  if (!category) return null;
  if (tier != null) return await ensureItemTierFolder(category, tier);
  return game.folders.find(
    f => f.type === "Item" && f.getFlag(MODULE_ID, category.flag) === true
  ) || await ensureItemCategoryFolder(category);
}

function cncCategoryForComponentType(componentType) {
  return ITEM_CATEGORIES.find(cat => {
    if (componentType === "helm") return cat.flag === "itemFolder_helms";
    if (componentType === "powerCore") return cat.flag === "itemFolder_power_cores";
    if (componentType === "engine") return cat.flag === "itemFolder_engines";
    if (componentType === "utility") return cat.flag === "itemFolder_utilities";
    if (componentType === "weapon") return cat.flag === "itemFolder_weapons";
    return false;
  }) ?? null;
}

async function getItemCategoryFolderByComponentType(componentType, tier=null) {
  const category = cncCategoryForComponentType(componentType);
  if (!category) return null;
  if (tier != null) return await ensureItemTierFolder(category, tier);
  return game.folders.find(
    f => f.type === "Item" && f.getFlag(MODULE_ID, category.flag) === true
  ) || await ensureItemCategoryFolder(category);
}


// ── C&C NORMALIZATION / TAGGING ──────────────────────────────────────────────

const CNC_SCHEMA_VERSION = 1;

function cncStripHtml(html) {
  return String(html ?? "")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function cncGetDescription(item) {
  return item?.system?.description?.value ?? item?.system?.description ?? item?.description ?? "";
}

function cncMatchNumber(text, patterns) {
  const source = String(text ?? "");
  for (const rx of patterns) {
    const m = source.match(rx);
    if (m) return Number(String(m[1]).replace(/,/g, ""));
  }
  return null;
}

function cncMatchText(text, patterns) {
  const source = String(text ?? "");
  for (const rx of patterns) {
    const m = source.match(rx);
    if (m) return m[1].trim();
  }
  return null;
}

function cncRomanToInt(value) {
  const raw = String(value ?? "").trim().toUpperCase();
  if (!raw) return null;
  if (/^\d+$/.test(raw)) return Number(raw);
  const map = { I: 1, V: 5, X: 10 };
  let total = 0, prev = 0;
  for (let i = raw.length - 1; i >= 0; i--) {
    const curr = map[raw[i]] ?? 0;
    if (!curr) return null;
    if (curr < prev) total -= curr;
    else total += curr;
    prev = curr;
  }
  return total || null;
}

function cncFindPerformanceProfileItem(items) {
  const scored = (items ?? [])
    .map(item => {
      const name = String(item?.name ?? "").toLowerCase().trim();
      const type = String(item?.type ?? "").toLowerCase();
      let score = 0;

      if (name === "flight performance profile") score = 100;
      else if (/flight\s+performance\s+profile/.test(name)) score = 95;
      else if (name.includes("performance profile")) score = 90;
      else if (name.includes("flight profile")) score = 85;
      else if (name.includes("ship performance profile")) score = 82;
      else if (name.includes("ship profile")) score = 75;
      else if (name.includes("performance") && name.includes("profile")) score = 70;
      else if (name.includes("flight") && name.includes("profile")) score = 65;
      else if (name.includes("profile")) score = 40;

      if (score > 0 && (type === "feat" || type === "equipment")) score += 5;
      return { item, score };
    })
    .filter(entry => entry.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored[0]?.item ?? null;
}

function cncExtractFromPerformanceProfile(text) {
  const result = {};
  result.speedHex = cncMatchNumber(text, [
    /speed\s*[:\-]?\s*(\d+)\s*hex/i,
    /speed\s*[:\-]?\s*(\d+)\s*hexes/i
  ]);
  result.turnRate = cncMatchNumber(text, [
    /turn\s*rate\s*[:\-]?\s*(\d+)/i,
    /turning\s*rate\s*[:\-]?\s*(\d+)/i
  ]);
  result.weaponHardpointsMax = cncMatchNumber(text, [
    /weapon\s*mounts?\s*[:\-]?\s*(\d+)/i,
    /weapon\s*hardpoints?\s*[:\-]?\s*(\d+)/i
  ]);
  result.utilityHardpointsMax = cncMatchNumber(text, [
    /utility\s*mounts?\s*[:\-]?\s*(\d+)/i,
    /utility\s*hardpoints?\s*[:\-]?\s*(\d+)/i
  ]);
  result.engineMounts = cncMatchNumber(text, [
    /engine\s*mounts?\s*[:\-]?\s*(\d+)/i,
    /engine\s*hardpoints?\s*[:\-]?\s*(\d+)/i
  ]);
  result.maxWeaponTier = cncMatchNumber(text, [
    /weapon\s*mounts?\s*:\s*\d+\s*\(max\s*tier\s*([ivx\d]+)\)/i,
    /max\s*weapon\s*tier\s*[:\-]?\s*([ivx\d]+)/i
  ].map(rx => new RegExp(rx.source, rx.flags)));
  result.maxUtilityTier = cncMatchNumber(text, [
    /utility\s*mounts?\s*:\s*\d+\s*\(max\s*tier\s*([ivx\d]+)\)/i,
    /max\s*utility\s*tier\s*[:\-]?\s*([ivx\d]+)/i
  ].map(rx => new RegExp(rx.source, rx.flags)));
  result.cargoMaxTons = cncMatchNumber(text, [
    /cargo\s*[:\-]?\s*(\d+)\s*tons?/i,
    /cargo(?:\s+capacity)?\s*[:\-]?\s*(\d+)\s*tons?/i
  ]);
  return result;
}

function cncParseTier(item, componentType, sourceFilename=null) {
  const name = String(item?.name ?? "");
  const desc = cncStripHtml(cncGetDescription(item));

  // First choice: the packaged source filename is authoritative for tiered components.
  if (sourceFilename) {
    let m = String(sourceFilename).match(/-t(\d+)\.json$/i);
    if (m) return Number(m[1]);
  }

  // Explicit utility suffixes / explicit Tier labels in name or description.
  let m = name.match(/\(T\s*(\d+)\s+Utility\)$/i);
  if (m) return Number(m[1]);

  m = name.match(/Tier\s*([IVX\d]+)/i) || desc.match(/Tier\s*[:\-]?\s*([IVX\d]+)/i);
  if (m) return cncRomanToInt(m[1]);

  // For helms, MK numerals are model numbers, not ship tiers, so we do NOT use them for tier parsing.
  return null;
}

function cncParsePowerCost(item) {
  const text = cncStripHtml(cncGetDescription(item));
  return cncMatchNumber(text, [
    /power\s*cost\s*[:\-]?\s*(\d+)/i,
    /cost\s*[:\-]?\s*(\d+)\s*power/i,
    /cost\s*[:\-]?\s*(\d+)\s*pp/i
  ]);
}

function cncParseMountIndex(item) {
  const name = String(item?.name ?? "");
  const m = name.match(/\s-\s*Mount\s+(\d+)$/i);
  return m ? Number(m[1]) : null;
}

function cncParseArc(item) {
  const name = String(item?.name ?? "");
  const m = name.match(/\(([^)]+)\)$/);
  return m ? m[1] : null;
}

function cncClassifyItem(item, sourceFilename=null) {
  const type = String(item?.type ?? "").toLowerCase();
  const rawName = String(item?.name ?? "").trim();
  const name = rawName.toLowerCase();
  const desc = cncStripHtml(cncGetDescription(item)).toLowerCase();

  // --- HARD OVERRIDES ---
  if (/combat-hardened helm enhancement/i.test(rawName)) return "utility";
  if (/auxiliary power core/i.test(rawName)) return "utility";
  if (/chrono-stabilization engine/i.test(rawName)) return "utility";
  if (/ship analysis grid/i.test(rawName)) return "utility";
  if (/luminarch mk xxx/i.test(rawName)) return "helm";

  if (type === "weapon") return "weapon";
  if (cncFindPerformanceProfileItem([item])) return "profile";

  if (/power\s*core|powercore/i.test(rawName) || /power\s*core|powercore/i.test(desc)) return "powerCore";

  if (/^(arcane jet|arcane thruster|arcane sails|propeller engine)$/i.test(rawName)) return "engine";
  if (/chrono-stabilization engine/i.test(rawName)) return "engine";
  if (/\s-\s*mount\s+\d+$/i.test(rawName)) return "engine";

  const hasHelmName = /(^|\b)(helm|tradehelm)([:\s-]|$)/i.test(rawName);
  const looksLikeMkHullController = /(\bMK\s*[IVX\d]+\b|\bv\d+(?:\.\d+)+\b)/i.test(rawName);
  const hasSpecialAction = /special action/i.test(desc);
  const mentionsHelmOfficer = /helm officer/i.test(desc);

  if (hasHelmName || ((looksLikeMkHullController || mentionsHelmOfficer) && hasSpecialAction)) return "helm";

  if (type === "equipment" || type === "feat" || type === "loot" || type === "consumable" || type === "tool") {
    return "utility";
  }

  return null;
}

function cncInferClassFromStats({ ac, hp, dt, str, dex, con, int, wis, cha }) {
  const classes = [
    { name: "Civilian Vessel", tier: 1, ac: [12,14], hp: [250,300], dt: [10,12], abilities: { str:[8,12], dex:[14,16], con:[8,12], int:[8,12], wis:[10,14], cha:[8,12] } },
    { name: "Frigate", tier: 2, ac: [14,16], hp: [300,500], dt: [12,14], abilities: { str:[12,16], dex:[18,20], con:[12,16], int:[10,14], wis:[12,16], cha:[10,14] } },
    { name: "Cruiser", tier: 3, ac: [16,18], hp: [500,700], dt: [14,16], abilities: { str:[16,20], dex:[22,24], con:[16,20], int:[14,18], wis:[14,18], cha:[12,16] } },
    { name: "Dreadnought", tier: 4, ac: [18,22], hp: [700,1500], dt: [16,20], abilities: { str:[20,24], dex:[26,28], con:[20,24], int:[16,20], wis:[16,20], cha:[14,18] } }
  ];

  function inRange(v, range) { return v != null && v >= range[0] && v <= range[1]; }

  const scored = classes.map(cls => {
    let score = 0;
    if (inRange(ac, cls.ac)) score += 2;
    if (inRange(hp, cls.hp)) score += 2;
    if (inRange(dt, cls.dt)) score += 2;
    for (const [k, range] of Object.entries(cls.abilities)) {
      const val = { str, dex, con, int, wis, cha }[k];
      if (inRange(val, range)) score += 1;
    }
    return { ...cls, score };
  }).sort((a,b)=>b.score-a.score);

  return scored[0]?.score > 0 ? { name: scored[0].name, tier: scored[0].tier } : { name: null, tier: null };
}

function cncNormalizeImportedShip(data) {
  data.flags ??= {};
  data.flags[MODULE_ID] ??= {};
  data.flags[MODULE_ID].ship = true;
  data.flags[MODULE_ID].schemaVersion = CNC_SCHEMA_VERSION;

  const items = Array.isArray(data.items) ? data.items : [];
  const perfItem = cncFindPerformanceProfileItem(items);
  const perfText = cncStripHtml(cncGetDescription(perfItem));
  const perf = perfItem ? cncExtractFromPerformanceProfile(perfText) : {};

  const classifiedItems = items.map(item => {
    item.flags ??= {};
    item.flags[MODULE_ID] ??= {};

    const existingFlags = item?.flags?.[MODULE_ID] ?? {};
    const componentType = existingFlags.componentType ?? cncClassifyItem(item);
    const tier = existingFlags.tier ?? cncParseTier(item, componentType);
    const mountIndex = existingFlags.mountIndex ?? cncParseMountIndex(item);
    const arc = existingFlags.arc ?? (componentType === "weapon" ? cncParseArc(item) : null);
    const powerCost = existingFlags.powerCost ?? cncParsePowerCost(item);

    cncInjectTierIntoDescription(item, tier, componentType);

    const costShards = existingFlags.costShards ?? cncResolveComponentCostShards(item);

    item.flags[MODULE_ID] = {
      ...item.flags[MODULE_ID],
      componentType,
      tier,
      mountIndex,
      arc,
      powerCost,
      costShards,
      installed: componentType !== "profile" && componentType !== null
    };

    return { item, componentType, tier, mountIndex, arc, powerCost, costShards };
  });

  const weapons = classifiedItems.filter(x => x.componentType === "weapon");
  const utilities = classifiedItems.filter(x => x.componentType === "utility");
  const engines = classifiedItems.filter(x => x.componentType === "engine").sort((a,b)=>(a.mountIndex ?? 999)-(b.mountIndex ?? 999));
  const helms = classifiedItems.filter(x => x.componentType === "helm");
  const powerCores = classifiedItems.filter(x => x.componentType === "powerCore");

  const system = data.system ?? {};
  const ac = system?.attributes?.ac?.flat ?? null;
  const hp = system?.attributes?.hp?.max ?? system?.attributes?.hp?.value ?? null;
  const dt = system?.attributes?.hp?.dt ?? null;

  const abilities = {
    str: system?.abilities?.str?.value ?? null,
    dex: system?.abilities?.dex?.value ?? null,
    con: system?.abilities?.con?.value ?? null,
    int: system?.abilities?.int?.value ?? null,
    wis: system?.abilities?.wis?.value ?? null,
    cha: system?.abilities?.cha?.value ?? null
  };

  const inferred = cncInferClassFromStats({ ac, hp, dt, ...abilities });

  const descText = cncStripHtml(system?.description?.value ?? system?.details?.biography?.value ?? "");
  const descTier = cncMatchText(descText, [/tier\s*([ivx\d]+)/i]);
  const descClass = cncMatchText(descText, [/tier\s*[ivx\d]+\s*(civilian|frigate|cruiser|dreadnought)/i]);

  const hullClass = (
    descClass ? (descClass.toLowerCase() === "civilian" ? "Civilian Vessel" : descClass[0].toUpperCase() + descClass.slice(1).toLowerCase()) :
    inferred.name
  );

  const tier = cncGetShipTierByName(data?.name) ?? cncRomanToInt(descTier) ?? powerCores[0]?.tier ?? inferred.tier ?? null;

  const propulsionOptions = [...new Set(engines.map(e => {
    const n = String(e.item?.name ?? "");
    if (/arcane\s+jets?/i.test(n)) return "Arcane Jet";
    if (/arcane\s+thrusters?/i.test(n)) return "Arcane Thruster";
    if (/propeller/i.test(n)) return "Propeller Engine";
    if (/arcane\s+sails?/i.test(n)) return "Arcane Sails";
    return null;
  }).filter(Boolean))];

  const hullData = {
    class: hullClass,
    tier,
    schemaVersion: CNC_SCHEMA_VERSION,
    importedBy: MODULE_ID,
    frame: {
      requiredPowerCoreTier: tier ?? powerCores[0]?.tier ?? null,
      weaponHardpoints: perf.weaponHardpointsMax ?? weapons.length,
      weaponHardpointsMax: perf.weaponHardpointsMax ?? weapons.length,
      maxWeaponTier: (() => { const inferredCap = perf.maxWeaponTier ?? (Math.max(0, ...weapons.map(w => w.tier ?? 0)) || tier || null); return tier ? Math.min(inferredCap || tier, tier) : inferredCap; })(),
      utilityHardpoints: perf.utilityHardpointsMax ?? utilities.length,
      utilityHardpointsMax: perf.utilityHardpointsMax ?? utilities.length,
      maxUtilityTier: (() => { const inferredCap = perf.maxUtilityTier ?? (Math.max(0, ...utilities.map(u => u.tier ?? 0)) || tier || null); return tier ? Math.min(inferredCap || tier, tier) : inferredCap; })(),
      engineMounts: perf.engineMounts ?? engines.length,
      propulsionOptions
    },
    stats: {
      ac,
      hp,
      damageThreshold: dt,
      turnRate: perf.turnRate ?? cncMatchNumber(String(system?.attributes?.speed?.special ?? ""), [/turn\s*rate\s*([0-9]+)/i]) ?? null,
      cargoMaxTons: perf.cargoMaxTons ?? system?.details?.weight?.value ?? system?.attributes?.capacity?.cargo?.value ?? null,
      crewRequired: system?.crew?.quantity ?? system?.crew?.max ?? null,
      passengerCapacity: system?.passengers?.quantity ?? system?.passengers?.max ?? null,
      costShards: system?.attributes?.price?.value ?? system?.details?.cost ?? null
    },
    abilities,
    installed: {
      helm: helms[0] ? { id: helms[0].item._id, name: helms[0].item.name, componentType: "helm", tier: helms[0].tier, costShards: helms[0].costShards ?? 0 } : null,
      powerCore: powerCores[0] ? { id: powerCores[0].item._id, name: powerCores[0].item.name, componentType: "powerCore", tier: powerCores[0].tier, costShards: powerCores[0].costShards ?? 0 } : null,
      engines: engines.map(e => ({ id: e.item._id, name: e.item.name, componentType: "engine", mountIndex: e.mountIndex ?? null, costShards: e.costShards ?? 0 })),
      weapons: weapons.map(w => ({ id: w.item._id, name: w.item.name, componentType: "weapon", tier: w.tier ?? null, arc: w.arc ?? null, powerCost: w.powerCost ?? null, costShards: w.costShards ?? 0 })),
      utilities: utilities.map(u => ({ id: u.item._id, name: u.item.name, componentType: "utility", tier: u.tier ?? null, powerCost: u.powerCost ?? null, costShards: u.costShards ?? 0 }))
    }
  };

  data.flags[MODULE_ID].hullData = hullData;
  return { data, hullData };
}




function classifiedItemsFromImportedData(data) {
  const items = Array.isArray(data?.items) ? data.items : [];
  return items.map(item => ({
    item,
    componentType: item?.flags?.[MODULE_ID]?.componentType ?? cncClassifyItem(item),
    tier: item?.flags?.[MODULE_ID]?.tier ?? cncParseTier(item, item?.flags?.[MODULE_ID]?.componentType ?? cncClassifyItem(item)),
    mountIndex: item?.flags?.[MODULE_ID]?.mountIndex ?? cncParseMountIndex(item),
    arc: item?.flags?.[MODULE_ID]?.arc ?? cncParseArc(item),
    powerCost: item?.flags?.[MODULE_ID]?.powerCost ?? cncParsePowerCost(item),
    costShards: item?.flags?.[MODULE_ID]?.costShards ?? cncResolveComponentCostShards(item)
  }));
}

function cncResolveComponentCostShards(data) {
  const directCandidates = [
    data?.flags?.[MODULE_ID]?.costShards,
    data?.system?.price?.value,
    data?.system?.attributes?.price?.value,
    data?.system?.details?.cost,
    data?.system?.details?.price,
    data?.system?.cost,
    data?.price
  ];

  for (const candidate of directCandidates) {
    const value = Number(candidate);
    if (Number.isFinite(value) && value > 0) return Math.round(value);
  }

  const textFields = [
    data?.system?.description?.value,
    data?.system?.description,
    data?.system?.details?.biography?.value,
    data?.system?.details?.biography,
    data?.system?.source,
    data?.system?.requirements,
    data?.system?.chatFlavor,
    data?.system?.identifier,
    data?.description
  ];

  for (const field of textFields) {
    const text = cncStripHtml(String(field ?? ''));
    if (!text) continue;

    const exactCost = text.match(/\bcost\s*[:\-]?\s*(\d[\d,]*)\s*shards?\b/i);
    if (exactCost) {
      const value = Number(String(exactCost[1]).replace(/,/g, ''));
      if (Number.isFinite(value) && value > 0) return Math.round(value);
    }

    const shardMention = text.match(/\b(\d[\d,]*)\s*shards?\b/i);
    if (shardMention) {
      const value = Number(String(shardMention[1]).replace(/,/g, ''));
      if (Number.isFinite(value) && value > 0) return Math.round(value);
    }
  }

  return 0;
}

function cncInjectTierIntoDescription(data, tier, componentType) {
  if (!tier) return data;
  if (!["weapon", "utility", "powerCore", "helm"].includes(componentType)) return data;

  const current =
    data?.system?.description?.value ??
    data?.system?.description ??
    "";

  if (/tier\s*[:\-]?\s*[ivx\d]+/i.test(String(current))) return data;

  const label = `<p><strong>Tier ${tier}</strong></p>`;
  const next = `${label}${current ?? ""}`;

  data.system ??= {};
  if (typeof data.system.description === "object" && data.system.description !== null) {
    data.system.description.value = next;
  } else {
    data.system.description = { value: next };
  }

  return data;
}

function cncNormalizeImportedItem(data, sourceFilename=null) {
  data.flags ??= {};
  data.flags[MODULE_ID] ??= {};

  const componentType = cncClassifyItem(data, sourceFilename);
  const tier = cncParseTier(data, componentType, sourceFilename);
  const mountIndex = cncParseMountIndex(data);
  const arc = componentType === "weapon" ? cncParseArc(data) : null;
  const powerCost = cncParsePowerCost(data);

  cncInjectTierIntoDescription(data, tier, componentType);

  const costShards = cncResolveComponentCostShards(data);

  data.flags[MODULE_ID] = {
    ...data.flags[MODULE_ID],
    componentType,
    tier,
    mountIndex,
    arc,
    powerCost,
    costShards,
    installed: false,
    schemaVersion: CNC_SCHEMA_VERSION
  };

  return { data, tags: data.flags[MODULE_ID] };
}



function cncBuildInstalledStateFromActorItems(actor) {
  const items = Array.from(actor?.items ?? []);
  const classified = items.map(item => {
    const componentType = item.getFlag(MODULE_ID, "componentType") ?? cncClassifyItem(item);
    const tier = item.getFlag(MODULE_ID, "tier");
    const mountIndex = item.getFlag(MODULE_ID, "mountIndex");
    const arc = item.getFlag(MODULE_ID, "arc");
    const powerCost = item.getFlag(MODULE_ID, "powerCost");
    const costShards = item.getFlag(MODULE_ID, "costShards") ?? cncResolveComponentCostShards(item.toObject ? item.toObject() : item);
    return { item, componentType, tier, mountIndex, arc, powerCost, costShards };
  });

  const helms = classified.filter(x => x.componentType === "helm");
  const powerCores = classified.filter(x => x.componentType === "powerCore");
  const engines = classified.filter(x => x.componentType === "engine").sort((a,b)=>(Number(a.mountIndex ?? 999))-(Number(b.mountIndex ?? 999)));
  const weapons = classified.filter(x => x.componentType === "weapon");
  const utilities = classified.filter(x => x.componentType === "utility");

  return {
    helm: helms[0] ? { id: helms[0].item.id, name: helms[0].item.name, componentType: "helm", tier: helms[0].tier ?? null, costShards: helms[0].costShards ?? 0 } : null,
    powerCore: powerCores[0] ? { id: powerCores[0].item.id, name: powerCores[0].item.name, componentType: "powerCore", tier: powerCores[0].tier ?? null, costShards: powerCores[0].costShards ?? 0 } : null,
    engines: engines.map(e => ({ id: e.item.id, name: e.item.name, componentType: "engine", mountIndex: e.mountIndex ?? null, costShards: e.costShards ?? 0 })),
    weapons: weapons.map(w => ({ id: w.item.id, name: w.item.name, componentType: "weapon", tier: w.tier ?? null, arc: w.arc ?? null, powerCost: w.powerCost ?? null, costShards: w.costShards ?? 0 })),
    utilities: utilities.map(u => ({ id: u.item.id, name: u.item.name, componentType: "utility", tier: u.tier ?? null, powerCost: u.powerCost ?? null, costShards: u.costShards ?? 0 }))
  };
}

async function cncApplyEmbeddedShipItemFlags(actor) {
  const updates = [];

  for (const item of Array.from(actor?.items ?? [])) {
    const componentType = item.getFlag(MODULE_ID, "componentType") ?? cncClassifyItem(item);
    const tier = item.getFlag(MODULE_ID, "tier") ?? cncParseTier(item, componentType);
    const mountIndex = item.getFlag(MODULE_ID, "mountIndex") ?? cncParseMountIndex(item);
    const arc = item.getFlag(MODULE_ID, "arc") ?? (componentType === "weapon" ? cncParseArc(item) : null);
    const powerCost = item.getFlag(MODULE_ID, "powerCost") ?? cncParsePowerCost(item);
    const costShards = item.getFlag(MODULE_ID, "costShards") ?? cncResolveComponentCostShards(item.toObject ? item.toObject() : item);
    const installed = componentType !== "profile" && componentType !== null;

    updates.push({
      _id: item.id,
      [`flags.${MODULE_ID}.componentType`]: componentType ?? null,
      [`flags.${MODULE_ID}.tier`]: tier ?? null,
      [`flags.${MODULE_ID}.mountIndex`]: mountIndex ?? null,
      [`flags.${MODULE_ID}.arc`]: arc ?? null,
      [`flags.${MODULE_ID}.powerCost`]: powerCost ?? null,
      [`flags.${MODULE_ID}.costShards`]: costShards ?? 0,
      [`flags.${MODULE_ID}.installed`]: installed,
      [`flags.${MODULE_ID}.schemaVersion`]: CNC_SCHEMA_VERSION
    });
  }

  if (updates.length) await actor.updateEmbeddedDocuments("Item", updates);

  const hullData = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "hullData") ?? {});
  hullData.installed = cncBuildInstalledStateFromActorItems(actor);
  hullData.schemaVersion = CNC_SCHEMA_VERSION;
  await actor.setFlag(MODULE_ID, "hullData", hullData);
  await actor.setFlag("world", "cannonsChaosHull", hullData);
  return hullData;
}

// ── ITEM IMPORT ───────────────────────────────────────────────────────────────

async function importItem(filename) {
  const source = ITEM_CATEGORIES.flatMap(c => c.items).find(i => i.file === filename);
  if (!source) {
    ui.notifications.warn(`Unknown component file: ${filename}`);
    return null;
  }

  try {
    const response = await fetch(`modules/${MODULE_ID}/packs/items/${filename}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();

    delete data._id;

    const normalized = cncNormalizeImportedItem(data, filename);
    const componentType = normalized.tags.componentType;
    const folder = await getItemCategoryFolderByComponentType(componentType, normalized.tags.tier) || await getItemCategoryFolderByFilename(filename, normalized.tags.tier);

    const existing = game.items.find(
      i => i.name === source.name && i.folder?.id === folder?.id
    );
    if (existing) {
      ui.notifications.info(`${source.name} is already in your Items directory.`);
      return existing;
    }

    normalized.data.folder = folder?.id ?? null;

    const item = await Item.create(normalized.data);

    await item.setFlag(MODULE_ID, "componentType", normalized.tags.componentType ?? null);
    await item.setFlag(MODULE_ID, "tier", normalized.tags.tier ?? null);
    await item.setFlag(MODULE_ID, "mountIndex", normalized.tags.mountIndex ?? null);
    await item.setFlag(MODULE_ID, "arc", normalized.tags.arc ?? null);
    await item.setFlag(MODULE_ID, "powerCost", normalized.tags.powerCost ?? null);
    await item.setFlag(MODULE_ID, "costShards", normalized.tags.costShards ?? 0);
    await item.setFlag(MODULE_ID, "installed", false);
    await item.setFlag(MODULE_ID, "schemaVersion", CNC_SCHEMA_VERSION);

    console.log(`${MODULE_ID} | Imported item: ${source.name}`, normalized.tags);
    return item;
  } catch(e) {
    ui.notifications.error(`Failed to import item ${source.name}. See console for details.`);
    console.error(`${MODULE_ID} | Item import failed for ${source.name}:`, e);
  }
}

async function importAllItems() {
  ui.notifications.info("Importing all Cannons and Chaos components — this may take a moment...");
  for (const category of ITEM_CATEGORIES) {
    for (const item of category.items) {
      await importItem(item.file);
    }
  }
  ui.notifications.info("All Cannons and Chaos components imported.");
}

// ── SHIP IMPORT ───────────────────────────────────────────────────────────────

async function importShip(name) {
  const filename = name.toLowerCase().replace(/ /g, "_");
  const folder   = await ensureShipTierFolder(SHIP_TIERS.find(t => t.ships.includes(name)));

  const existing = game.actors.find(
    a => a.name === name && a.folder?.id === folder?.id
  );
  if (existing) {
    ui.notifications.info(`${name} is already in your Actors directory.`);
    return existing;
  }

  try {
    const response = await fetch(`modules/${MODULE_ID}/packs/actors/${filename}.json`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();

    delete data._id;
    data.items?.forEach(i => delete i._id);
    data.folder = folder?.id ?? null;

    const normalized = cncNormalizeImportedShip(data);
    const importViolations = cncCollectTierViolations(classifiedItemsFromImportedData(normalized.data), normalized.hullData?.tier, normalized.hullData?.frame ?? {});
    if (importViolations.length) console.warn(`${MODULE_ID} | Tier violations found while importing ${name}:`, importViolations);
    const actor = await Actor.create(normalized.data);
    if (importViolations.length) ui.notifications.warn(`${name} imported with ${importViolations.length} tier legality warning${importViolations.length === 1 ? "" : "s"}. See console.`);

    await actor.setFlag(MODULE_ID, "ship", true);
    await actor.setFlag(MODULE_ID, "schemaVersion", CNC_SCHEMA_VERSION);
    await actor.setFlag(MODULE_ID, "hullData", normalized.hullData);

    const liveHullData = await cncApplyEmbeddedShipItemFlags(actor);

    console.log(`${MODULE_ID} | Imported ship: ${name}`, liveHullData);
    return actor;
  } catch(e) {
    ui.notifications.error(`Failed to import ship ${name}. See console for details.`);
    console.error(`${MODULE_ID} | Ship import failed for ${name}:`, e);
  }
}

async function importAllShips() {
  ui.notifications.info("Importing all ships — this may take a moment...");
  for (const name of SHIP_NAMES) {
    await importShip(name);
  }
  ui.notifications.info("All ships imported into Cannons and Chaos - Ships.");
}

// ── CREW IMPORT ───────────────────────────────────────────────────────────────

async function importCrewMember(shipName, role) {
  const fname    = npcFilename(shipName, role);
  const roleFlag = role.toLowerCase().replace(/ /g, "-");

  // Ensure the ship's subfolder exists before importing into it
  const folder = await ensureShipCrewFolder(shipName);

  const existing = game.actors.find(a =>
    a.getFlag(MODULE_ID, "assignedShip") === shipName.toLowerCase() &&
    a.getFlag(MODULE_ID, "crewRole")     === roleFlag &&
    a.folder?.id === folder?.id
  );
  if (existing) return existing;

  const response = await fetch(`modules/${MODULE_ID}/packs/actors/${fname}`);
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();

  delete data._id;
  data.items?.forEach(i => delete i._id);
  data.folder = folder.id;   // place directly in the ship's subfolder

  const actor = await Actor.create(data);
  console.log(`${MODULE_ID} | Imported crew: ${data.name} → Crew — ${shipName}`);
  return actor;
}

async function importCrew(shipName) {
  const errors = [];
  for (const role of ROLES) {
    try {
      await importCrewMember(shipName, role);
    } catch(e) {
      errors.push(role);
      console.error(`${MODULE_ID} | Crew import failed: ${role} — ${shipName}`, e);
    }
  }
  if (errors.length) {
    ui.notifications.warn(`Some crew members for ${shipName} could not be imported: ${errors.join(", ")}`);
  }
}

async function importAllCrews() {
  ui.notifications.info("Importing all crews (60 NPCs) — this may take a moment...");
  for (const name of SHIP_NAMES) {
    await importCrew(name);
  }
  ui.notifications.info("All crews imported into Cannons and Chaos - Crews.");
}

// ── STATE HELPERS ─────────────────────────────────────────────────────────────

function isShipImported(name) {
  return game.actors.some(a => a.name === name);
}

function isCrewMemberImported(shipName, role) {
  const roleFlag = role.toLowerCase().replace(/ /g, "-");
  return game.actors.some(a =>
    a.getFlag(MODULE_ID, "assignedShip") === shipName.toLowerCase() &&
    a.getFlag(MODULE_ID, "crewRole")     === roleFlag
  );
}


function isItemImported(filename) {
  const source = ITEM_CATEGORIES.flatMap(c => c.items).find(i => i.file === filename);
  if (!source) return false;
  return game.items.some(i => i.name === source.name);
}

// ── PANEL ─────────────────────────────────────────────────────────────────────

function openCNCPanel() {
  const rulesJournal  = game.journal.find(j => j.getFlag(MODULE_ID, "rules") === true);
  const commandBridge = game.macros.find(m => m.getFlag(MODULE_ID, "commandBridge") === true);

  // SHIP_TIERS is the module-level constant — use it directly for both tabs
  const tiers = SHIP_TIERS;

  // ── Ships tab ──────────────────────────────────────────────────────────────
  const shipRows = tiers.map(tier => {
    const rows = tier.ships.map(name => {
      const done = isShipImported(name);
      return `
        <div class="cnc-row">
          <span class="cnc-check">${done ? "✓" : ""}</span>
          <span class="cnc-label">${name}</span>
          <button class="cnc-import-btn" data-ship="${name}"${done ? " disabled" : ""}>Import</button>
          ${done ? `<button class="cnc-open-btn" data-ship="${name}">Open</button>` : `<span></span>`}
        </div>`;
    }).join("");
    return `<div class="cnc-tier"><div class="cnc-tier-label">${tier.label}</div>${rows}</div>`;
  }).join("");

  // ── Crews tab ─────────────────────────────────────────────────────────────
  const crewRows = tiers.map(tier => {
    const blocks = tier.ships.map(shipName => {
      const allDone = ROLES.every(r => isCrewMemberImported(shipName, r));
      const roleRows = ROLES.map(role => {
        const done = isCrewMemberImported(shipName, role);
        return `
          <div class="cnc-row cnc-crew-row">
            <span class="cnc-check">${done ? "✓" : ""}</span>
            <span class="cnc-label cnc-role-label">${role}</span>
            <button class="cnc-import-npc-btn" data-ship="${shipName}" data-role="${role}"${done ? " disabled" : ""}>Import</button>
          </div>`;
      }).join("");
      return `
        <div class="cnc-crew-block">
          <div class="cnc-crew-ship-label">
            <span>${shipName}</span>
            <button class="cnc-import-crew-btn" data-ship="${shipName}"${allDone ? " disabled" : ""}>Import All</button>
          </div>
          ${roleRows}
        </div>`;
    }).join("");
    return `<div class="cnc-tier"><div class="cnc-tier-label">${tier.label}</div>${blocks}</div>`;
  }).join("");


  // ── Components tab ────────────────────────────────────────────────────────
  const itemRows = ITEM_CATEGORIES.map(category => {
    const rows = category.items.map(entry => {
      const done = isItemImported(entry.file);
      return `
        <div class="cnc-row">
          <span class="cnc-check">${done ? "✓" : ""}</span>
          <span class="cnc-label">${entry.name}</span>
          <button class="cnc-import-item-btn" data-item-file="${entry.file}"${done ? " disabled" : ""}>Import</button>
          ${done ? `<button class="cnc-open-item-btn" data-item-name="${entry.name}">Open</button>` : `<span></span>`}
        </div>`;
    }).join("");
    return `<div class="cnc-tier"><div class="cnc-tier-label">${category.label}</div>${rows}</div>`;
  }).join("");

  // ── CSS + HTML ─────────────────────────────────────────────────────────────
  const content = `
<style>
.cnc-panel { font-family: 'Palatino Linotype', serif; color: #1e0a35; }
.cnc-header { text-align: center; margin-bottom: 10px; }
.cnc-header h2 { font-size: 17px; color: ${PURPLE}; margin: 0 0 2px 0; letter-spacing: 2px; }
.cnc-header p  { font-size: 11px; color: #7c5fa8; margin: 0; font-style: italic; }
.cnc-tabs { display: flex; margin-bottom: 0; border-bottom: 2px solid ${PURPLE}; }
.cnc-tab  { flex: 1; padding: 5px 0; text-align: center; font-size: 12px; font-weight: bold;
  letter-spacing: 1px; cursor: pointer; color: #7c5fa8;
  border: 1px solid ${PURPLE}; border-bottom: none; background: #f5eeff;
  border-radius: 4px 4px 0 0; }
.cnc-tab:first-child { margin-right: -1px; }
.cnc-tab.cnc-active { background: ${PURPLE}; color: #fff; }
.cnc-tab-content { display: none; padding-top: 8px; }
.cnc-tab-content.cnc-active { display: block; }
.cnc-scroll { max-height: 300px; overflow-y: auto; padding-right: 4px; }
.cnc-section { margin-bottom: 8px; }
.cnc-tier { margin-bottom: 8px; }
.cnc-tier-label { font-size: 10px; font-weight: bold; color: #7c5fa8;
  letter-spacing: 1px; margin-bottom: 3px; text-transform: uppercase; }
.cnc-row { display: grid; grid-template-columns: 16px 1fr auto auto;
  align-items: center; gap: 4px; padding: 2px 0;
  border-bottom: 1px solid rgba(107,33,168,0.1); }
.cnc-check { color: #5a2d91; font-weight: bold; font-size: 12px; text-align: center; }
.cnc-label { font-size: 12px; }
.cnc-crew-block { margin-bottom: 6px; }
.cnc-crew-ship-label { display: flex; align-items: center; justify-content: space-between;
  font-size: 11px; font-weight: bold; color: #3b0d6e; padding: 3px 0 2px 0;
  border-bottom: 1px solid rgba(107,33,168,0.3); margin-bottom: 2px; }
.cnc-crew-row { grid-template-columns: 16px 1fr auto; padding-left: 8px; }
.cnc-role-label { font-size: 11px; color: #4a1a7a; }
.cnc-import-btn, .cnc-open-btn, .cnc-import-npc-btn,
.cnc-import-crew-btn, .cnc-action-btn {
  font-size: 10px; padding: 2px 7px; cursor: pointer;
  border: 1px solid ${PURPLE}; border-radius: 3px; background: #f5eeff;
  color: #3b0d6e; white-space: nowrap; }
.cnc-import-btn:hover:not(:disabled), .cnc-import-npc-btn:hover:not(:disabled),
.cnc-import-crew-btn:hover:not(:disabled), .cnc-action-btn:hover { background: #e8d5ff; }
.cnc-open-btn { border-color: #3b0d6e; }
.cnc-open-btn:hover { background: #e8d5ff; }
button:disabled { opacity: 0.35; cursor: default; }
.cnc-action-row { display: flex; gap: 6px; margin-bottom: 8px; }
.cnc-action-btn { flex: 1; padding: 5px 8px; text-align: center; min-width: 70px; font-size: 11px; }
.cnc-action-btn.primary { background: ${PURPLE}; color: #fff; border-color: #4a1a7a; }
.cnc-action-btn.primary:hover { background: #7c3ab8; }
</style>

<div class="cnc-panel">
  <div class="cnc-header">
    <h2>⚓ CANNONS AND CHAOS</h2>
    <p>A Spelljammer Combat System by LaserW1tch</p>
  </div>

  <div class="cnc-section">
    <div class="cnc-action-row">
      ${rulesJournal  ? `<button class="cnc-action-btn" id="cnc-open-rules">📜 Rules PDF</button>` : ""}
      ${commandBridge ? `<button class="cnc-action-btn" id="cnc-open-macro">⚔ Command Bridge</button>` : ""}
    </div>
  </div>

  <div class="cnc-tabs">
    <div class="cnc-tab cnc-active" data-tab="ships">🚀 Ships</div>
    <div class="cnc-tab"            data-tab="crews">👥 Crews</div>
    <div class="cnc-tab"            data-tab="items">🧩 Components</div>
  </div>

  <div class="cnc-tab-content cnc-active" data-tab="ships">
    <div class="cnc-section">
      <div class="cnc-action-row">
        <button class="cnc-action-btn primary" id="cnc-import-all-ships">⬇ Import All Ships</button>
      </div>
    </div>
    <div class="cnc-scroll">${shipRows}</div>
  </div>

  <div class="cnc-tab-content" data-tab="crews">
    <div class="cnc-section">
      <div class="cnc-action-row">
        <button class="cnc-action-btn primary" id="cnc-import-all-crews">⬇ Import All Crews (60 NPCs)</button>
      </div>
    </div>
    <div class="cnc-scroll">${crewRows}</div>
  </div>

  <div class="cnc-tab-content" data-tab="items">
    <div class="cnc-section">
      <div class="cnc-action-row">
        <button class="cnc-action-btn primary" id="cnc-import-all-items">⬇ Import All Components</button>
      </div>
    </div>
    <div class="cnc-scroll">${itemRows}</div>
  </div>
</div>`;

  const d = new Dialog({
    title:   "Cannons and Chaos",
    content,
    buttons: {},
    render: html => {

      // Tab switching
      html.find(".cnc-tab").click(function() {
        html.find(".cnc-tab").removeClass("cnc-active");
        html.find(".cnc-tab-content").removeClass("cnc-active");
        $(this).addClass("cnc-active");
        html.find(`.cnc-tab-content[data-tab="${this.dataset.tab}"]`).addClass("cnc-active");
      });

      // Quick actions
      html.find("#cnc-open-rules").click(() => { rulesJournal?.sheet?.render(true); d.close(); });
      html.find("#cnc-open-macro").click(() => { commandBridge?.execute(); d.close(); });

      // Import all ships
      html.find("#cnc-import-all-ships").click(async () => {
        d.close();
        await importAllShips();
        openCNCPanel();
      });

      // Import single ship
      html.find(".cnc-import-btn").click(async function() {
        const name = this.dataset.ship;
        d.close();
        await importShip(name);
        ui.notifications.info(`${name} imported.`);
        openCNCPanel();
      });

      // Open ship sheet
      html.find(".cnc-open-btn").click(function() {
        game.actors.find(a => a.name === this.dataset.ship)?.sheet?.render(true);
        d.close();
      });

      // Import all crews
      html.find("#cnc-import-all-crews").click(async () => {
        d.close();
        await importAllCrews();
        openCNCPanel();
      });

      // Import one ship's full crew
      html.find(".cnc-import-crew-btn").click(async function() {
        const ship = this.dataset.ship;
        d.close();
        await importCrew(ship);
        ui.notifications.info(`Crew for ${ship} imported.`);
        openCNCPanel();
      });

      // Import single NPC
      html.find(".cnc-import-npc-btn").click(async function() {
        const { ship, role } = this.dataset;
        d.close();
        try {
          await importCrewMember(ship, role);
          ui.notifications.info(`${role} of the ${ship} imported.`);
        } catch(e) {
          ui.notifications.error(`Failed to import ${role} of the ${ship}.`);
        }
        openCNCPanel();
      });

      // Import all components
      html.find("#cnc-import-all-items").click(async () => {
        d.close();
        await importAllItems();
        openCNCPanel();
      });

      // Import single component
      html.find(".cnc-import-item-btn").click(async function() {
        const file = this.dataset.itemFile;
        d.close();
        await importItem(file);
        openCNCPanel();
      });

      // Open imported component
      html.find(".cnc-open-item-btn").click(function() {
        game.items.find(i => i.name === this.dataset.itemName)?.sheet?.render(true);
        d.close();
      });
    }
  });

  d.render(true, { width: 400, height: "auto" });
}