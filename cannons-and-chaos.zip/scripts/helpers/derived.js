export const MODULE_ID = "cannons-and-chaos";
export const CNC_MODULE_ID = "cannons-and-chaos";

export function getCncFlags(document) {
  return document?.getFlag?.(CNC_MODULE_ID, "") ?? {};
}

export function getHullData(actor) {
  return actor?.getFlag?.(CNC_MODULE_ID, "hullData") ?? {};
}

export function getSheetState(actor) {
  return actor?.getFlag?.(MODULE_ID, "sheetState") ?? {};
}

export function getCrewEntries(actor) {
  const entries = actor?.getFlag?.(MODULE_ID, "sheetState")?.crew?.entries;
  return Array.isArray(entries) ? entries : [];
}


export function getItemCncFlags(item) {
  return item?.getFlag?.(CNC_MODULE_ID, "") ?? {};
}

export function getComponentType(item) {
  return getItemCncFlags(item).componentType ?? null;
}

export function getComponentTier(item) {
  const tier = getItemCncFlags(item).tier;
  return Number.isFinite(Number(tier)) ? Number(tier) : null;
}

export function getMountIndex(item) {
  const mountIndex = getItemCncFlags(item).mountIndex;
  return Number.isFinite(Number(mountIndex)) ? Number(mountIndex) : null;
}

export function getPowerCost(item) {
  const powerCost = getItemCncFlags(item).powerCost;
  return Number.isFinite(Number(powerCost)) ? Number(powerCost) : null;
}

export function getArc(item) {
  return getItemCncFlags(item).arc ?? null;
}

export function getLoadedState(item) {
  const loaded = getItemCncFlags(item).loaded;
  if (loaded === true || loaded === false) return loaded;
  return getResolvedComponentType(item) === "weapon" ? true : null;
}

export function getWeaponLoadStates(actor) {
  return actor?.getFlag?.(MODULE_ID, "weaponLoadStates") ?? {};
}

export function getWeaponLoadedState(actor, item) {
  if (getResolvedComponentType(item) !== "weapon") return null;
  const states = getWeaponLoadStates(actor);
  if (Object.prototype.hasOwnProperty.call(states, item?.id)) return states[item.id] === true;
  return getLoadedState(item) !== false;
}

function tierRomanNumeral(tier) {
  return ({ 1: "I", 2: "II", 3: "III", 4: "IV" })[Number(tier ?? 0)] ?? String(tier ?? "?");
}

function getHullClassLabel(hull) {
  return String(hull?.hullClass ?? hull?.class ?? hull?.name ?? "Unknown Hull").trim() || "Unknown Hull";
}

function getHullTierSubtitle(hull) {
  const tier = Number(hull?.tier ?? 0);
  const classLabel = getHullClassLabel(hull);
  if (tier > 0) return `Tier ${tierRomanNumeral(tier)} - ${classLabel}`;
  return classLabel;
}

function stripHtml(value) {
  return String(value ?? "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/gi, " ").replace(/\s+/g, " ").trim();
}

function getDescription(item) {
  return item?.system?.description?.value ?? item?.system?.description ?? item?.system?.details?.description ?? "";
}

function parseComponentAc(item) {
  const direct = Number(item?.system?.armor?.value ?? item?.system?.attributes?.ac?.value ?? item?.system?.ac ?? NaN);
  if (Number.isFinite(direct)) return direct;
  const text = stripHtml(getDescription(item));
  const m = text.match(/\bAC\s*[:\-]?\s*(\d+)\b/i) || text.match(/\bArmor Class\s*[:\-]?\s*(\d+)\b/i);
  return m ? Number(m[1]) : 0;
}

function parseComponentHpMax(item) {
  const direct = Number(item?.system?.hp?.max ?? item?.system?.hitPoints?.max ?? item?.system?.attributes?.hp?.max ?? NaN);
  if (Number.isFinite(direct)) return direct;
  const text = stripHtml(getDescription(item));
  const m = text.match(/\bHP\s*[:\-]?\s*(\d+)\b/i) || text.match(/\bHit Points?\s*[:\-]?\s*(\d+)\b/i);
  if (m) return Number(m[1]);
  const tier = getResolvedComponentTier(item);
  return tier ? tier * 5 : 1;
}

export function getComponentStates(actor) {
  return getSheetState(actor)?.combat?.componentStates ?? {};
}

export function getComponentState(actor, item) {
  const existing = foundry.utils.deepClone(getComponentStates(actor)?.[item?.id] ?? {});
  const hpMax = Math.max(0, Number(existing.hpMax ?? parseComponentHpMax(item) ?? 1));
  const hpCurrent = Math.max(0, Number(existing.hpCurrent ?? hpMax));
  const stateRaw = String(existing.state ?? (hpCurrent <= 0 ? "disabled" : "operational"));
  const state = ["operational", "disabled", "destroyed"].includes(stateRaw) ? stateRaw : "operational";
  const ac = Math.max(0, Number(existing.ac ?? parseComponentAc(item) ?? 0));
  const onFire = existing.onFire === true;
  const hpPercent = hpMax > 0 ? Math.max(0, Math.min(100, (hpCurrent / hpMax) * 100)) : 0;
  const stateLabel = state.charAt(0).toUpperCase() + state.slice(1);
  const hpTier = hpPercent <= 0 ? "destroyed" : hpPercent <= 33 ? "critical" : hpPercent <= 66 ? "damaged" : "healthy";
  return { ac, hpCurrent, hpMax, onFire, state, hpPercent, hpTier, stateLabel };
}

export async function ensureComponentStates(actor) {
  const states = foundry.utils.deepClone(getComponentStates(actor) ?? {});
  let changed = false;
  for (const item of Array.from(actor?.items ?? [])) {
    const componentType = getResolvedComponentType(item);
    if (!componentType || componentType === "profile") continue;
    if (!Object.prototype.hasOwnProperty.call(states, item.id)) {
      states[item.id] = getComponentState(actor, item);
      changed = true;
    }
  }
  if (changed) {
    const sheetState = foundry.utils.deepClone(getSheetState(actor) ?? {});
    sheetState.combat ??= {};
    sheetState.combat.componentStates = states;
    await actor.setFlag(MODULE_ID, "sheetState", sheetState);
    return true;
  }
  return false;
}

function romanToInt(input) {
  const s = String(input ?? "").toUpperCase();
  if (!s) return null;
  if (/^\d+$/.test(s)) return Number(s);
  const map = { I: 1, V: 5, X: 10, L: 50, C: 100 };
  let total = 0, prev = 0;
  for (let i = s.length - 1; i >= 0; i--) {
    const val = map[s[i]] ?? 0;
    total += val < prev ? -val : val;
    prev = val;
  }
  return total || null;
}

function parseTier(item) {
  const name = String(item?.name ?? "");
  const desc = stripHtml(getDescription(item));

  let m = name.match(/\(T\s*(\d+)\s+Utility\)$/i);
  if (m) return Number(m[1]);

  m = name.match(/Tier\s*([IVX\d]+)/i) || desc.match(/Tier\s*[:\-]?\s*([IVX\d]+)/i);
  if (m) return romanToInt(m[1]);

  return null;
}

function parsePowerCost(item) {
  const text = stripHtml(getDescription(item));

  const explicitPatterns = [
    /(?:pp|power(?:\s+points?)?)\s*cost\s*[:\-]?\s*(\d+)/i,
    /(?:spend|spends|spent|use|uses|using)\s*(\d+)\s*(?:power|pp)\b/i,
    /cost\s*[:\-]?\s*(\d+)\s*(?:power|pp)\b/i
  ];

  for (const pattern of explicitPatterns) {
    const m = text.match(pattern);
    if (m) return Number(m[1]);
  }

  return null;
}

function parsePowerPointCapacity(item) {
  const text = stripHtml(getDescription(item));
  const m = text.match(/power\s*points?\s*(?:pool)?\s*[:\-]?\s*(\d+)/i);
  return m ? Number(m[1]) : null;
}

function getInstalledPowerCoreItem(actor, hull = null) {
  const targetId = hull?.installed?.powerCore?.id ?? null;
  if (targetId) {
    const byId = actor?.items?.get?.(targetId);
    if (byId) return byId;
  }

  const items = Array.from(actor?.items ?? []);
  return items.find(i => getResolvedComponentType(i) === "powerCore" && (getItemCncFlags(i).installed === true)) ?? null;
}

function getComputedPowerMax(actor, hull = null) {
  const powerCore = getInstalledPowerCoreItem(actor, hull);
  if (!powerCore) return 0;
  return parsePowerPointCapacity(powerCore) ?? 0;
}


export async function ensureWeaponLoadState(actor) {
  const states = foundry.utils.deepClone(getWeaponLoadStates(actor) ?? {});
  let changed = false;
  for (const item of Array.from(actor?.items ?? [])) {
    if (getResolvedComponentType(item) !== "weapon") continue;
    if (!Object.prototype.hasOwnProperty.call(states, item.id)) {
      states[item.id] = getLoadedState(item) !== false;
      changed = true;
    }
  }
  if (changed) {
    await actor.setFlag(MODULE_ID, "weaponLoadStates", states);
    return true;
  }
  return false;
}

export async function ensureTurnPowerState(actor) {
  const hull = getHullData(actor);
  const computedMax = getComputedPowerMax(actor, hull);
  if (computedMax <= 0) return false;

  const sheetState = foundry.utils.deepClone(getSheetState(actor) ?? {});
  sheetState.combat ??= {};

  let changed = false;

  if (!sheetState.combat.powerInitialized) {
    sheetState.combat.powerPointsMax = computedMax;
    sheetState.combat.powerPoints = computedMax;
    sheetState.combat.powerInitialized = true;
    changed = true;
  } else if (!(Number(sheetState.combat.powerPointsMax) > 0)) {
    sheetState.combat.powerPointsMax = computedMax;
    if (!(Number(sheetState.combat.powerPoints) >= 0)) {
      sheetState.combat.powerPoints = computedMax;
    }
    changed = true;
  }

  if (changed) {
    await actor.setFlag(MODULE_ID, "sheetState", sheetState);
  }

  return changed;
}

function parseMountIndex(item) {
  const m = String(item?.name ?? "").match(/\s*[—–-]\s*Mount\s+(\d+)$/i);
  return m ? Number(m[1]) : null;
}

function parseArc(item) {
  const name = String(item?.name ?? "");
  const matches = Array.from(name.matchAll(/\(([^)]+)\)/g));
  for (const match of matches) {
    const candidate = String(match?.[1] ?? "").trim();
    if (/^(fore|port|starboard|aft|stern)$/i.test(candidate)) return candidate;
  }
  return null;
}

function isCargoLikeType(type) {
  return ["loot", "consumable", "container", "backpack"].includes(type);
}

function looksLikeEngineName(rawName) {
  return /^(arcane jet|arcane jets|arcane thruster|arcane thrusters|arcane sails|propeller engine|propeller engines)$/i.test(rawName)
    || /^(arcane jet|arcane jets|arcane thruster|arcane thrusters|arcane sails|propeller engine|propeller engines)\s*[—–-]\s*mount\s+\d+$/i.test(rawName);
}

export function classifyComponentType(item) {
  const type = String(item?.type ?? "").toLowerCase();
  const rawName = String(item?.name ?? "").trim();
  const desc = stripHtml(getDescription(item)).toLowerCase();

  if (isCargoLikeType(type)) return null;

  if (/combat-hardened helm enhancement/i.test(rawName)) return "utility";
  if (/auxiliary power core/i.test(rawName)) return "utility";
  if (/chrono-stabilization engine/i.test(rawName)) return "utility";
  if (/luminarch mk xxx/i.test(rawName)) return "helm";

  // Explicit utility matches from the Cannons & Chaos utility catalog.
  if (/^arcanomech fire suppression matrix$/i.test(rawName)) return "utility";
  if (/^arcanomech repair matrix$/i.test(rawName)) return "utility";
  if (/^arcanomech targeting matrix \+?[123]$/i.test(rawName)) return "utility";
  if (/^hidden cargo storage$/i.test(rawName)) return "utility";
  if (/^reinforced hull plating$/i.test(rawName)) return "utility";
  if (/^boarding defense grid$/i.test(rawName)) return "utility";
  if (/^improved rudder array$/i.test(rawName)) return "utility";
  if (/^adamantine ramming prow$/i.test(rawName)) return "utility";
  if (/^arcane shield projector$/i.test(rawName)) return "utility";
  if (/^self-repair organism$/i.test(rawName)) return "utility";
  if (/^aegis harmonic barrier lattice$/i.test(rawName)) return "utility";
  if (/^arcane capacitor bank \(overloaded\)$/i.test(rawName)) return "utility";
  if (/^dimensional anchor array$/i.test(rawName)) return "utility";

  if (type === "weapon") return "weapon";
  if (/\bperformance profile\b/i.test(rawName)) return "profile";
  if (/power\s*core|powercore/i.test(rawName) || /power\s*core|powercore/i.test(desc)) return "powerCore";
  if (looksLikeEngineName(rawName)) return "engine";

  // Broader utility fallback for known utility naming patterns.
  if (/(matrix|storage|plating|grid|rudder array|prow|projector|organism|lattice|capacitor bank|anchor array)$/i.test(rawName)) return "utility";

  const hasHelmName = /(^|\b)(helm|tradehelm)([:\s-]|$)/i.test(rawName);
  const looksLikeMkHullController = /(\bMK\s*[IVX\d]+\b|\bv\d+(?:\.\d+)+\b)/i.test(rawName);
  const hasSpecialAction = /special action/i.test(desc);
  const mentionsHelmOfficer = /helm officer/i.test(desc);

  if (hasHelmName || ((looksLikeMkHullController || mentionsHelmOfficer) && hasSpecialAction)) return "helm";
  if (/\butility\b/i.test(rawName) || /\butility\b/i.test(desc)) return "utility";

  return null;
}

export function getResolvedComponentType(item) {
  return getComponentType(item) ?? classifyComponentType(item);
}

export function getResolvedComponentTier(item) {
  return getComponentTier(item) ?? parseTier(item);
}

export function getResolvedMountIndex(item) {
  return getMountIndex(item) ?? parseMountIndex(item);
}

export function getResolvedPowerCost(item) {
  const flagged = getPowerCost(item);
  if (flagged != null) {
    // Imported shard costs occasionally landed in the powerCost flag on some helms.
    // Treat implausibly large values as bad data and fall back to parsing the rules text.
    if (flagged <= 100) return flagged;
  }
  return parsePowerCost(item);
}

export function getResolvedArc(item) {
  const rawArc = getArc(item) ?? parseArc(item) ?? null;
  const normalized = String(rawArc ?? "").trim().toLowerCase();
  if (normalized === "stern") return "Aft";
  if (normalized === "aft") return "Aft";
  if (normalized === "fore") return "Fore";
  if (normalized === "port") return "Port";
  if (normalized === "starboard") return "Starboard";
  return rawArc;
}

export function buildCncFlagsForItem(item, overrides = {}) {
  const componentType = overrides.componentType ?? getResolvedComponentType(item);
  const tier = overrides.tier ?? getResolvedComponentTier(item);
  const mountIndex = overrides.mountIndex ?? getResolvedMountIndex(item);
  const arc = overrides.arc ?? getResolvedArc(item);
  const powerCost = overrides.powerCost ?? getResolvedPowerCost(item);
  const installed = overrides.installed ?? (componentType !== "profile" && componentType !== null);

  return {
    componentType,
    tier: tier ?? null,
    mountIndex: mountIndex ?? null,
    arc: arc ?? null,
    powerCost: powerCost ?? null,
    installed,
    schemaVersion: 1
  };
}

export function isShipActor(actor) {
  return actor?.type === "vehicle" && actor?.getFlag?.(CNC_MODULE_ID, "ship") === true;
}

function hullInstalledIdSet(hull) {
  const ids = new Set();
  if (hull?.installed?.helm?.id) ids.add(hull.installed.helm.id);
  if (hull?.installed?.powerCore?.id) ids.add(hull.installed.powerCore.id);
  for (const e of hull?.installed?.engines ?? []) if (e?.id) ids.add(e.id);
  for (const w of hull?.installed?.weapons ?? []) if (w?.id) ids.add(w.id);
  for (const u of hull?.installed?.utilities ?? []) if (u?.id) ids.add(u.id);
  return ids;
}

function makeBuckets() {
  return { helm: [], powerCore: [], engine: [], utility: [], weapon: [], profile: [], other: [] };
}

function sortBuckets(buckets) {
  buckets.engine.sort((a, b) => (getResolvedMountIndex(a) ?? 999) - (getResolvedMountIndex(b) ?? 999));
  return buckets;
}

export function classifyItemsByFlag(items) {
  const buckets = makeBuckets();
  for (const item of items ?? []) {
    const componentType = getResolvedComponentType(item);
    if (componentType && buckets[componentType]) buckets[componentType].push(item);
    else buckets.other.push(item);
  }
  return sortBuckets(buckets);
}

export function classifyInstalledItems(items, hull = null) {
  const buckets = makeBuckets();
  const installedIds = hullInstalledIdSet(hull);
  const itemList = Array.from(items ?? []);

  const hasExplicitInstalledFlags = itemList.some(item => {
    const installed = getItemCncFlags(item).installed;
    return installed === true || installed === false;
  });

  for (const item of itemList) {
    const componentType = getResolvedComponentType(item);
    const installedByFlag = getItemCncFlags(item).installed === true;
    const installedByLegacyHull = !hasExplicitInstalledFlags && installedIds.has(item.id);
    const installed = installedByFlag || installedByLegacyHull;
    if (!installed) continue;
    if (componentType && buckets[componentType]) buckets[componentType].push(item);
  }

  return sortBuckets(buckets);
}

function parseTierLikeValue(value) {
  if (value == null) return null;
  if (typeof value === "number" && Number.isFinite(value)) return value;

  const s = String(value).trim();
  if (!s) return null;

  if (/^\d+$/.test(s)) return Number(s);

  const numericTier = s.match(/^T\s*(\d+)$/i) || s.match(/^Tier\s*(\d+)$/i);
  if (numericTier) return Number(numericTier[1]);

  const romanTier = s.match(/^T\s*([IVXLC]+)$/i) || s.match(/^Tier\s*([IVXLC]+)$/i);
  if (romanTier) return romanToInt(romanTier[1]);

  const romanMatch = s.match(/^[IVXLC]+$/i);
  if (romanMatch) return romanToInt(s);

  const embedded = s.match(/(\d+)/);
  if (embedded) return Number(embedded[1]);

  return null;
}

export function normalizeLimit(value, fallback = 0) {
  const parsed = parseTierLikeValue(value);
  if (parsed != null) return parsed;

  const fallbackParsed = parseTierLikeValue(fallback);
  return fallbackParsed != null ? fallbackParsed : 0;
}


function getEffectiveShipTier(hull) {
  const directTier = normalizeLimit(hull?.tier, 0);
  if (directTier > 0) return directTier;

  const coreTier = normalizeLimit(hull?.frame?.requiredPowerCoreTier, 0);
  if (coreTier > 0) return coreTier;

  return 0;
}


function collectShipTierViolations(hull, classified) {
  const shipTier = getEffectiveShipTier(hull);
  const violations = [];
  const weaponCap = normalizeLimit(hull?.frame?.maxWeaponTier, shipTier > 0 ? shipTier : 0);
  const utilityCap = normalizeLimit(hull?.frame?.maxUtilityTier, shipTier > 0 ? shipTier : 0);

  const helm = classified?.helm?.[0] ?? null;
  if (helm) {
    const tier = Number(getResolvedComponentTier(helm) ?? 0);
    if (shipTier > 0 && tier > shipTier) violations.push(`${helm.name} (helm T${tier} on ship T${shipTier})`);
  }

  const core = classified?.powerCore?.[0] ?? null;
  if (core) {
    const tier = Number(getResolvedComponentTier(core) ?? 0);
    if (shipTier > 0 && tier > shipTier) violations.push(`${core.name} (power core T${tier} on ship T${shipTier})`);
  }

  for (const item of classified?.weapon ?? []) {
    const tier = Number(getResolvedComponentTier(item) ?? 0);
    const effectiveCap = weaponCap > 0 && shipTier > 0 ? Math.min(weaponCap, shipTier) : (weaponCap || shipTier);
    if (effectiveCap > 0 && tier > effectiveCap) violations.push(`${item.name} (weapon T${tier} above cap T${effectiveCap})`);
  }

  for (const item of classified?.utility ?? []) {
    const tier = Number(getResolvedComponentTier(item) ?? 0);
    const effectiveCap = utilityCap > 0 && shipTier > 0 ? Math.min(utilityCap, shipTier) : (utilityCap || shipTier);
    if (effectiveCap > 0 && tier > effectiveCap) violations.push(`${item.name} (utility T${tier} above cap T${effectiveCap})`);
  }

  return violations;
}

export function buildValidationProfile(actor, buckets = null) {
  const hull = getHullData(actor);
  const frame = hull.frame ?? {};
  const classified = buckets ?? classifyInstalledItems(Array.from(actor?.items ?? []), hull);

  const legalityViolations = collectShipTierViolations(hull, classified);

  return {
    legalityViolations,
    limits: {
      helm: 1,
      powerCore: 1,
      engine: normalizeLimit(frame.engineMounts, classified.engine.length),
      // weaponHardpoints is the rolled actual count from the hull generator (the enforced cap).
      // weaponHardpointsMax is the class ceiling — used only as a fallback for legacy ships
      // that predate the hull generator storing both values separately.
      weapon: normalizeLimit(frame.weaponHardpoints ?? frame.weaponHardpointsMax, classified.weapon.length),
      utility: normalizeLimit(frame.utilityHardpoints ?? frame.utilityHardpointsMax, classified.utility.length)
    },
    tierCaps: {
      powerCore: normalizeLimit(frame.requiredPowerCoreTier, hull.tier ?? 0),
      weapon: normalizeLimit(frame.maxWeaponTier, hull.tier ?? 0),
      utility: normalizeLimit(frame.maxUtilityTier, hull.tier ?? 0)
    }
  };
}

function buildInstalledStateFromActor(actor, existingHull = null) {
  const items = Array.from(actor?.items ?? []);
  const classified = classifyInstalledItems(items, existingHull);

  return {
    helm: classified.helm[0] ? {
      id: classified.helm[0].id,
      name: classified.helm[0].name,
      componentType: "helm",
      tier: getResolvedComponentTier(classified.helm[0])
    } : null,
    powerCore: classified.powerCore[0] ? {
      id: classified.powerCore[0].id,
      name: classified.powerCore[0].name,
      componentType: "powerCore",
      tier: getResolvedComponentTier(classified.powerCore[0])
    } : null,
    engines: classified.engine.map(item => ({
      id: item.id,
      name: item.name,
      componentType: "engine",
      mountIndex: getResolvedMountIndex(item)
    })),
    weapons: classified.weapon.map(item => ({
      id: item.id,
      name: item.name,
      componentType: "weapon",
      tier: getResolvedComponentTier(item),
      arc: getResolvedArc(item),
      powerCost: getResolvedPowerCost(item)
    })),
    utilities: classified.utility.map(item => ({
      id: item.id,
      name: item.name,
      componentType: "utility",
      tier: getResolvedComponentTier(item),
      powerCost: getResolvedPowerCost(item)
    }))
  };
}

function needsLegacyCorrection(item, currentType, inferredType) {
  const rawName = String(item?.name ?? "").trim();
  const type = String(item?.type ?? "").toLowerCase();

  if (currentType === "utility" && inferredType === "engine" && looksLikeEngineName(rawName)) return true;
  if (currentType === "utility" && inferredType === null && isCargoLikeType(type)) return true;

  return false;
}

function hullHasAnyInstalled(hull) {
  return hullInstalledIdSet(hull).size > 0;
}

export async function ensureShipComponentsHydrated(actor) {
  if (!isShipActor(actor)) return false;

  const existingHull = foundry.utils.deepClone(getHullData(actor) ?? {});
  const installedIds = hullInstalledIdSet(existingHull);
  const itemUpdates = [];

  for (const item of Array.from(actor?.items ?? [])) {
    const flags = getItemCncFlags(item);
    const currentType = flags.componentType ?? null;
    const inferredType = classifyComponentType(item);

    let componentType = currentType;
    let tier = flags.tier ?? null;
    let mountIndex = flags.mountIndex ?? null;
    let arc = flags.arc ?? null;
    let powerCost = flags.powerCost ?? null;
    let installed = flags.installed;

    let changed = false;

    if (!componentType) {
      componentType = inferredType;
      if (componentType !== currentType) changed = true;
    } else if (needsLegacyCorrection(item, currentType, inferredType)) {
      componentType = inferredType;
      changed = true;
    }

    if (tier == null) {
      const parsed = parseTier(item);
      if (parsed != null) { tier = parsed; changed = true; }
    }

    if (mountIndex == null) {
      const parsed = parseMountIndex(item);
      if (parsed != null) { mountIndex = parsed; changed = true; }
    }

    if (arc == null && componentType === "weapon") {
      const parsed = parseArc(item);
      if (parsed != null) { arc = parsed; changed = true; }
    }

    if (powerCost == null) {
      const parsed = parsePowerCost(item);
      if (parsed != null) { powerCost = parsed; changed = true; }
    }

    // Seed legacy installed state from hullData ids once, otherwise trust explicit flags.
    let desiredInstalled = installed;
    if (installed == null && installedIds.has(item.id)) desiredInstalled = true;
    else if (installed == null && !hullHasAnyInstalled(existingHull)) {
      desiredInstalled = componentType !== "profile" && componentType !== null && !isCargoLikeType(String(item?.type ?? "").toLowerCase());
    }

    if (installed !== desiredInstalled && desiredInstalled !== undefined) {
      installed = desiredInstalled;
      changed = true;
    }

    if (changed) {
      itemUpdates.push({
        _id: item.id,
        [`flags.${CNC_MODULE_ID}.componentType`]: componentType ?? null,
        [`flags.${CNC_MODULE_ID}.tier`]: tier ?? null,
        [`flags.${CNC_MODULE_ID}.mountIndex`]: mountIndex ?? null,
        [`flags.${CNC_MODULE_ID}.arc`]: arc ?? null,
        [`flags.${CNC_MODULE_ID}.powerCost`]: powerCost ?? null,
        ...(installed !== undefined ? { [`flags.${CNC_MODULE_ID}.installed`]: installed } : {}),
        [`flags.${CNC_MODULE_ID}.schemaVersion`]: 1
      });
    }
  }

  if (itemUpdates.length) {
    await actor.updateEmbeddedDocuments("Item", itemUpdates);
  }

  // Always rebuild hull.installed from explicit installed flags after hydration.
  const rebuiltHull = foundry.utils.deepClone(getHullData(actor) ?? {});
  rebuiltHull.installed = buildInstalledStateFromActor(actor, rebuiltHull);
  await actor.setFlag(CNC_MODULE_ID, "hullData", rebuiltHull);

  return itemUpdates.length > 0;
}

function itemNameLower(item) {
  return String(item?.name ?? "").trim().toLowerCase();
}

function isNamed(item, pattern) {
  return pattern.test(itemNameLower(item));
}

function sumNamedBonuses(items, mapping) {
  let total = 0;
  for (const item of Array.from(items ?? [])) {
    const name = itemNameLower(item);
    for (const [pattern, value] of mapping) {
      if (pattern.test(name)) total += value;
    }
  }
  return total;
}

function hasNamed(items, pattern) {
  return Array.from(items ?? []).some(item => isNamed(item, pattern));
}

function computeDerivedShipStats(actor, hull, classifiedRaw, combat) {
  const stats = hull?.stats ?? {};

  const baseHp = Number(actor?.system?.attributes?.hp?.max ?? stats.hp ?? 0);
  const baseAc = Number(actor?.system?.attributes?.ac?.flat ?? actor?.system?.attributes?.ac?.value ?? stats.ac ?? 0);
  const baseDt = normalizeLimit(stats.damageThreshold, 0);
  const baseTurnRate = normalizeLimit(stats.turnRate, 0);
  const baseCargo = normalizeLimit(stats.cargoMaxTons, 0);

  const engines = classifiedRaw.engine ?? [];
  const utilities = classifiedRaw.utility ?? [];
  const helms = classifiedRaw.helm ?? [];

  const operationalEngines = engines.filter(item => {
    const state = getComponentState(actor, item);
    return state.state === "operational" && Number(state.hpCurrent ?? 0) > 0;
  });
  const hasOperationalArcaneSails = operationalEngines.some(item => isNamed(item, /^arcane sails(?:\s*[—–-]\s*mount\s+\d+)?$/i));
  const speedTotal = hasOperationalArcaneSails ? 5 : operationalEngines.length;

  const turnRateBonus = sumNamedBonuses(utilities, [
    [/^improved rudder array$/i, 1]
  ]);

  const acBonus = sumNamedBonuses(utilities, [
    [/^reinforced hull plating$/i, 2]
  ]);

  const dtBonus = sumNamedBonuses(utilities, [
    [/^reinforced hull plating$/i, 4]
  ]);

  const cargoBonus = sumNamedBonuses(utilities, [
    [/^hidden cargo storage$/i, 1]
  ]);

  const dexScore =
    Number(actor?.system?.abilities?.dex?.value ?? actor?.system?.abilities?.dex ?? hull?.abilities?.dex ?? 10);
  const dexMod = Math.floor((dexScore - 10) / 2);

  const targetingMatrixBonus = (() => {
    let total = 0;
    for (const item of Array.from(utilities ?? [])) {
      const name = itemNameLower(item);
      const tier = getResolvedComponentTier(item);

      if (/^arcanomech targeting matrix\s*\+?1$/i.test(name)) { total += 1; continue; }
      if (/^arcanomech targeting matrix\s*\+?2$/i.test(name)) { total += 2; continue; }
      if (/^arcanomech targeting matrix\s*\+?3$/i.test(name)) { total += 3; continue; }

      if (/^arcanomech targeting matrix\b/i.test(name) && tier != null) {
        total += tier;
        continue;
      }

      if (/^arcanomech targeting matrix\s*(?:mk\s*)?i{1,3}$/i.test(name)) {
        const roman = name.match(/(i{1,3})$/i);
        if (roman) total += romanToInt(roman[1]) ?? 0;
      }
    }
    return total;
  })();

  const helmAttackBonus =
    sumNamedBonuses(helms, [
      [/^luminarch mk xxx$/i, 1]
    ]);

  const weaponAttackBonus =
    dexMod + targetingMatrixBonus + helmAttackBonus;

  const computedPowerMax = getComputedPowerMax(actor, hull);

  const notes = [];
  if (hasOperationalArcaneSails) notes.push("Arcane Sails set ship speed to 5 and exclude other propulsion.");
  if (turnRateBonus) notes.push(`Improved Rudder Array: +${turnRateBonus} turn rate.`);
  if (acBonus || dtBonus) notes.push(`Reinforced Hull Plating: +${acBonus} AC, +${dtBonus} damage threshold.`);
  if (weaponAttackBonus) notes.push(`Fire-control bonus: +${weaponAttackBonus} to installed weapon attacks.`);
  if (cargoBonus) notes.push(`Hidden Cargo Storage: +${cargoBonus} ton cargo capacity.`);
  if (hasNamed(utilities, /^auxiliary (?:crystal )?power core$/i)) notes.push("Auxiliary Power Core increases max power.");
  if (hasNamed(utilities, /^arcane capacitor bank \(overloaded\)$/i)) notes.push("Arcane Capacitor Bank (Overloaded) increases max power.");
  if (hasNamed(utilities, /^combat-hardened helm enhancement$/i)) notes.push("Combat-Hardened Helm Enhancement affects the installed helm.");
  if (hasNamed(utilities, /^adamantine ramming prow$/i)) notes.push("Adamantine Ramming Prow modifies ramming damage.");
  if (hasNamed(utilities, /^arcane shield projector$/i)) notes.push("Arcane Shield Projector grants temporary HP while active.");
  if (hasNamed(utilities, /^self-repair organism$/i)) notes.push("Self-Repair Organism grants one destruction prevention per combat.");
  if (hasNamed(utilities, /^dimensional anchor array$/i)) notes.push("Dimensional Anchor Array blocks teleport/reposition effects.");
  if (hasNamed(utilities, /^aegis harmonic barrier lattice$/i)) notes.push("Aegis Harmonic Barrier Lattice grants recurring temp HP / damage reduction.");
  if (hasNamed(utilities, /^chrono-stabilization engine$/i)) notes.push("Chrono-Stabilization Engine changes initiative / extra-turn timing.");

  return {
    speed: {
      base: 0,
      bonus: speedTotal,
      total: speedTotal
    },
    turnRate: {
      base: baseTurnRate,
      bonus: turnRateBonus,
      total: baseTurnRate + turnRateBonus
    },
    ac: {
      base: baseAc,
      bonus: acBonus,
      total: baseAc + acBonus
    },
    damageThreshold: {
      base: baseDt,
      bonus: dtBonus,
      total: baseDt + dtBonus
    },
    cargo: {
      base: baseCargo,
      bonus: cargoBonus,
      total: baseCargo + cargoBonus
    },
    hp: {
      base: baseHp,
      bonus: 0,
      total: baseHp
    },
    power: {
      total: computedPowerMax,
      current: Math.min(Number(combat?.powerPoints ?? 0), computedPowerMax)
    },
    weapons: {
      attackBonus: weaponAttackBonus,
      dexMod,
      targetingBonus: targetingMatrixBonus,
      helmBonus: helmAttackBonus
    },
    notes
  };
}

function getDisplayRange(item) {
  const text = stripHtml(getDescription(item));

  let m = text.match(/(\d+)\s*\/\s*(\d+)\s*(hex|hexes)\s+range/i)
    || text.match(/range\s*[:\-]?\s*(\d+)\s*\/\s*(\d+)\s*(hex|hexes)/i);
  if (m) return `${m[1]}/${m[2]} hex`;

  m = text.match(/range\s*[:\-]?\s*(\d+)\s*(hex|hexes)/i);
  if (m) return `${m[1]} hex`;

  const direct = item?.system?.range ?? {};
  const directValue = Number(direct?.value ?? NaN);
  const directLong = Number(direct?.long ?? NaN);
  const directUnits = String(direct?.units ?? "").trim().toLowerCase();

  const toHex = (value, units) => {
    if (!Number.isFinite(value) || value <= 0) return null;
    if (units === "hex" || units === "hexes") return Math.round(value);
    if (units === "ft" || units === "feet") return Math.max(1, Math.round(value / 50));
    return null;
  };

  const shortHex = toHex(directValue, directUnits);
  const longHex = toHex(directLong, directUnits);
  if (shortHex || longHex) return longHex ? `${shortHex ?? "—"}/${longHex} hex` : `${shortHex} hex`;

  return "—";
}

function presentItem(item, actor) {
  const data = item?.toObject ? item.toObject() : foundry.utils.deepClone(item);
  data.id = item?.id ?? data.id ?? data._id;
  data.uuid = item?.uuid ?? data.uuid ?? null;

  const componentType = getResolvedComponentType(item);
  const powerCost = getResolvedPowerCost(item);
  const displayPowerCost = powerCost ?? 0;
  const showUse = componentType === "weapon" || powerCost != null;

  const hull = getHullData(actor);
  const sheetState = getSheetState(actor);
  const assignedArc = componentType === "weapon"
    ? (sheetState?.battleArcAssignments?.[data.id] ?? null)
    : null;

  const installedWeapon = componentType === "weapon"
    ? (hull?.installed?.weapons ?? []).find(w => w?.id === data.id)
    : null;

  const resolvedArc = componentType === "weapon"
    ? (assignedArc ?? installedWeapon?.arc ?? getResolvedArc(item))
    : getResolvedArc(item);

  data._cncResolved = {
    componentType,
    tier: getResolvedComponentTier(item),
    mountIndex: getResolvedMountIndex(item),
    arc: resolvedArc,
    powerCost,
    displayPowerCost,
    displayRange: getDisplayRange(item),
    showUse,
    loaded: getWeaponLoadedState(actor, item),
    descriptionText: stripHtml(getDescription(item)),
    descriptionHtml: getDescription(item),
    componentState: getComponentState(actor, item)
  };
  return data;
}

function presentBuckets(buckets, actor) {
  const output = {};
  for (const [key, arr] of Object.entries(buckets ?? {})) {
    output[key] = Array.isArray(arr) ? arr.map(item => presentItem(item, actor)) : arr;
  }
  return output;
}


function getCargoEntries(actor) {
  const sheetState = getSheetState(actor);
  return Array.isArray(sheetState?.cargo?.entries) ? foundry.utils.deepClone(sheetState.cargo.entries) : [];
}

function normalizeCargoEntry(entry, index = 0) {
  const qty = Math.max(0, Number(entry?.qty ?? 0));
  const weightEach = Math.max(0, Number(entry?.weightEach ?? entry?.tonsEach ?? 0));
  const weightUnitRaw = String(entry?.weightUnit ?? (entry?.tonsEach != null ? "tons" : "lbs")).trim().toLowerCase();
  const weightUnit = weightUnitRaw === "tons" ? "tons" : "lbs";
  const totalWeight = qty * weightEach;
  const totalTons = weightUnit === "tons" ? totalWeight : (totalWeight / 2000);
  const totalDisplay = weightUnit === "tons" ? `${totalWeight} tons` : `${totalWeight} lbs`;
  return {
    id: String(entry?.id ?? `cargo-${index + 1}`),
    name: String(entry?.name ?? "").trim(),
    qty,
    weightEach,
    weightUnit,
    totalWeight,
    totalTons,
    totalDisplay,
    notes: String(entry?.notes ?? "").trim()
  };
}


function formatTreasuryNumber(value) {
  return Math.round(Number(value ?? 0)).toLocaleString();
}

function getStartingShipBaseline() {
  // Baseline is baked into the curve directly — no separate addition needed.
  return 0;
}

function getIdealWealthAnchors() {
  // Full per-level ideal net-worth curve (liquid balance + ship resale value).
  // Derived from the Cannons & Chaos economic model:
  //   - T1 levels 1–5, T2 levels 6–10, T3 levels 11–15, T4 levels 16–20
  //   - 80% quest income / 20% salvage income split
  //   - Savings target includes next-tier upgrade cost; T3 target adds 225k Christmas fund
  //   - Ship value component uses mid-fitted cost at each tier
  //   - Net worth = liquid shards + current ship's fitted value
  const CURVE = [
       85500,  // Level  1  T1
      113000,  // Level  2  T1
      140500,  // Level  3  T1
      168000,  // Level  4  T1
      195500,  // Level  5  T1
      346738,  // Level  6  T2
      396476,  // Level  7  T2
      446214,  // Level  8  T2
      495952,  // Level  9  T2
      545690,  // Level 10  T2
      846647,  // Level 11  T3
      998103,  // Level 12  T3
     1149560,  // Level 13  T3
     1301016,  // Level 14  T3
     1452472,  // Level 15  T3
     1805472,  // Level 16  T4
     1815472,  // Level 17  T4
     1825472,  // Level 18  T4
     1835472,  // Level 19  T4
     1845472   // Level 20  T4
  ];
  return CURVE.map((wealth, i) => ({ level: i + 1, wealth }));
}

function getTierAccessProjection(actualWealth, avgPerLevel = 0) {
  // Readiness thresholds = net upgrade cost (new ship minus old ship recovery).
  // Liquid balance needed to pull the trigger on an upgrade.
  const thresholds = [
    { tier: 1, label: "Tier I Ready",    wealth: 58000   },
    { tier: 2, label: "Tier II Ready",   wealth: 137500  },
    { tier: 3, label: "Tier III Ready",  wealth: 248690  },
    { tier: 4, label: "Tier IV Ready",   wealth: 532282  }
  ];

  let currentTier = thresholds[0];
  for (const entry of thresholds) {
    if (actualWealth >= entry.wealth) currentTier = entry;
  }

  const next = thresholds.find(entry => actualWealth < entry.wealth);
  if (!next) {
    return {
      label: "Tier IV Ready",
      sublabel: "Current wealth is at or above the Tier IV campaign-readiness threshold."
    };
  }

  const needed = Math.max(0, next.wealth - actualWealth);
  const currentLabel = currentTier?.tier ? `Currently sustaining Tier ${currentTier.tier}.` : "";

  if (!(avgPerLevel > 0)) {
    return {
      label: next.label,
      sublabel: `${currentLabel} Need ${formatTreasuryNumber(needed)} more shards for campaign-ready access.`
    };
  }

  const levelsTo = Math.max(1, Math.ceil(needed / Math.max(1, avgPerLevel)));
  return {
    label: next.label,
    sublabel: `${currentLabel} Projected in ~${levelsTo} level${levelsTo === 1 ? "" : "s"} at the observed income rate.`
  };
}

function getCollapseRiskAdvisor({ balance = 0, shipValue = 0 } = {}) {
  if (!(shipValue > 0)) {
    return {
      label: "Unknown",
      cls: "unknown",
      sublabel: "Assign a treasury ship to estimate replacement risk."
    };
  }

  // Tier brackets based on fitted ship costs: T1≤58k, T2≤159.5k, T3≤309k, T4>309k
  const tier = shipValue <= 58000 ? 1 : shipValue <= 159500 ? 2 : shipValue <= 309000 ? 3 : 4;
  // Replacement floor = net upgrade cost (what you need liquid to buy in to this tier)
  const replacementFloor = { 1: 58000, 2: 137500, 3: 248690, 4: 532282 }[tier];
  // Fallback floor = minimum to drop down one tier
  const fallbackFloor    = { 1: 58000, 2: 58000,  3: 137500, 4: 248690 }[tier];
  // Guild charter recovery: 60% of ship value back on loss
  const charterBuffer = Math.round(balance + (shipValue * 0.60));

  if (balance >= replacementFloor) {
    return {
      label: "Stable",
      cls: "oncurve",
      sublabel: `Liquid treasury alone covers a same-tier replacement floor of ${formatTreasuryNumber(replacementFloor)}.`
    };
  }
  if (charterBuffer >= replacementFloor) {
    return {
      label: "Managed",
      cls: "ahead",
      sublabel: `With a Guild Charter-style recovery buffer, same-tier replacement remains plausible.`
    };
  }
  if (charterBuffer >= fallbackFloor) {
    return {
      label: "Exposed",
      cls: "behind",
      sublabel: `A loss likely forces a down-tier replacement unless income improves.`
    };
  }
  return {
    label: "Critical",
    cls: "behind",
    sublabel: `Even with charter assumptions, the party may not afford a viable replacement hull.`
  };
}

function interpolateIdealWealth(level) {
  const numericLevel = Math.max(1, Math.min(20, Math.round(Number(level ?? 1) || 1)));
  const anchors = getIdealWealthAnchors();
  // Curve now has an explicit entry per level — no interpolation needed.
  const entry = anchors.find(a => a.level === numericLevel);
  if (entry) return entry.wealth;
  // Fallback: clamp to nearest end
  if (numericLevel <= anchors[0].level) return anchors[0].wealth;
  return anchors[anchors.length - 1].wealth;
}

function classifyTreasuryIncomeRows(ledgerAsc) {
  const rows = Array.isArray(ledgerAsc) ? ledgerAsc : [];
  const questRows = [];
  const salvageRows = [];
  const allPositive = [];
  const questPattern = /(quest|contract|bounty|objective|reward|payment|payout|job|mission)/i;
  const salvagePattern = /(salvage|scrap|chop|wreck|charter recovery|insurance payout|guild recovery)/i;

  for (const row of rows) {
    const amount = Number(row?.amount ?? 0);
    if (!(amount > 0)) continue;
    allPositive.push(row);
    const label = `${row?.source ?? ""} ${row?.type ?? ""}`;
    if (salvagePattern.test(label)) salvageRows.push(row);
    if (questPattern.test(label)) questRows.push(row);
  }

  return { questRows, salvageRows, allPositive };
}

function getEconomicCurveAdvisor({ treasury = null, ledgerAsc = [], currentLevel = null, netWorth = 0, balance = 0, shipValue = 0, avgPerLevel = 0 } = {}) {
  const numericLevel = Number.isFinite(Number(currentLevel)) ? Math.max(1, Math.min(20, Math.round(Number(currentLevel)))) : null;
  if (!numericLevel) {
    return {
      enabled: game.user?.isGM === true,
      mode: "Ideal Curve",
      statusLabel: "Unavailable",
      statusClass: "unknown",
      statusDelta: "—",
      expectedDisplay: "—",
      actualDisplay: formatTreasuryNumber(netWorth),
      nextTargetDisplay: "—",
      suggestedQuestRewardDisplay: "—",
      suggestedSalvageDisplay: "—",
      startingBaselineDisplay: formatTreasuryNumber(getStartingShipBaseline()),
      questSharePct: "65",
      notes: ["Add or assign PC levels in Foundry to enable ideal-curve guidance."],
      tierProjectionLabel: "—",
      tierProjectionSub: "—",
      collapseRiskLabel: "—",
      collapseRiskClass: "unknown",
      collapseRiskSub: "—",
      deltaRaw: 0,
      deltaPct: 0,
      expectedCurrent: 0,
      expectedNext: 0,
      suggestedQuestReward: 0,
      suggestedSalvage: 0
    };
  }

  const startingBaseline = getStartingShipBaseline();
  const expectedCurrent = interpolateIdealWealth(numericLevel);
  const expectedNext = interpolateIdealWealth(Math.min(20, numericLevel + 1));
  const actualWealth = Math.max(0, Number(netWorth ?? 0));
  const deltaRaw = Math.round(actualWealth - expectedCurrent);
  const deltaPct = expectedCurrent > 0 ? Math.round((deltaRaw / expectedCurrent) * 100) : 0;

  let statusLabel = "On Curve";
  let statusClass = "oncurve";
  if (deltaPct <= -25) {
    statusLabel = "Well Behind Curve";
    statusClass = "behind";
  } else if (deltaPct <= -10) {
    statusLabel = "Behind Curve";
    statusClass = "behind";
  } else if (deltaPct >= 25) {
    statusLabel = "Well Ahead of Curve";
    statusClass = "ahead";
  } else if (deltaPct >= 10) {
    statusLabel = "Ahead of Curve";
    statusClass = "ahead";
  }

  const { questRows, salvageRows, allPositive } = classifyTreasuryIncomeRows(ledgerAsc);
  const totalPositive = allPositive.reduce((sum, row) => sum + Math.max(0, Number(row?.amount ?? 0)), 0);
  const totalSalvage = salvageRows.reduce((sum, row) => sum + Math.max(0, Number(row?.amount ?? 0)), 0);
  let salvageShare = totalPositive > 0 ? (totalSalvage / totalPositive) : 0.20;
  if (!Number.isFinite(salvageShare) || salvageShare <= 0) salvageShare = 0.20;
  salvageShare = Math.max(0.10, Math.min(0.35, salvageShare));
  const questShare = 1 - salvageShare;

  // Smooth the quest suggestion across ~3 quests this level rather than dumping
  // the entire next-level gap into one reward. The party earns back to the curve
  // within a single level, not across multiple levels.
  const QUESTS_PER_LEVEL = 3;
  const neededGain = Math.max(0, expectedNext - actualWealth);
  const rawPerQuest = neededGain * questShare / QUESTS_PER_LEVEL;

  // Model ideal: what one quest should pay if the party is perfectly on curve.
  // = per-level gain × questShare ÷ QUESTS_PER_LEVEL
  const idealPerQuest = Math.max(1, (expectedNext - expectedCurrent) * questShare / QUESTS_PER_LEVEL);

  // Floor: never below 50% of model ideal (rewards feel normal when slightly ahead).
  // Ceiling: never above 200% of model ideal (prevents shock numbers when far behind).
  const suggestedQuestReward = Math.max(0, Math.round(
    Math.max(idealPerQuest * 0.5, Math.min(idealPerQuest * 2.0, rawPerQuest))
  ));

  // Salvage is a single-event haul suggestion — not divided across quests.
  const suggestedSalvage = Math.max(0, Math.round(neededGain * salvageShare));

  const observedQuestAvg = questRows.length
    ? Math.round(questRows.reduce((sum, row) => sum + Math.max(0, Number(row?.amount ?? 0)), 0) / questRows.length)
    : 0;
  const observedSalvageAvg = salvageRows.length
    ? Math.round(totalSalvage / salvageRows.length)
    : 0;

  const tierProjection = getTierAccessProjection(actualWealth, avgPerLevel);
  const collapseRisk = getCollapseRiskAdvisor({ balance, shipValue });

  const notes = [];
  notes.push(`Baseline mode: Ideal curve. Adaptive tuning can be layered in later.`);
  notes.push(`Ideal curve reflects: 80% quest income, 20% salvage, ~2 combats/level, T4 includes 225k outfitting fund.`);
  notes.push(`Expected total wealth at level ${numericLevel}: ${formatTreasuryNumber(expectedCurrent)} shards.`);
  notes.push(`Target total wealth by level ${Math.min(20, numericLevel + 1)}: ${formatTreasuryNumber(expectedNext)} shards.`);
  notes.push(`Quest reward suggestion is per-quest, smoothed across ~3 quests this level. Floor: 50% of model ideal. Ceiling: 200% of model ideal.`);
  if (questRows.length || salvageRows.length) {
    notes.push(`Observed income mix: ${Math.round(questShare * 100)}% quest / ${Math.round(salvageShare * 100)}% salvage.`);
  } else {
    notes.push(`No observed income mix yet — using model default of 80% quest / 20% salvage.`);
  }
  if (observedQuestAvg > 0) notes.push(`Observed average quest-sized payout: ${formatTreasuryNumber(observedQuestAvg)} shards.`);
  if (observedSalvageAvg > 0) notes.push(`Observed average salvage payout: ${formatTreasuryNumber(observedSalvageAvg)} shards.`);
  if (neededGain <= 0) notes.push(`Current net worth already meets or exceeds the next level's ideal target.`);

  return {
    enabled: game.user?.isGM === true,
    mode: "Ideal Curve",
    statusLabel,
    statusClass,
    statusDelta: `${deltaRaw >= 0 ? "+" : "−"}${formatTreasuryNumber(Math.abs(deltaRaw))} (${deltaPct >= 0 ? "+" : ""}${deltaPct}%)`,
    expectedDisplay: formatTreasuryNumber(expectedCurrent),
    actualDisplay: formatTreasuryNumber(actualWealth),
    nextTargetDisplay: formatTreasuryNumber(expectedNext),
    suggestedQuestRewardDisplay: formatTreasuryNumber(suggestedQuestReward),
    suggestedSalvageDisplay: formatTreasuryNumber(suggestedSalvage),
    startingBaselineDisplay: formatTreasuryNumber(startingBaseline),
    questSharePct: String(Math.round(questShare * 100)),
    notes,
    tierProjectionLabel: tierProjection.label,
    tierProjectionSub: tierProjection.sublabel,
    collapseRiskLabel: collapseRisk.label,
    collapseRiskClass: collapseRisk.cls,
    collapseRiskSub: collapseRisk.sublabel,
    deltaRaw,
    deltaPct,
    expectedCurrent,
    expectedNext,
    suggestedQuestReward,
    suggestedSalvage,
    observedQuestAvgDisplay: observedQuestAvg > 0 ? formatTreasuryNumber(observedQuestAvg) : "—",
    observedSalvageAvgDisplay: observedSalvageAvg > 0 ? formatTreasuryNumber(observedSalvageAvg) : "—"
  };
}

export function getCurrentPartyLevel() {
  const pcs = game.actors.filter(a => a?.type === "character" && a?.hasPlayerOwner);
  if (!pcs.length) return null;

  const levels = pcs
    .map(a => Number(a.system?.details?.level ?? 0))
    .filter(level => Number.isFinite(level) && level > 0);

  if (!levels.length) return null;
  return Math.round(levels.reduce((sum, level) => sum + level, 0) / levels.length);
}

export function getTreasuryData(actor) {
  const sheetState = getSheetState(actor);
  const treasury = foundry.utils.deepClone(sheetState?.treasury ?? {});
  return {
    balance: Math.round(Number(treasury.balance ?? 0)),
    startLevel: Number.isFinite(Number(treasury.startLevel)) ? Number(treasury.startLevel) : null,
    linkedShipUuid: String(treasury.linkedShipUuid ?? actor?.uuid ?? ""),
    ledger: Array.isArray(treasury.ledger) ? treasury.ledger : []
  };
}

export function getPrimaryTreasuryShipUuid() {
  return String(game.settings.get(MODULE_ID, "primaryTreasuryShipUuid") ?? "").trim();
}

export async function getPrimaryTreasuryShipActor() {
  const uuid = getPrimaryTreasuryShipUuid();
  if (!uuid) return null;
  try {
    const actor = await fromUuid(uuid);
    return actor?.documentName === "Actor" ? actor : null;
  } catch (err) {
    console.warn(`${MODULE_ID} | Failed to resolve primary treasury ship`, err);
    return null;
  }
}

export async function setPrimaryTreasuryShip(actorOrUuid) {
  const uuid = String(actorOrUuid?.uuid ?? actorOrUuid ?? "").trim();
  await game.settings.set(MODULE_ID, "primaryTreasuryShipUuid", uuid);
  return uuid;
}

export async function ensureTreasuryState(actor) {
  const sheetState = foundry.utils.deepClone(getSheetState(actor) ?? {});
  sheetState.treasury ??= {};
  sheetState.treasury.balance = Math.round(Number(sheetState.treasury.balance ?? 0));
  sheetState.treasury.startLevel = Number.isFinite(Number(sheetState.treasury.startLevel))
    ? Number(sheetState.treasury.startLevel)
    : null;
  sheetState.treasury.linkedShipUuid = String(sheetState.treasury.linkedShipUuid ?? actor?.uuid ?? "");
  sheetState.treasury.ledger = Array.isArray(sheetState.treasury.ledger) ? sheetState.treasury.ledger : [];

  if (!sheetState.treasury.startLevel) {
    const partyLevel = getCurrentPartyLevel();
    if (partyLevel) sheetState.treasury.startLevel = partyLevel;
  }

  await actor.setFlag(MODULE_ID, "sheetState", sheetState);
  return sheetState.treasury;
}

export function buildTreasuryTransaction(actor, treasury, {
  amount = 0,
  source = "Manual Adjustment",
  type = "manual",
  notes = "",
  timestamp = Date.now(),
  balanceAfter = null,
  shipUuid = null
} = {}) {
  const numericAmount = Math.round(Number(amount ?? 0));
  const nextBalance = balanceAfter == null
    ? Math.round(Number(treasury?.balance ?? 0) + numericAmount)
    : Math.round(Number(balanceAfter ?? 0));

  return {
    id: `txn-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
    amount: numericAmount,
    source: String(source ?? "Manual Adjustment").trim() || "Manual Adjustment",
    type: String(type ?? "manual").trim() || "manual",
    timestamp: Number(timestamp ?? Date.now()),
    balanceAfter: nextBalance,
    shipUuid: String(shipUuid ?? actor?.uuid ?? ""),
    notes: String(notes ?? "").trim()
  };
}

async function setTreasuryData(actor, treasury) {
  const sheetState = foundry.utils.deepClone(getSheetState(actor) ?? {});
  sheetState.treasury = {
    balance: Math.round(Number(treasury?.balance ?? 0)),
    startLevel: Number.isFinite(Number(treasury?.startLevel)) ? Number(treasury.startLevel) : null,
    linkedShipUuid: String(treasury?.linkedShipUuid ?? actor?.uuid ?? ""),
    ledger: Array.isArray(treasury?.ledger) ? treasury.ledger : []
  };
  await actor.setFlag(MODULE_ID, "sheetState", sheetState);
  return sheetState.treasury;
}

export async function addTreasuryTransaction(actor, {
  amount = 0,
  source = "Manual Adjustment",
  type = "manual",
  notes = ""
} = {}) {
  if (!actor) throw new Error("Treasury transaction requires an actor.");

  const treasury = await ensureTreasuryState(actor);
  const nextTreasury = foundry.utils.deepClone(treasury ?? {});
  nextTreasury.balance = Math.round(Number(nextTreasury.balance ?? 0));
  nextTreasury.startLevel = Number.isFinite(Number(nextTreasury.startLevel)) ? Number(nextTreasury.startLevel) : null;
  nextTreasury.linkedShipUuid = String(nextTreasury.linkedShipUuid ?? actor.uuid ?? "");
  nextTreasury.ledger = Array.isArray(nextTreasury.ledger) ? nextTreasury.ledger : [];

  const transaction = buildTreasuryTransaction(actor, nextTreasury, {
    amount,
    source,
    type,
    notes
  });

  nextTreasury.balance = transaction.balanceAfter;
  nextTreasury.ledger.push(transaction);

  await setTreasuryData(actor, nextTreasury);
  return transaction;
}

export async function transferTreasuryToShip(sourceActor, targetActor, {
  clearSource = false,
  logTransfer = true,
  notes = "",
  setAsPrimary = false
} = {}) {
  if (!sourceActor || !targetActor) throw new Error("Treasury transfer requires both a source actor and a target actor.");
  if (String(sourceActor.uuid) === String(targetActor.uuid)) throw new Error("Source and target ships must be different actors.");

  const sourceTreasury = foundry.utils.deepClone(await ensureTreasuryState(sourceActor));
  await ensureTreasuryState(targetActor);

  const transferred = {
    balance: Math.round(Number(sourceTreasury.balance ?? 0)),
    startLevel: Number.isFinite(Number(sourceTreasury.startLevel)) ? Number(sourceTreasury.startLevel) : null,
    linkedShipUuid: String(targetActor.uuid ?? ""),
    ledger: Array.isArray(sourceTreasury.ledger) ? foundry.utils.deepClone(sourceTreasury.ledger) : []
  };

  if (logTransfer) {
    transferred.ledger.push(buildTreasuryTransaction(targetActor, transferred, {
      amount: 0,
      source: `Treasury transferred from ${sourceActor.name}`,
      type: "transfer",
      notes: String(notes ?? "").trim(),
      balanceAfter: transferred.balance,
      shipUuid: targetActor.uuid
    }));
  }

  await setTreasuryData(targetActor, transferred);

  const currentPrimaryUuid = getPrimaryTreasuryShipUuid();
  if (setAsPrimary || (clearSource && currentPrimaryUuid && String(currentPrimaryUuid) === String(sourceActor.uuid))) {
    await setPrimaryTreasuryShip(targetActor);
  }

  if (clearSource) {
    const clearedSource = {
      balance: 0,
      startLevel: transferred.startLevel,
      linkedShipUuid: String(sourceActor.uuid ?? ""),
      ledger: []
    };
    await setTreasuryData(sourceActor, clearedSource);
  }

  return {
    sourceActor,
    targetActor,
    treasury: transferred,
    clearedSource: clearSource === true
  };
}

function clampTreasury(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function getNestedNumeric(source, path) {
  let current = source;
  for (const key of path) {
    current = current?.[key];
    if (current == null) return null;
  }
  const n = Number(current);
  return Number.isFinite(n) ? n : null;
}

function parseShardValueFromText(text) {
  const cleaned = stripHtml(text ?? "");
  if (!cleaned) return null;

  const patterns = [
    /(?:cost|price|value|worth)\s*[:\-]?\s*(\d[\d,]*)\s*shards?/i,
    /(\d[\d,]*)\s*shards?/i
  ];

  for (const pattern of patterns) {
    const match = cleaned.match(pattern);
    if (!match) continue;
    const n = Number(String(match[1]).replace(/,/g, ""));
    if (Number.isFinite(n)) return n;
  }

  return null;
}

function collectDeepStringValues(value, out = [], depth = 0) {
  if (depth > 6 || value == null) return out;
  if (typeof value === "string") {
    out.push(value);
    return out;
  }
  if (Array.isArray(value)) {
    for (const entry of value) collectDeepStringValues(entry, out, depth + 1);
    return out;
  }
  if (typeof value === "object") {
    for (const entry of Object.values(value)) collectDeepStringValues(entry, out, depth + 1);
  }
  return out;
}

function findTreasuryNumericFallback(source, path = [], depth = 0) {
  if (depth > 5 || source == null) return null;

  if (typeof source === "number") {
    const last = String(path[path.length - 1] ?? "").toLowerCase();
    const joined = path.map(part => String(part).toLowerCase()).join(".");
    const looksRelevant = /(price|cost|value|worth|shard)/i.test(joined)
      && !/(power|hp|hit|damage|range|level|action|crew|speed|movement|armor|ac|max|min|quantity|ammo|charge|use|threshold|capacity|tonnage|weight)/i.test(joined);
    if (looksRelevant && Number.isFinite(source) && source >= 0) return source;
    if (["price", "cost", "value", "worth", "shards", "shardvalue", "shardcost"].includes(last) && Number.isFinite(source) && source >= 0) return source;
    return null;
  }

  if (typeof source !== "object") return null;

  for (const [key, value] of Object.entries(source)) {
    const result = findTreasuryNumericFallback(value, [...path, key], depth + 1);
    if (result != null) return result;
  }

  return null;
}

export function getTreasuryItemValue(item) {
  const directPaths = [
    ["flags", CNC_MODULE_ID, "costShards"],
    ["flags", CNC_MODULE_ID, "priceShards"],
    ["flags", MODULE_ID, "costShards"],
    ["flags", MODULE_ID, "priceShards"],
    ["system", "price", "value"],
    ["system", "price", "shards"],
    ["system", "price"],
    ["system", "cost", "value"],
    ["system", "cost", "shards"],
    ["system", "cost"],
    ["system", "details", "price", "value"],
    ["system", "details", "price"],
    ["system", "details", "cost", "value"],
    ["system", "details", "cost"],
    ["system", "details", "value"],
    ["system", "attributes", "price", "value"],
    ["system", "attributes", "price"],
    ["system", "attributes", "cost", "value"],
    ["system", "attributes", "cost"],
    ["system", "value", "value"],
    ["system", "value"],
    ["system", "shardValue"],
    ["system", "shardCost"],
    ["price", "value"],
    ["price", "shards"],
    ["price"],
    ["cost", "value"],
    ["cost", "shards"],
    ["cost"],
    ["value", "value"],
    ["value"],
    ["flags", MODULE_ID, "price"],
    ["flags", MODULE_ID, "cost"],
    ["flags", MODULE_ID, "value"],
    ["flags", CNC_MODULE_ID, "price"],
    ["flags", CNC_MODULE_ID, "cost"],
    ["flags", CNC_MODULE_ID, "value"]
  ];

  let zeroCandidate = null;
  for (const path of directPaths) {
    const n = getNestedNumeric(item, path);
    if (n == null) continue;
    if (n > 0) return n;
    if (n === 0 && zeroCandidate == null) zeroCandidate = 0;
  }

  const recursiveNumeric = findTreasuryNumericFallback(item?.system);
  if (recursiveNumeric != null) {
    if (recursiveNumeric > 0) return recursiveNumeric;
    if (recursiveNumeric === 0 && zeroCandidate == null) zeroCandidate = 0;
  }

  return zeroCandidate ?? 0;
}

export function getTreasuryHullValue(actor, hull = null) {
  const resolvedHull = hull ?? getHullData(actor);
  const directPaths = [
    ["system", "attributes", "price", "value"],
    ["system", "attributes", "price"],
    ["system", "price", "value"],
    ["system", "price"],
    ["system", "details", "price"],
    ["system", "details", "cost"],
    ["price", "value"],
    ["price"],
    ["cost", "value"],
    ["cost"],
    ["stats", "price"],
    ["stats", "cost"],
    ["stats", "costShards"],
    ["frame", "price"],
    ["frame", "cost"],
    ["frame", "costShards"],
    ["value"],
    ["flags", CNC_MODULE_ID, "price"],
    ["flags", CNC_MODULE_ID, "cost"],
    ["flags", CNC_MODULE_ID, "costShards"]
  ];

  let zeroCandidate = null;
  for (const source of [actor, resolvedHull]) {
    if (!source) continue;
    for (const path of directPaths) {
      const n = getNestedNumeric(source, path);
      if (n == null) continue;
      if (n > 0) return n;
      if (n === 0 && zeroCandidate == null) zeroCandidate = 0;
    }
  }

  return zeroCandidate ?? 0;
}

export function getShipValueBreakdown(actor, { hull = null, remainingOnly = false } = {}) {
  const resolvedHull = hull ?? getHullData(actor);
  const classified = classifyInstalledItems(Array.from(actor?.items ?? []), resolvedHull);
  const installedComponents = [
    ...(classified.helm ?? []),
    ...(classified.powerCore ?? []),
    ...(classified.engine ?? []),
    ...(classified.utility ?? []),
    ...(classified.weapon ?? [])
  ];

  const includedItems = [];
  const excludedItems = [];
  let componentValue = 0;

  for (const item of installedComponents) {
    const state = getComponentState(actor, item);
    const isDestroyed = state?.state === "destroyed";
    if (remainingOnly && isDestroyed) {
      excludedItems.push(item);
      continue;
    }

    const value = Math.max(0, Number(getTreasuryItemValue(item) ?? 0));
    componentValue += value;
    includedItems.push({ item, value, state });
  }

  const hullValue = Math.max(0, Math.round(Number(getTreasuryHullValue(actor, resolvedHull) ?? 0)));
  const totalValue = Math.max(0, Math.round(hullValue + componentValue));

  return {
    hullValue,
    componentValue: Math.max(0, Math.round(componentValue)),
    totalValue,
    includedItems,
    excludedItems,
    includedCount: includedItems.length,
    excludedCount: excludedItems.length,
    remainingOnly
  };
}

function getTreasuryShipValue(actor, hull = null) {
  return getShipValueBreakdown(actor, { hull, remainingOnly: false }).totalValue;
}

function getSalvageCondition(rollTotal) {
  const total = Math.max(1, Math.min(6, Number(rollTotal ?? 0)));
  if (total <= 2) {
    return { label: "Drifting Wreck", multiplier: 0.35 };
  }
  if (total <= 5) {
    return { label: "Broken Hull", multiplier: 0.25 };
  }
  return { label: "Catastrophic Explosion", multiplier: 0.10 };
}

export async function calculateSalvageOutcome(actor, { rollTotal = null, roll = null, source = null, notes = "" } = {}) {
  if (!actor) throw new Error("Salvage calculation requires an actor.");

  let resolvedRoll = roll ?? null;
  if (!resolvedRoll) {
    resolvedRoll = await (new Roll("1d6")).evaluate({ async: true });
  }

  const total = Number(rollTotal ?? resolvedRoll?.total ?? 0);
  const condition = getSalvageCondition(total);
  const shipValue = getShipValueBreakdown(actor, { remainingOnly: true });
  const recoveredShards = Math.max(0, Math.floor(shipValue.totalValue * condition.multiplier));

  return {
    actor,
    roll: resolvedRoll,
    rollTotal: total,
    condition: condition.label,
    multiplier: condition.multiplier,
    hullValue: shipValue.hullValue,
    componentValue: shipValue.componentValue,
    totalShipValue: shipValue.totalValue,
    includedComponentCount: shipValue.includedCount,
    destroyedComponentCount: shipValue.excludedCount,
    recoveredShards,
    source: String(source ?? `Salvage: ${actor.name}`).trim() || `Salvage: ${actor.name}`,
    type: "salvage",
    notes: String(notes ?? "").trim()
  };
}

export async function salvageShipToTreasury(actor, { source = null, notes = "", createChatMessage = false, whisper = null } = {}) {
  const result = await calculateSalvageOutcome(actor, { source, notes });
  const depositActor = await getPrimaryTreasuryShipActor() ?? actor;
  const transaction = await addTreasuryTransaction(depositActor, {
    amount: result.recoveredShards,
    source: result.source,
    type: result.type,
    notes: result.notes
  });

  result.transaction = transaction;
  result.depositActor = depositActor;

  if (createChatMessage) {
    const lines = [
      `<div class="cnc-salvage-card" style="font-family:monospace; border:1px solid #46ffd9; padding:10px; background:rgba(4,7,15,0.92); color:#ffffff;">`,
      `<h2 style="color:#ff2fae; margin:0 0 8px 0;">SALVAGE OPERATION COMPLETE</h2>`,
      `<hr>`,
      `<b>Target:</b> ${foundry.utils.escapeHTML(actor.name)}<br>`,
      `<b>Destruction Roll:</b> ${result.rollTotal} (1d6)<br>`,
      `<b>Condition:</b> ${result.condition}<br>`,
      `<b>Salvage Efficiency:</b> ${Math.round(result.multiplier * 100)}%<br>`,
      `<hr>`,
      `<b>Hull Value:</b> ${formatTreasuryNumber(result.hullValue)} shards<br>`,
      `<b>Remaining Components:</b> ${formatTreasuryNumber(result.componentValue)} shards<br>`,
      `<b>Total Salvage Value:</b> ${formatTreasuryNumber(result.totalShipValue)} shards<br>`,
      `<b>Components Counted:</b> ${formatTreasuryNumber(result.includedComponentCount)}`,
      result.destroyedComponentCount > 0 ? `<br><b>Destroyed Components Excluded:</b> ${formatTreasuryNumber(result.destroyedComponentCount)}` : "",
      `<hr>`,
      `<h3 style="color:#46ffd9; margin:8px 0 0 0;">Recovered: ${formatTreasuryNumber(result.recoveredShards)} shards</h3>`,
      `<div style="margin-top:6px; color:#8fffe0;"><b>Deposited To:</b> ${foundry.utils.escapeHTML(depositActor.name)}</div>`,
      `</div>`
    ];

    await ChatMessage.create({
      content: lines.join(""),
      whisper: Array.isArray(whisper) && whisper.length ? whisper : undefined
    });
  }

  return result;
}


export async function calculateRecoveryCharterQuote(actor, { treasuryActor = null, rate = 0.10 } = {}) {
  if (!actor) throw new Error("Recovery charter calculation requires an actor.");

  const shipValue = getShipValueBreakdown(actor, { remainingOnly: false });
  const charterRate = Math.max(0, Number(rate ?? 0.10));
  const charterCost = Math.max(0, Math.round(shipValue.totalValue * charterRate));

  let resolvedTreasuryActor = treasuryActor ?? null;
  if (!resolvedTreasuryActor) {
    resolvedTreasuryActor = await getPrimaryTreasuryShipActor() ?? actor;
  }

  let treasuryBalance = null;
  if (resolvedTreasuryActor) {
    const treasury = await ensureTreasuryState(resolvedTreasuryActor);
    treasuryBalance = Math.max(0, Math.round(Number(treasury?.balance ?? 0)));
  }

  return {
    actor,
    treasuryActor: resolvedTreasuryActor,
    hullValue: shipValue.hullValue,
    componentValue: shipValue.componentValue,
    totalShipValue: shipValue.totalValue,
    charterRate,
    charterCost,
    treasuryBalance,
    affordable: treasuryBalance == null ? null : treasuryBalance >= charterCost
  };
}

export async function createRecoveryCharterQuote(actor, { treasuryActor = null, createChatMessage = false, whisper = null, preferPrimary = true } = {}) {
  const resolvedTreasuryActor = treasuryActor ?? ((preferPrimary ? await getPrimaryTreasuryShipActor() : null) ?? actor);
  const result = await calculateRecoveryCharterQuote(actor, { treasuryActor: resolvedTreasuryActor, rate: 0.10 });

  if (createChatMessage) {
    const affordabilityLine = result.treasuryBalance == null
      ? ""
      : `<br><b>Treasury Balance:</b> ${formatTreasuryNumber(result.treasuryBalance)} shards<br><b>Affordability:</b> ${result.affordable ? "Affordable" : "Insufficient Funds"}`;

    const content = [
      `<div class="cnc-charter-card" style="font-family:monospace; line-height:1.6; border:1px solid #46ffd9; padding:10px; background:rgba(4,7,15,0.92); color:#ffffff;">`,
      `<h2 style="margin:0 0 8px 0; color:#ff2fae;">GUILD RECOVERY CHARTER QUOTE</h2>`,
      `<p style="margin:0 0 6px 0;"><strong>Ship:</strong> ${foundry.utils.escapeHTML(actor.name)}</p>`,
      `<p style="margin:0 0 6px 0;"><strong>Quote Against Treasury:</strong> ${foundry.utils.escapeHTML(result.treasuryActor?.name ?? actor.name)}</p>`,
      `<p style="margin:0;"><strong>Hull Value:</strong> ${formatTreasuryNumber(result.hullValue)} shards<br>`,
      `<strong>Installed Component Value:</strong> ${formatTreasuryNumber(result.componentValue)} shards<br>`,
      `<strong>Total Ship and Loadout Value:</strong> ${formatTreasuryNumber(result.totalShipValue)} shards<br>`,
      `<strong>Charter Rate:</strong> ${Math.round(result.charterRate * 100)}%${affordabilityLine}</p>`,
      `<hr>`,
      `<h3 style="margin:8px 0 0 0; color:#46ffd9;">Quoted Cost: ${formatTreasuryNumber(result.charterCost)} shards</h3>`,
      `</div>`
    ].join("");

    const chatData = { content };
    if (Array.isArray(whisper) && whisper.length) {
      chatData.whisper = whisper;
    }
    await ChatMessage.create(chatData);
  }

  return result;
}

export async function calculateRecoveryCharterPayout(actor, { rate = 0.60 } = {}) {
  if (!actor) throw new Error("Recovery charter payout calculation requires an actor.");

  const shipValue = getShipValueBreakdown(actor, { remainingOnly: true });
  const payoutRate = Math.max(0, Number(rate ?? 0.60));
  const payoutAmount = Math.max(0, Math.round(shipValue.totalValue * payoutRate));

  return {
    actor,
    hullValue: shipValue.hullValue,
    componentValue: shipValue.componentValue,
    totalShipValue: shipValue.totalValue,
    includedComponentCount: shipValue.includedCount,
    destroyedComponentCount: shipValue.excludedCount,
    payoutRate,
    payoutAmount,
    source: `Recovery Charter: ${actor.name}`,
    type: "recovery",
    notes: ""
  };
}

export async function claimRecoveryCharterPayout(actor, { rate = 0.60 } = {}) {
  return calculateRecoveryCharterPayout(actor, { rate });
}

export async function createRecoveryCharterPayoutCard(actor, { createChatMessage = false, whisper = null } = {}) {
  const result = await calculateRecoveryCharterPayout(actor, { rate: 0.60 });

  if (createChatMessage) {
    const content = [
      `<div class="cnc-charter-payout-card" style="font-family:monospace; line-height:1.6; border:1px solid #46ffd9; padding:10px; background:rgba(4,7,15,0.92); color:#ffffff;">`,
      `<h2 style="margin:0 0 8px 0; color:#ff2fae;">GUILD RECOVERY CHARTER PAYOUT</h2>`,
      `<p style="margin:0 0 6px 0;"><strong>Ship:</strong> ${foundry.utils.escapeHTML(actor.name)}</p>`,
      `<p style="margin:0;"><strong>Hull Value:</strong> ${formatTreasuryNumber(result.hullValue)} shards<br>`,
      `<strong>Remaining Component Value:</strong> ${formatTreasuryNumber(result.componentValue)} shards<br>`,
      `<strong>Total Recoverable Value:</strong> ${formatTreasuryNumber(result.totalShipValue)} shards<br>`,
      `<strong>Payout Rate:</strong> ${Math.round(result.payoutRate * 100)}%<br>`,
      `<strong>Components Counted:</strong> ${formatTreasuryNumber(result.includedComponentCount)}`,
      result.destroyedComponentCount > 0 ? `<br><strong>Destroyed Components Excluded:</strong> ${formatTreasuryNumber(result.destroyedComponentCount)}` : "",
      `</p>`,
      `<hr>`,
      `<h3 style="margin:8px 0 0 0; color:#46ffd9;">Payout Awarded: ${formatTreasuryNumber(result.payoutAmount)} shards</h3>`,
      `<p style="margin:8px 0 0 0; color:#ffffff;">This payout is informational only and is not deposited into treasury automatically.</p>`,
      `</div>`
    ].join("");

    const chatData = { content };
    if (Array.isArray(whisper) && whisper.length) {
      chatData.whisper = whisper;
    }
    result.message = await ChatMessage.create(chatData);
  }

  return result;
}

export function getRecoveryPayoutMessageData(message) {
  return foundry.utils.deepClone(message?.flags?.[MODULE_ID]?.recoveryPayout ?? null);
}

export async function claimRecoveryPayoutFromMessage(message) {
  const payoutData = getRecoveryPayoutMessageData(message);
  if (!payoutData) throw new Error("Message does not contain recovery payout data.");
  if (payoutData.claimed) throw new Error("This payout has already been claimed.");

  const actor = await fromUuid(payoutData.actorUuid);
  const treasuryActor = await fromUuid(payoutData.treasuryActorUuid);
  if (!actor || actor.documentName !== "Actor") throw new Error("Could not resolve the insured ship for this payout.");
  if (!treasuryActor || treasuryActor.documentName !== "Actor") throw new Error("Could not resolve the treasury ship for this payout.");

  const freshMessage = game.messages.get(message.id);
  const freshData = getRecoveryPayoutMessageData(freshMessage);
  if (!freshData || freshData.claimed) throw new Error("This payout has already been claimed.");

  const result = await claimRecoveryCharterPayout(actor, { treasuryActor, rate: 0.60 });
  await freshMessage.setFlag(MODULE_ID, "recoveryPayout.claimed", true);
  await freshMessage.setFlag(MODULE_ID, "recoveryPayout.claimedAt", Date.now());
  await freshMessage.setFlag(MODULE_ID, "recoveryPayout.claimedBy", game.user?.id ?? null);

  return result;
}


const CHOP_SHOP_CONFIG_KEY = "chopShopConfig";

function getChopShopTierData(shopTier = "established") {
  const tiers = {
    backalley: { key: "backalley", label: "Back-Alley Shop", rating: 2 },
    established: { key: "established", label: "Established Ring", rating: 4 },
    elite: { key: "elite", label: "Elite Operation", rating: 6 }
  };
  return tiers[String(shopTier ?? "established").toLowerCase()] ?? tiers.established;
}

function getChopShopDcForTier(tier) {
  return { 1: 12, 2: 14, 3: 16, 4: 18 }[Number(tier ?? 1)] ?? 12;
}

function getChopShopTimeDays(_item) {
  return 1;
}

function getChopShopCategory(item) {
  const type = getResolvedComponentType(item);
  if (type === "powerCore") return "Power Core";
  if (type === "helm") return "Helm";
  if (type === "engine") return "Engine";
  if (type === "weapon") return "Weapon";
  return "Utility";
}

function isChopShopPowerCore(item) {
  return getResolvedComponentType(item) === "powerCore";
}

function getNaturalD20Result(roll) {
  try {
    const d20 = roll?.dice?.find?.(die => Number(die.faces ?? 0) === 20);
    return d20?.results?.[0]?.result ?? null;
  } catch {
    return null;
  }
}

export function getChopShopComponents(actor, { includeDestroyed = false } = {}) {
  if (!actor) return [];
  const resolvedHull = getHullData(actor);
  const classified = classifyInstalledItems(Array.from(actor.items ?? []), resolvedHull);
  const installedComponents = [
    ...(classified.helm ?? []),
    ...(classified.powerCore ?? []),
    ...(classified.engine ?? []),
    ...(classified.utility ?? []),
    ...(classified.weapon ?? [])
  ];

  return installedComponents
    .map(item => {
      const value = Math.max(0, Number(getTreasuryItemValue(item) ?? 0));
      const state = getComponentState(actor, item);
      const destroyed = state?.state === "destroyed";
      return { item, value, state, destroyed };
    })
    .filter(entry => entry.value > 0)
    .filter(entry => includeDestroyed || !entry.destroyed)
    .sort((a, b) => {
      const catA = getChopShopCategory(a.item);
      const catB = getChopShopCategory(b.item);
      if (catA !== catB) return catA.localeCompare(catB);
      return String(a.item?.name ?? "").localeCompare(String(b.item?.name ?? ""));
    });
}

function getChopShopPotentialReturns(cost, powerCore = false) {
  const value = Math.max(0, Number(cost ?? 0));
  return powerCore
    ? {
      botched: 0,
      rough: Math.floor(value * 0.30),
      clean: Math.floor(value * 0.50),
      precision: Math.floor(value * 0.65),
      exceptional: Math.floor(value * 0.80)
    }
    : {
      botched: Math.floor(value * 0.20),
      rough: Math.floor(value * 0.35),
      clean: Math.floor(value * 0.50),
      precision: Math.floor(value * 0.65),
      exceptional: Math.floor(value * 0.80)
    };
}

function getChopShopOutcome({ total = 0, natural = null, dc = 12, cost = 0, powerCore = false } = {}) {
  const margin = Number(total ?? 0) - Number(dc ?? 12);
  const numericCost = Math.max(0, Number(cost ?? 0));

  if (powerCore) {
    if (natural === 20) return { label: "Exceptional Extraction", pct: 0.80, shards: Math.floor(numericCost * 0.80), defect: null };
    if (margin >= 5) return { label: "Precision Extraction", pct: 0.65, shards: Math.floor(numericCost * 0.65), defect: null };
    if (margin >= 0) return { label: "Extracted", pct: 0.50, shards: Math.floor(numericCost * 0.50), defect: null };
    if (margin <= -5) return { label: "Destroyed", pct: 0, shards: 0, defect: "Destroyed during extraction" };
    return { label: "Cracked", pct: 0.30, shards: Math.floor(numericCost * 0.30), defect: "Core casing cracked" };
  }

  if (natural === 20) return { label: "Exceptional Extraction", pct: 0.80, shards: Math.floor(numericCost * 0.80), defect: null };
  if (margin >= 5) return { label: "Precision Extraction", pct: 0.65, shards: Math.floor(numericCost * 0.65), defect: null };
  if (margin >= 0) return { label: "Clean Extraction", pct: 0.50, shards: Math.floor(numericCost * 0.50), defect: null };
  if (margin <= -5) return { label: "Botched Extraction", pct: 0.20, shards: Math.floor(numericCost * 0.20), defect: "Major extraction damage" };
  return { label: "Rough Extraction", pct: 0.35, shards: Math.floor(numericCost * 0.35), defect: "Minor extraction damage" };
}

export async function calculateChopShopOutcome(actor, item, { shopTier = "established", roll = null } = {}) {
  if (!actor) throw new Error("Chop shop calculation requires a ship actor.");
  if (!item) throw new Error("Chop shop calculation requires a component item.");

  const shop = getChopShopTierData(shopTier);
  const tier = Math.max(1, Number(getResolvedComponentTier(item) ?? 1));
  const dc = getChopShopDcForTier(tier);
  const cost = Math.max(0, Number(getTreasuryItemValue(item) ?? 0));
  const powerCore = isChopShopPowerCore(item);
  const timeDays = getChopShopTimeDays(item);
  const resolvedRoll = roll ?? await (new Roll(`1d20 + ${shop.rating}`)).evaluate({ async: true });
  const natural = getNaturalD20Result(resolvedRoll);
  const outcome = getChopShopOutcome({ total: resolvedRoll.total, natural, dc, cost, powerCore });

  return {
    actor,
    item,
    shop,
    cost,
    tier,
    dc,
    powerCore,
    timeDays,
    roll: resolvedRoll,
    natural,
    outcome,
    shardsRecovered: Math.max(0, Number(outcome.shards ?? 0)),
    category: getChopShopCategory(item),
    state: getComponentState(actor, item)
  };
}

function formatChopShopDuration(days) {
  const n = Math.max(0, Number(days ?? 0));
  return `${n} day${n === 1 ? "" : "s"}`;
}

function buildChopShopResultCard(result) {
  const defectText = result.outcome?.defect ? `<div><strong>Defect:</strong> ${foundry.utils.escapeHTML(result.outcome.defect)}</div>` : "";
  return [
    `<div class="cnc-chop-result-card" style="font-family:monospace; line-height:1.6; border:1px solid #46ffd9; padding:10px; background:rgba(4,7,15,0.92); color:#ffffff;">`,
    `<h2 style="margin:0 0 8px 0; color:#ff2fae;">CHOP SHOP PROCESSING COMPLETE</h2>`,
    `<p style="margin:0 0 6px 0;"><strong>Ship:</strong> ${foundry.utils.escapeHTML(result.actor?.name ?? "Unknown Ship")}</p>`,
    `<p style="margin:0 0 6px 0;"><strong>Component:</strong> ${foundry.utils.escapeHTML(result.item?.name ?? "Unknown Component")}</p>`,
    `<p style="margin:0;"><strong>Shop:</strong> ${foundry.utils.escapeHTML(result.shop.label)}<br>`,
    `<strong>Category:</strong> ${foundry.utils.escapeHTML(result.category)}<br>`,
    `<strong>Tier DC:</strong> ${result.dc}<br>`,
    `<strong>Roll:</strong> ${result.roll.total} vs DC ${result.dc}${result.natural ? ` (natural ${result.natural})` : ""}<br>`,
    `<strong>Outcome:</strong> ${foundry.utils.escapeHTML(result.outcome.label)}<br>`,
    `<strong>Component Value:</strong> ${formatTreasuryNumber(result.cost)} shards<br>`,
    `<strong>Time Required:</strong> ${formatChopShopDuration(result.timeDays)}</p>`,
    defectText,
    `<hr>`,
    `<h3 style="margin:8px 0 0 0; color:#46ffd9;">Recovered: ${formatTreasuryNumber(result.shardsRecovered)} shards</h3>`,
    `<p style="margin:8px 0 0 0; color:#ffffff;"><em>This component has been removed from the ship and fenced through black-market channels. No treasury deposit is made automatically.</em></p>`,
    `</div>`
  ].join("");
}

function buildChopShopBatchJournalHtml(actor, shop, results) {
  const totalShards = results.reduce((sum, entry) => sum + Math.max(0, Number(entry.shardsRecovered ?? 0)), 0);
  const totalDays = results.reduce((sum, entry) => sum + Math.max(0, Number(entry.timeDays ?? 0)), 0);
  const rows = results.map(entry => {
    const naturalText = entry.natural ? ` (nat ${entry.natural})` : "";
    return `<tr>
      <td style="padding:8px 10px; border-bottom:1px solid rgba(255,255,255,0.08); color:#ffffff; white-space:nowrap;">${foundry.utils.escapeHTML(entry.item?.name ?? "Unknown")}</td>
      <td style="padding:8px 10px; border-bottom:1px solid rgba(255,255,255,0.08); color:#ffffff; text-align:center; white-space:nowrap;">${entry.roll.total}${naturalText}</td>
      <td style="padding:8px 10px; border-bottom:1px solid rgba(255,255,255,0.08); color:#ffffff; white-space:nowrap;">${foundry.utils.escapeHTML(entry.outcome.label)}</td>
      <td style="padding:8px 10px; border-bottom:1px solid rgba(255,255,255,0.08); color:#46ffd9; text-align:right; white-space:nowrap;">${formatTreasuryNumber(entry.shardsRecovered)}</td>
      <td style="padding:8px 10px; border-bottom:1px solid rgba(255,255,255,0.08); color:#ffffff; text-align:right; white-space:nowrap;">${formatChopShopDuration(entry.timeDays)}</td>
    </tr>`;
  }).join("");

  return [
    `<section style="font-family:monospace; line-height:1.5; background:#0a0f1d; color:#ffffff; border:1px solid #46ffd9; padding:16px;">`,
    `<h1 style="margin:0 0 10px 0; color:#ff2fae; letter-spacing:0.06em;">CHOP SHOP BATCH PROCESSING COMPLETE</h1>`,
    `<p style="margin:0 0 12px 0; color:#ffffff;"><strong>Ship:</strong> ${foundry.utils.escapeHTML(actor?.name ?? "Unknown Ship")}<br><strong>Shop:</strong> ${foundry.utils.escapeHTML(shop.label)}</p>`,
    `<div style="overflow-x:auto; border:1px solid rgba(70,255,217,0.25); background:#10182c;">`,
    `<table style="width:100%; min-width:760px; border-collapse:collapse; font-size:13px; background:#10182c; color:#ffffff;">`,
    `<thead style="background:#18233c; color:#8fffe0;"><tr><th style="text-align:left; padding:8px 10px; border-bottom:1px solid rgba(70,255,217,0.35);">Component</th><th style="text-align:center; padding:8px 10px; border-bottom:1px solid rgba(70,255,217,0.35);">Roll</th><th style="text-align:left; padding:8px 10px; border-bottom:1px solid rgba(70,255,217,0.35);">Outcome</th><th style="text-align:right; padding:8px 10px; border-bottom:1px solid rgba(70,255,217,0.35);">Recovered</th><th style="text-align:right; padding:8px 10px; border-bottom:1px solid rgba(70,255,217,0.35);">Time</th></tr></thead>`,
    `<tbody>${rows}</tbody></table>`,
    `</div>`,
    `<hr style="margin:14px 0; border:none; border-top:1px solid rgba(70,255,217,0.35);">`,
    `<h3 style="margin:0; color:#46ffd9;">Total Recovered: ${formatTreasuryNumber(totalShards)} shards</h3>`,
    `<div style="margin-top:6px; color:#ffffff;"><strong>Total Time:</strong> ${formatChopShopDuration(totalDays)}</div>`,
    `</section>`
  ].join("");
}

async function createChopShopBatchJournalEntry(actor, shop, results) {
  const timestamp = new Date().toLocaleString();
  const name = `Chop Shop Batch Report — ${actor?.name ?? "Ship"} — ${timestamp}`;
  const html = buildChopShopBatchJournalHtml(actor, shop, results);
  return JournalEntry.create({
    name,
    pages: [{
      name: "Report",
      type: "text",
      text: { format: 1, content: html }
    }]
  });
}

async function getChopShopConfigDialog(existing = {}) {
  const currentTier = existing?.shopTier ?? "established";

  return new Promise(resolve => {
    new Dialog({
      title: "Select Chop Shop",
      content: `
        <form>
          <div class="form-group">
            <label>Chop Shop Tier</label>
            <select name="shopTier">
              <option value="backalley" ${currentTier === "backalley" ? "selected" : ""}>Back-Alley Shop</option>
              <option value="established" ${currentTier === "established" ? "selected" : ""}>Established Ring</option>
              <option value="elite" ${currentTier === "elite" ? "selected" : ""}>Elite Operation</option>
            </select>
          </div>
        </form>
      `,
      buttons: {
        ok: { label: "Open", callback: html => resolve({ shopTier: String(html.find('[name="shopTier"]').val() || "established") }) },
        cancel: { label: "Cancel", callback: () => resolve(null) }
      },
      default: "ok",
      close: () => resolve(null)
    }).render(true);
  });
}

async function confirmChopShopAction({ title = "Confirm Processing", body = "This will process the selected component.", shopLabel = "Established Ring" } = {}) {
  return new Promise(resolve => {
    new Dialog({
      title,
      content: `
        <div class="cs-confirm-root">
          <style>
            .chop-shop-confirm-dialog .window-content{ padding:0; overflow:hidden; background:transparent; }
            .chop-shop-confirm-dialog .dialog-content{ padding:0; margin:0; }
            .chop-shop-confirm-dialog form{ margin:0; }
            .chop-shop-confirm-dialog .dialog-buttons{ display:grid; grid-template-columns:1fr 1fr; gap:10px; padding:12px 16px 16px; border-top:1px solid rgba(255,47,174,0.35); background:linear-gradient(180deg, rgba(255,0,170,0.08), rgba(70,255,217,0.05)); box-shadow: inset 0 1px 0 rgba(70,255,217,0.08); }
            .chop-shop-confirm-dialog .dialog-buttons button{ margin:0; min-height:38px; border:1px solid rgba(255,79,207,0.45); border-radius:6px; background:linear-gradient(180deg, rgba(255,0,170,0.18), rgba(255,0,170,0.08)); color:#8fffe0; text-shadow:none; box-shadow:0 0 14px rgba(255,0,170,0.12), inset 0 0 10px rgba(255,255,255,0.03); }
            .chop-shop-confirm-dialog .dialog-buttons button:hover{ border-color:rgba(70,255,217,0.55); box-shadow:0 0 16px rgba(70,255,217,0.18), inset 0 0 10px rgba(255,255,255,0.04); }
            .cs-confirm-root{ position:relative; overflow:hidden; padding:16px; color:#8fffe0; font-family:monospace; background: radial-gradient(circle at 15% 15%, rgba(255,0,170,0.18), transparent 24%), radial-gradient(circle at 85% 20%, rgba(70,255,217,0.12), transparent 28%), linear-gradient(180deg, #080d1a 0%, #04070f 100%); }
            .cs-confirm-root::before{ content:""; position:absolute; inset:0; background: linear-gradient(rgba(255,0,200,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,0,200,0.08) 1px, transparent 1px); background-size:28px 28px; opacity:0.55; pointer-events:none; }
            .cs-confirm-panel{ position:relative; border:1px solid rgba(255,47,174,0.42); background:rgba(6,10,20,0.9); box-shadow:0 0 18px rgba(255,0,170,0.15), inset 0 0 20px rgba(70,255,217,0.04); padding:14px; }
            .cs-confirm-title{ margin:0 0 10px; color:#ff4fcf; font-size:18px; letter-spacing:1.2px; text-transform:uppercase; font-family:"Orbitron","Eurostile","Bank Gothic",monospace; }
            .cs-confirm-panel p{ position:relative; margin:0 0 10px; line-height:1.45; }
            .cs-confirm-panel p:last-child{ margin-bottom:0; }
            .cs-confirm-accent{ color:#ffffff; }
          </style>
          <div class="cs-confirm-panel">
            <h2 class="cs-confirm-title">${foundry.utils.escapeHTML(title)}</h2>
            <p class="cs-confirm-accent">${body}</p>
            <p><strong>Shop:</strong> ${foundry.utils.escapeHTML(shopLabel)}</p>
          </div>
        </div>
      `,
      buttons: {
        yes: { label: "Process", callback: () => resolve(true) },
        no: { label: "Cancel", callback: () => resolve(false) }
      },
      default: "no",
      close: () => resolve(false)
    }, { classes: ["chop-shop-confirm-dialog"], width: 520 }).render(true);
  });
}

export async function processChopShopComponent(actor, item, { shopTier = "established", createChatMessage = true } = {}) {
  const result = await calculateChopShopOutcome(actor, item, { shopTier });
  await actor.deleteEmbeddedDocuments("Item", [item.id]);
  if (createChatMessage) await ChatMessage.create({ content: buildChopShopResultCard(result) });
  return result;
}

export async function processAllChopShopComponents(actor, { shopTier = "established", createChatMessage = true } = {}) {
  const entries = getChopShopComponents(actor);
  const results = [];
  const idsToDelete = [];
  for (const entry of entries) {
    const result = await calculateChopShopOutcome(actor, entry.item, { shopTier });
    results.push(result);
    idsToDelete.push(entry.item.id);
  }
  if (idsToDelete.length) await actor.deleteEmbeddedDocuments("Item", idsToDelete);
  const shop = getChopShopTierData(shopTier);
  let journalEntry = null;
  if (createChatMessage && results.length) {
    journalEntry = await createChopShopBatchJournalEntry(actor, shop, results);
    const uuid = journalEntry?.uuid;
    const title = foundry.utils.escapeHTML(journalEntry?.name ?? "Chop Shop Batch Report");
    const journalLink = uuid ? `@UUID[${uuid}]{${title}}` : title;
    await ChatMessage.create({
      content: `<div class="cnc-chop-batch-notice" style="font-family:monospace; line-height:1.6; border:1px solid #46ffd9; padding:10px; background:rgba(4,7,15,0.92); color:#ffffff;">`
        + `<h2 style="margin:0 0 8px 0; color:#ff2fae;">CHOP SHOP BATCH PROCESSING COMPLETE</h2>`
        + `<p style="margin:0 0 8px 0; color:#ffffff;"><strong>Ship:</strong> ${foundry.utils.escapeHTML(actor?.name ?? "Unknown Ship")}<br><strong>Shop:</strong> ${foundry.utils.escapeHTML(shop.label)}</p>`
        + `<p style="margin:0 0 8px 0; color:#ffffff;"><strong>Total Recovered:</strong> ${formatTreasuryNumber(results.reduce((sum, entry) => sum + Math.max(0, Number(entry.shardsRecovered ?? 0)), 0))} shards<br><strong>Total Time:</strong> ${formatChopShopDuration(results.reduce((sum, entry) => sum + Math.max(0, Number(entry.timeDays ?? 0)), 0))}</p>`
        + `<p style="margin:0; color:#ffffff;">Full breakdown saved to journal: ${journalLink}</p>`
        + `</div>`
    });
  }
  return {
    actor,
    shop,
    journalEntry,
    results,
    totalShards: results.reduce((sum, entry) => sum + Math.max(0, Number(entry.shardsRecovered ?? 0)), 0),
    totalDays: results.reduce((sum, entry) => sum + Math.max(0, Number(entry.timeDays ?? 0)), 0)
  };
}

function renderChopShopDialog(actor, config = { shopTier: "established" }) {
  const components = getChopShopComponents(actor);
  const shopData = getChopShopTierData(config?.shopTier);
  const sheetTreasury = getSheetState(actor)?.treasury ?? { balance: 0 };
  const treasuryTotal = Math.max(0, Number(sheetTreasury.balance ?? 0));
  const componentCount = components.length;
  const grossValue = components.reduce((sum, entry) => sum + entry.value, 0);
  const hullValue = Math.max(0, Number(getTreasuryHullValue(actor) ?? 0));
  const shipValue = getShipValueBreakdown(actor, { remainingOnly: false }).totalValue;
  const powerCores = components.filter(entry => isChopShopPowerCore(entry.item)).length;
  const totalTime = components.reduce((sum, entry) => sum + getChopShopTimeDays(entry.item), 0);
  const tierSpread = components.reduce((acc, entry) => {
    const t = Math.max(1, Number(getResolvedComponentTier(entry.item) ?? 1));
    acc[t] = (acc[t] || 0) + 1;
    return acc;
  }, {});
  const tierSummary = [1, 2, 3, 4].filter(t => tierSpread[t]).map(t => `T${t}: ${tierSpread[t]}`).join("  |  ") || "None";
  const projectedLow = components.reduce((sum, entry) => sum + getChopShopPotentialReturns(entry.value, isChopShopPowerCore(entry.item)).botched, 0);
  const projectedMid = components.reduce((sum, entry) => sum + getChopShopPotentialReturns(entry.value, isChopShopPowerCore(entry.item)).clean, 0);
  const projectedHigh = components.reduce((sum, entry) => sum + getChopShopPotentialReturns(entry.value, isChopShopPowerCore(entry.item)).precision, 0);

  const rows = components.map(entry => {
    const item = entry.item;
    const cost = entry.value;
    const tier = Math.max(1, Number(getResolvedComponentTier(item) ?? 1));
    const dc = getChopShopDcForTier(tier);
    const hp = entry.state;
    const hpText = hp ? `${hp.hpCurrent}/${hp.hpMax}` : "—";
    const hpPct = hp?.hpMax ? clampTreasury((hp.hpCurrent / hp.hpMax) * 100, 0, 100) : null;
    const ac = hp?.ac ?? parseComponentAc(item) ?? "—";
    const cat = getChopShopCategory(item);
    const core = isChopShopPowerCore(item);
    const returns = getChopShopPotentialReturns(cost, core);
    return `
      <div class="cs-row" data-item-id="${item.id}">
        <div class="cs-cell cs-name">
          <div class="cs-item-name">${foundry.utils.escapeHTML(item.name)}</div>
          <div class="cs-item-cat">${foundry.utils.escapeHTML(cat)}</div>
        </div>
        <div class="cs-cell cs-mini"><div class="cs-mini-label">Tier</div><div class="cs-mini-value">T${tier}</div></div>
        <div class="cs-cell cs-mini"><div class="cs-mini-label">DC</div><div class="cs-mini-value">${dc}</div></div>
        <div class="cs-cell cs-mini"><div class="cs-mini-label">Cost</div><div class="cs-mini-value">${formatTreasuryNumber(cost)}</div></div>
        <div class="cs-cell cs-mini"><div class="cs-mini-label">AC</div><div class="cs-mini-value">${ac}</div></div>
        <div class="cs-cell cs-hp">
          <div class="cs-mini-label">HP</div><div class="cs-mini-value">${hpText}</div>
          ${hpPct != null ? `<div class="cs-hpbar"><div class="cs-hpfill" style="width:${hpPct}%"></div></div>` : ""}
        </div>
        <div class="cs-cell cs-returns"><div class="cs-return-grid"><div><span>B:</span> ${formatTreasuryNumber(returns.botched)}</div><div><span>R:</span> ${formatTreasuryNumber(returns.rough)}</div><div><span>C:</span> ${formatTreasuryNumber(returns.clean)}</div><div><span>P:</span> ${formatTreasuryNumber(returns.precision)}</div><div><span>N20:</span> ${formatTreasuryNumber(returns.exceptional)}</div></div></div>
        <div class="cs-cell cs-action"><button type="button" class="cs-chop-btn" data-item-id="${item.id}">Process</button></div>
      </div>`;
  }).join("");

  const content = `
<div class="cs-root"><div class="cs-grid"></div><div class="cs-scan"></div><div class="cs-vignette"></div>
<div class="cs-header"><div class="cs-title">CHOP SHOP: ${foundry.utils.escapeHTML(actor.name)}</div><div class="cs-crystal-wrap"><svg class="cs-crystal" viewBox="0 0 100 100" aria-hidden="true"><polygon points="50,5 85,35 70,90 30,90 15,35" fill="#ff2fae"/></svg></div></div>
<div class="cs-main"><div class="cs-left"><div class="cs-value-panel"><div class="cs-value">${formatTreasuryNumber(treasuryTotal)}</div><div class="cs-label">SHARDS ON HAND</div></div>
<div class="cs-button-row"><button class="cs-process-all">Process All</button></div>
<div class="cs-button-row"><button class="cs-refresh">Refresh</button></div>
<div class="cs-button-row"><button class="cs-settings">Settings</button></div>
<div class="cs-button-row"><button class="cs-close">Close</button></div>
<div class="cs-stats-panel"><div class="cs-stat"><span>Chop Shop</span><span>${shopData.label}</span></div><div class="cs-stat"><span>Shop Rating</span><span>+${shopData.rating}</span></div><div class="cs-stat"><span>Ship Hull Value</span><span>${formatTreasuryNumber(hullValue)}</span></div><div class="cs-stat"><span>Ship Total Value</span><span>${formatTreasuryNumber(shipValue)}</span></div><div class="cs-stat"><span>Choppable Value</span><span>${formatTreasuryNumber(grossValue)}</span></div><div class="cs-stat"><span>Component Count</span><span>${formatTreasuryNumber(componentCount)}</span></div><div class="cs-stat"><span>Power Cores</span><span>${formatTreasuryNumber(powerCores)}</span></div><div class="cs-stat"><span>Projected Time</span><span>${formatChopShopDuration(totalTime)}</span></div><div class="cs-stat"><span>Tier Spread</span><span>${tierSummary}</span></div></div></div>
<div class="cs-center"><div class="cs-projections"><div class="cs-proj-title">PROJECTED RECOVERY</div><div class="cs-proj-grid"><div class="cs-proj-box"><div class="cs-proj-label">Botched Floor</div><div class="cs-proj-value">${formatTreasuryNumber(projectedLow)}</div></div><div class="cs-proj-box"><div class="cs-proj-label">Clean Average</div><div class="cs-proj-value">${formatTreasuryNumber(projectedMid)}</div></div><div class="cs-proj-box"><div class="cs-proj-label">Precision Ceiling</div><div class="cs-proj-value">${formatTreasuryNumber(projectedHigh)}</div></div></div></div>
<div class="cs-table-shell"><div class="cs-table-head"><div class="cs-head-name">Component</div><div class="cs-head-mini">Tier</div><div class="cs-head-mini">DC</div><div class="cs-head-mini">Cost</div><div class="cs-head-mini">AC</div><div class="cs-head-hp">HP</div><div class="cs-head-returns">Potential Returns</div><div class="cs-head-action">Action</div></div><div class="cs-table-body">${rows || `<div class="cs-empty">No choppable non-destroyed components with shard costs were found on this ship.</div>`}</div></div></div></div>
<style>
.cs-root{ position:relative; height:100%; min-height:100%; overflow:hidden; color:#8fffe0; font-family:monospace; background: radial-gradient(circle at 15% 15%, rgba(255,0,170,0.18), transparent 20%), radial-gradient(circle at 80% 20%, rgba(70,255,217,0.12), transparent 24%), radial-gradient(circle at 50% 100%, rgba(255,0,170,0.08), transparent 35%), linear-gradient(180deg, #080d1a 0%, #04070f 100%); }
.cs-grid{ position:absolute; inset:0; background: linear-gradient(rgba(255,0,200,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,0,200,0.08) 1px, transparent 1px); background-size:36px 36px; pointer-events:none; opacity:0.85; animation:csGridPulse 6s ease-in-out infinite alternate; }
@keyframes csGridPulse{ from{opacity:0.45;} to{opacity:0.9;} }
.cs-scan{ position:absolute; inset:0; background:linear-gradient(rgba(255,255,255,0.035) 50%, transparent 50%); background-size:100% 3px; animation:csScan 5s linear infinite; pointer-events:none; opacity:0.9; }
@keyframes csScan{ from{background-position:0 0;} to{background-position:0 180px;} }
.cs-vignette{ position:absolute; inset:0; box-shadow: inset 0 0 90px rgba(0,0,0,0.8); pointer-events:none; }
.cs-header{ position:relative; z-index:1; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,47,174,0.55); background:linear-gradient(180deg, rgba(255,0,170,0.10), rgba(255,0,170,0.02)); box-shadow: 0 0 20px rgba(255,0,170,0.10), inset 0 -1px 0 rgba(70,255,217,0.08); }
.cs-title{ font-size:24px; color:#ff4fcf; letter-spacing:1.8px; font-family:"Orbitron","Eurostile","Bank Gothic",monospace; text-transform:uppercase; text-shadow: 0 0 8px rgba(255,47,174,0.95), 0 0 18px rgba(255,0,170,0.6), 0 0 32px rgba(255,0,170,0.3); }
.cs-crystal{ width:32px; height:32px; filter: drop-shadow(0 0 8px #ff2fae) drop-shadow(0 0 18px rgba(255,0,170,0.8)) drop-shadow(0 0 30px rgba(255,0,170,0.45)); animation:csCrystalFlicker 1.6s infinite; }
@keyframes csCrystalFlicker{ 0%{transform:scale(1); opacity:1;} 20%{transform:scale(1.04); opacity:0.95;} 40%{transform:scale(0.98); opacity:1;} 60%{transform:scale(1.06); opacity:0.88;} 80%{transform:scale(1.01); opacity:1;} 100%{transform:scale(1.03); opacity:0.96;} }
.cs-main{ position:relative; z-index:1; display:grid; grid-template-columns: 360px 1fr; gap:18px; height:calc(100% - 58px); padding:16px; min-height:0; }
.cs-left{ display:flex; flex-direction:column; gap:10px; min-width:0; min-height:0; }
.cs-center{ display:flex; flex-direction:column; gap:14px; min-width:0; min-height:0; }
.cs-value-panel,.cs-stats-panel,.cs-table-shell,.cs-projections{ border:1px solid rgba(255,0,170,0.24); background: linear-gradient(180deg, rgba(255,0,170,0.05), rgba(70,255,217,0.03)), rgba(0,0,0,0.10); box-shadow: inset 0 0 30px rgba(255,0,170,0.06), 0 0 22px rgba(70,255,217,0.05); }
.cs-value-panel{ padding:14px; }
.cs-value{ font-size:52px; color:#ff2fae; font-family:"Cinzel Decorative","Cinzel","Garamond",serif; text-shadow: 0 0 8px #ff2fae, 0 0 18px rgba(255,0,170,0.7), 0 0 36px rgba(255,0,170,0.35); line-height:1; }
.cs-label{ margin-top:8px; font-size:12px; letter-spacing:1.2px; color:#8fffe0; opacity:0.9; }
.cs-button-row{ display:flex; gap:8px; flex-wrap:wrap; }
.cs-refresh,.cs-settings,.cs-close,.cs-chop-btn,.cs-process-all{ padding:9px 11px; background: linear-gradient(180deg, rgba(19,30,56,0.98), rgba(8,12,24,0.98)); border:1px solid rgba(70,255,217,0.55); color:#8fffe0; cursor:pointer; font-family:"Orbitron","Eurostile","Bank Gothic",monospace; letter-spacing:0.8px; transition: transform 0.12s ease, box-shadow 0.18s ease, border-color 0.18s ease, background 0.18s ease; width:100%; }
.cs-close{ border-color:rgba(255,47,174,0.6); color:#ff8ed0; }
.cs-chop-btn,.cs-process-all{ border-color:rgba(255,215,0,0.55); color:#ffd779; width:100%; }
.cs-refresh:hover,.cs-settings:hover{ transform:translateY(-1px); border-color:#46ffd9; box-shadow: 0 0 10px rgba(70,255,217,0.65), 0 0 24px rgba(70,255,217,0.22); }
.cs-close:hover{ transform:translateY(-1px); border-color:#ff2fae; box-shadow: 0 0 10px rgba(255,47,174,0.65), 0 0 24px rgba(255,47,174,0.22); }
.cs-chop-btn:hover,.cs-process-all:hover{ transform:translateY(-1px); border-color:#ffd779; box-shadow: 0 0 10px rgba(255,215,0,0.45), 0 0 24px rgba(255,215,0,0.18); }
.cs-stats-panel{ padding:12px; display:flex; flex-direction:column; gap:6px; min-height:0; }
.cs-stat{ display:flex; justify-content:space-between; gap:10px; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:4px; }
.cs-projections{ padding:12px; }
.cs-proj-title{ font-size:13px; letter-spacing:1.5px; color:#ff9fdb; margin-bottom:10px; font-family:"Orbitron","Eurostile","Bank Gothic",monospace; }
.cs-proj-grid{ display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap:10px; }
.cs-proj-box{ padding:10px; border:1px solid rgba(70,255,217,0.18); background:rgba(255,255,255,0.02); }
.cs-proj-label{ font-size:11px; opacity:0.8; margin-bottom:6px; }
.cs-proj-value{ font-size:18px; color:#46ffd9; text-shadow:0 0 10px rgba(70,255,217,0.25); }
.cs-table-shell{ display:flex; flex-direction:column; flex:1 1 auto; min-height:0; padding:10px; }
.cs-table-head{ display:grid; grid-template-columns: 2.3fr 0.7fr 0.7fr 1fr 0.7fr 1.1fr 2fr 1fr; gap:10px; padding:8px 10px; border:1px solid rgba(255,0,170,0.22); background:rgba(255,255,255,0.02); color:#ff9fdb; font-size:12px; letter-spacing:1px; font-family:"Orbitron","Eurostile","Bank Gothic",monospace; margin-bottom:8px; }
.cs-table-body{ min-height:0; overflow-y:auto; overflow-x:hidden; display:flex; flex-direction:column; gap:8px; padding-right:4px; }
.cs-table-body::-webkit-scrollbar{ width:8px; }
.cs-table-body::-webkit-scrollbar-track{ background:rgba(255,255,255,0.03); }
.cs-table-body::-webkit-scrollbar-thumb{ background:rgba(255,47,174,0.5); border-radius:4px; box-shadow:0 0 10px rgba(255,47,174,0.25); }
.cs-row{ display:grid; grid-template-columns: 2.3fr 0.7fr 0.7fr 1fr 0.7fr 1.1fr 2fr 1fr; gap:10px; align-items:center; padding:10px; border:1px solid rgba(70,255,217,0.18); background:rgba(255,255,255,0.02); }
.cs-row:hover{ border-color:rgba(70,255,217,0.4); box-shadow:0 0 16px rgba(70,255,217,0.08); }
.cs-cell{ min-width:0; }
.cs-item-name{ font-size:14px; color:#46ffd9; text-shadow:0 0 8px rgba(70,255,217,0.22); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.cs-item-cat{ font-size:11px; color:#ff9fdb; opacity:0.9; margin-top:3px; }
.cs-mini-label{ font-size:10px; opacity:0.72; margin-bottom:4px; text-transform:uppercase; letter-spacing:0.7px; }
.cs-mini-value{ font-size:16px; color:#8fffe0; }
.cs-hpbar{ width:100%; height:6px; margin-top:6px; background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.06); }
.cs-hpfill{ height:100%; background:linear-gradient(90deg, #ff4f7a, #ffd779, #46ffd9); box-shadow:0 0 8px rgba(70,255,217,0.22); }
.cs-return-grid{ display:grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap:4px 10px; font-size:11px; color:#8fffe0; }
.cs-return-grid span{ color:#ff9fdb; }
.cs-empty{ padding:16px; border:1px solid rgba(255,0,170,0.22); background:rgba(255,255,255,0.02); color:#8fffe0; }
.cs-root{ height:100%; }
.chop-shop-dialog .dialog-content{ height:100%; margin:0; padding:0; }
.chop-shop-dialog form{ height:100%; margin:0; }
.chop-shop-dialog .window-content{ padding:0 !important; overflow:hidden !important; background:transparent !important; }
.chop-shop-dialog .dialog-buttons{ display:none !important; }
@media (max-width: 1400px){ .cs-main{ grid-template-columns: 320px 1fr; } .cs-table-head,.cs-row{ grid-template-columns: 2fr 0.6fr 0.6fr 0.9fr 0.6fr 1fr 1.7fr 0.9fr; } .cs-value{ font-size:44px; } }
</style></div>`;

  const dialog = new Dialog({
    title: `Chop Shop: ${actor.name}`,
    content,
    buttons: {},
    render: html => {
      const app = html.closest(".app");
      if (app.length) app.css({ width: 1600, height: 920 });
      const windowContent = html.closest(".window-content");
      if (windowContent.length) windowContent.css({ padding: "0", overflow: "hidden", background: "transparent", height: "100%" });
      const dialogContent = html.closest(".dialog-content");
      if (dialogContent.length) dialogContent.css({ padding: "0", margin: "0", height: "100%" });
      const dialogForm = html.closest("form");
      if (dialogForm.length) dialogForm.css({ height: "100%", margin: "0" });
      const buttons = app.find(".dialog-buttons");
      if (buttons.length) buttons.css({ display: "none" });
      html.css({ height: "100%" });

      html.find(".cs-refresh").on("click", () => { dialog.close(); renderChopShopDialog(actor, config); });
      html.find(".cs-close").on("click", () => dialog.close());
      html.find(".cs-settings").on("click", async () => {
        dialog.close();
        const nextConfig = await getChopShopConfigDialog(config);
        if (!nextConfig) return renderChopShopDialog(actor, config);
        await game.user.setFlag(MODULE_ID, CHOP_SHOP_CONFIG_KEY, nextConfig);
        renderChopShopDialog(actor, nextConfig);
      });
      html.find(".cs-process-all").on("click", async () => {
        const approved = await confirmChopShopAction({
          title: "Process Entire Ship",
          body: `This will process ${componentCount} component${componentCount === 1 ? "" : "s"} from ${foundry.utils.escapeHTML(actor.name)} and remove them from the ship.`,
          shopLabel: shopData.label
        });
        if (!approved) return;
        await processAllChopShopComponents(actor, { shopTier: config.shopTier, createChatMessage: true });
        dialog.close();
        renderChopShopDialog(actor, config);
      });
      html.find(".cs-chop-btn").on("click", async ev => {
        const itemId = ev.currentTarget.dataset.itemId;
        const item = actor.items.get(itemId);
        if (!item) { ui.notifications.warn("That component is no longer on the ship."); dialog.close(); return renderChopShopDialog(actor, config); }
        const approved = await confirmChopShopAction({
          title: "Confirm Chop",
          body: `${foundry.utils.escapeHTML(item.name)} will be removed from the ship and fenced for shards.`,
          shopLabel: shopData.label
        });
        if (!approved) return;
        await processChopShopComponent(actor, item, { shopTier: config.shopTier, createChatMessage: true });
        dialog.close();
        renderChopShopDialog(actor, config);
      });
    }
  }, { width: 1600, height: 920, resizable: true, classes: ["chop-shop-dialog"] });

  dialog.render(true);
  return dialog;
}

export async function openChopShopForActor(actor, { config = null } = {}) {
  if (!actor || actor.type !== "vehicle") throw new Error("Chop shop requires a vehicle ship actor.");
  await ensureTreasuryState(actor);
  const savedConfig = config ?? foundry.utils.deepClone(game.user.getFlag(MODULE_ID, CHOP_SHOP_CONFIG_KEY) ?? { shopTier: "established" });
  const nextConfig = await getChopShopConfigDialog(savedConfig);
  if (!nextConfig) return null;
  await game.user.setFlag(MODULE_ID, CHOP_SHOP_CONFIG_KEY, nextConfig);
  return renderChopShopDialog(actor, nextConfig);
}

function getTreasuryCombatOutlook(actor, treasuryBalance, shipValue) {
  const hpValue = Math.max(0, Number(actor?.system?.attributes?.hp?.value ?? 0));
  const hpMax = Math.max(1, Number(actor?.system?.attributes?.hp?.max ?? hpValue ?? 1));
  const healthPct = clampTreasury(hpValue / hpMax, 0, 1);

  const items = Array.from(actor?.items ?? []).filter(item => {
    const type = getResolvedComponentType(item);
    return ["weapon", "engine", "utility", "helm", "powerCore"].includes(type);
  });

  let destroyed = 0;
  let damaged = 0;
  let total = 0;

  for (const item of items) {
    const st = getComponentState(actor, item);
    if (!st || Number(st.hpMax ?? 0) <= 0) continue;
    total += 1;
    if (st.state === "destroyed" || Number(st.hpCurrent ?? 0) <= 0) destroyed += 1;
    else if (Number(st.hpCurrent ?? 0) < Number(st.hpMax ?? 0)) damaged += 1;
  }

  const destroyedRatio = total ? destroyed / total : 0;
  const damagedRatio = total ? damaged / total : 0;

  let score = (healthPct * 0.72) + ((1 - destroyedRatio) * 0.2) + ((1 - damagedRatio) * 0.08);
  score = clampTreasury(score, 0, 1);

  let label = "Stable Uptrend";
  let cls = "good";
  if (score >= 0.85) {
    label = "Strong Uptrend";
    cls = "good";
  } else if (score >= 0.65) {
    label = "Moderate Uptrend";
    cls = "good";
  } else if (score >= 0.45) {
    label = "Uncertain Outlook";
    cls = "warn";
  } else if (score >= 0.25) {
    label = "Downward Pressure";
    cls = "bad";
  } else {
    label = "Severe Downtrend";
    cls = "bad";
  }

  return {
    label,
    cls,
    healthPct,
    destroyed,
    damaged,
    total,
    baselineNetWorth: Math.max(0, Number(treasuryBalance ?? 0) + Number(shipValue ?? 0))
  };
}

function buildTreasuryChartData(ledger, balance) {
  const ordered = [...(ledger ?? [])].sort((a, b) => Number(a.timestamp ?? 0) - Number(b.timestamp ?? 0));
  let running = 0;
  let values = ordered.map(entry => {
    running += Math.round(Number(entry.amount ?? 0));
    return running;
  });

  if (!values.length) values = [0, Math.max(0, Number(balance ?? 0))];
  if (values.length === 1) values = [0, values[0]];

  const first = values[0];
  const last = values[values.length - 1];
  const projection = values.map((_, i) => {
    if (values.length < 2) return last;
    return Math.round(first + ((last - first) * (i / (values.length - 1))));
  });

  return {
    values,
    projection,
    labels: values.map((_, i) => i + 1)
  };
}

function buildTreasuryCombatProjection(outlook) {
  const healthPct = clampTreasury(Number(outlook?.healthPct ?? 0), 0, 1);
  const destroyed = Math.max(0, Number(outlook?.destroyed ?? 0));
  const damaged = Math.max(0, Number(outlook?.damaged ?? 0));
  const total = Math.max(1, Number(outlook?.total ?? 0));
  const baseline = Math.max(1, Number(outlook?.baselineNetWorth ?? 1));
  const stability = clampTreasury((healthPct * 0.72) + ((1 - (destroyed / total)) * 0.20) + ((1 - (damaged / total)) * 0.08), 0, 1);

  let startMult = 0.95;
  let endMult = 1.08;

  if (stability >= 0.85) {
    startMult = 0.96;
    endMult = 1.16;
  } else if (stability >= 0.65) {
    startMult = 0.97;
    endMult = 1.08;
  } else if (stability >= 0.45) {
    startMult = 0.99;
    endMult = 1.01;
  } else if (stability >= 0.25) {
    startMult = 1.0;
    endMult = 0.78;
  } else {
    startMult = 1.0;
    endMult = 0.42;
  }

  const volatility = 1 - stability;
  const points = [];
  for (let i = 0; i < 8; i += 1) {
    const t = i / 7;
    const mult = startMult + ((endMult - startMult) * t);
    const wobble = Math.sin(i * 1.35) * baseline * 0.012 * volatility;
    points.push(Math.max(0, Math.round(baseline * mult + wobble)));
  }
  return points;
}

function prepareTreasuryContext(actor, hull = null) {
  const treasury = getTreasuryData(actor);
  const primaryTreasuryShipUuid = getPrimaryTreasuryShipUuid();
  const isPrimaryTreasuryShip = !!primaryTreasuryShipUuid && String(primaryTreasuryShipUuid) === String(actor?.uuid ?? "");
  const currentLevel = getCurrentPartyLevel();
  const ledgerAsc = [...treasury.ledger].sort((a, b) => Number(a.timestamp ?? 0) - Number(b.timestamp ?? 0));
  const ledgerDesc = [...ledgerAsc].reverse();

  const totalIncome = ledgerAsc
    .filter(row => Number(row.amount ?? 0) > 0)
    .reduce((sum, row) => sum + Number(row.amount ?? 0), 0);

  const totalLosses = ledgerAsc
    .filter(row => Number(row.amount ?? 0) < 0)
    .reduce((sum, row) => sum + Math.abs(Number(row.amount ?? 0)), 0);

  const positiveRows = ledgerAsc.filter(row => Number(row.amount ?? 0) > 0);
  const avgGain = positiveRows.length ? Math.round(totalIncome / positiveRows.length) : 0;
  const largestGain = ledgerAsc.length ? Math.max(...ledgerAsc.map(row => Number(row.amount ?? 0))) : 0;
  const largestLoss = ledgerAsc.length ? Math.min(...ledgerAsc.map(row => Number(row.amount ?? 0))) : 0;

  const firstBalance = ledgerAsc.length ? Number(ledgerAsc[0]?.balanceAfter ?? ledgerAsc[0]?.amount ?? 0) : 0;
  const growth = firstBalance !== 0
    ? Math.round(((Number(treasury.balance ?? 0) - firstBalance) / Math.abs(firstBalance)) * 100)
    : (Number(treasury.balance ?? 0) > 0 ? 100 : 0);

  const shipValue = getTreasuryShipValue(actor, hull);
  const netWorth = Number(treasury.balance ?? 0) + shipValue;

  const startLevel = treasury.startLevel ?? currentLevel ?? null;
  const levelsElapsed = (currentLevel && startLevel) ? Math.max(1, currentLevel - startLevel + 1) : 1;
  const avgPerLevel = Math.round(totalIncome / Math.max(1, levelsElapsed));

  const projectAtLevel = (targetLevel) => {
    if (!currentLevel || targetLevel <= currentLevel) return Number(treasury.balance ?? 0);
    return Number(treasury.balance ?? 0) + ((targetLevel - currentLevel) * avgPerLevel);
  };

  const chart = buildTreasuryChartData(ledgerAsc, treasury.balance);
  const combatOutlook = getTreasuryCombatOutlook(actor, treasury.balance, shipValue);
  combatOutlook.points = buildTreasuryCombatProjection(combatOutlook);
  const economicAdvisor = getEconomicCurveAdvisor({
    treasury,
    ledgerAsc,
    currentLevel,
    netWorth,
    balance: Number(treasury.balance ?? 0),
    shipValue,
    avgPerLevel
  });

  return {
    balance: Number(treasury.balance ?? 0),
    balanceDisplay: formatTreasuryNumber(treasury.balance),
    startLevel,
    linkedShipUuid: treasury.linkedShipUuid,
    primaryTreasuryShipUuid,
    isPrimaryTreasuryShip,
    treasuryOwnerLabel: isPrimaryTreasuryShip ? "Primary Treasury Ship" : (primaryTreasuryShipUuid ? "Secondary Treasury Ship" : "Local Treasury Ship"),
    currentLevel: currentLevel ?? "—",
    totalIncome,
    totalIncomeDisplay: formatTreasuryNumber(totalIncome),
    totalLosses,
    totalLossesDisplay: formatTreasuryNumber(totalLosses),
    avgGain,
    avgGainDisplay: formatTreasuryNumber(avgGain),
    largestGain,
    largestGainDisplay: formatTreasuryNumber(largestGain),
    largestLoss,
    largestLossDisplay: formatTreasuryNumber(largestLoss),
    growth,
    shipValue,
    shipValueDisplay: formatTreasuryNumber(shipValue),
    netWorth,
    netWorthDisplay: formatTreasuryNumber(netWorth),
    avgPerLevel,
    avgPerLevelDisplay: formatTreasuryNumber(avgPerLevel),
    projected10: formatTreasuryNumber(projectAtLevel(10)),
    projected15: formatTreasuryNumber(projectAtLevel(15)),
    projected20: formatTreasuryNumber(projectAtLevel(20)),
    transactionsLogged: ledgerAsc.length,
    chart,
    combatOutlook: {
      ...combatOutlook,
      hullIntegrity: Math.round(Number(combatOutlook.healthPct ?? 0) * 100)
    },
    economicAdvisor,
    ledger: ledgerDesc.map(row => {
      const amount = Math.round(Number(row.amount ?? 0));
      return {
        ...row,
        sign: amount >= 0 ? "+" : "",
        amountDisplay: formatTreasuryNumber(amount),
        cssClass: amount >= 0 ? "positive" : "negative",
        timestampDisplay: new Date(Number(row.timestamp ?? Date.now())).toLocaleString()
      };
    })
  };
}

export function prepareNavalContext(actor) {
  const hull = getHullData(actor);
  const sheetState = getSheetState(actor);
  const items = Array.from(actor?.items ?? []);
  const allClassifiedRaw = classifyItemsByFlag(items);
  const classifiedRaw = classifyInstalledItems(items, hull);
  const cargoEntries = getCargoEntries(actor).map((entry, index) => normalizeCargoEntry(entry, index));
  const cargoCapacityNumber = [
    hull?.stats?.cargoMaxTons,
    hull?.stats?.cargoCapacityTons,
    hull?.stats?.cargoCapacity,
    hull?.stats?.cargoMax,
    hull?.stats?.cargo,
    hull?.frame?.cargoMaxTons,
    hull?.frame?.cargoCapacityTons,
    hull?.frame?.cargoCapacity,
    hull?.frame?.cargoMax,
    hull?.frame?.cargo
  ].map(value => normalizeLimit(value, 0)).find(value => value > 0) ?? 0;
  const cargoUsedTons = cargoEntries.reduce((sum, entry) => sum + Number(entry.totalTons ?? 0), 0);
  const cargoRemaining = Math.max(0, cargoCapacityNumber - cargoUsedTons);
  const cargoPercent = cargoCapacityNumber > 0 ? Math.max(0, Math.min(100, (cargoUsedTons / cargoCapacityNumber) * 100)) : 0;

  const validation = buildValidationProfile(actor, classifiedRaw);
  const allClassified = presentBuckets(allClassifiedRaw, actor);
  const classified = presentBuckets(classifiedRaw, actor);

  const installedWeaponIds = new Set((hull?.installed?.weapons ?? []).map(w => w?.id).filter(Boolean));
  const assignedWeaponIds = new Set(Object.keys(sheetState?.battleArcAssignments ?? {}));
  const battleWeapons = items
    .filter(item =>
      getResolvedComponentType(item) === "weapon" &&
      (installedWeaponIds.has(item.id) || assignedWeaponIds.has(item.id))
    )
    .map(item => presentItem(item, actor));

  const repairComponentsRaw = [
    ...(classifiedRaw.helm ?? []),
    ...(classifiedRaw.powerCore ?? []),
    ...(classifiedRaw.engine ?? []),
    ...(classifiedRaw.utility ?? [])
  ];
  const repairComponents = repairComponentsRaw.map(item => presentItem(item, actor));

  const repairLists = {
    battle: repairComponents.filter(entry => {
      const st = entry?._cncResolved?.componentState ?? {};
      return st.state === "operational" && Number(st.hpCurrent ?? 0) > 0 && Number(st.hpCurrent ?? 0) < Number(st.hpMax ?? 0);
    }),
    post: repairComponents.filter(entry => {
      const st = entry?._cncResolved?.componentState ?? {};
      return (st.state === "operational" && Number(st.hpCurrent ?? 0) > 0 && Number(st.hpCurrent ?? 0) < Number(st.hpMax ?? 0))
        || st.state === "disabled";
    }),
    destroyed: repairComponents.filter(entry => {
      const st = entry?._cncResolved?.componentState ?? {};
      return st.state === "destroyed";
    }),
    hull: null
  };

  const system = actor?.system ?? {};
  const hpValue = Number(system?.attributes?.hp?.value ?? hull?.stats?.hp ?? 0);
  const hpMax = Number(system?.attributes?.hp?.max ?? hull?.stats?.hp ?? 0);
  const ac = Number(system?.attributes?.ac?.flat ?? system?.attributes?.ac?.value ?? hull?.stats?.ac ?? 0);

  if (hpValue < hpMax) {
    repairLists.hull = { current: hpValue, max: hpMax };
  }

  const componentRepairKits = repairLists.post.reduce((sum, entry) => {
    const st = entry?._cncResolved?.componentState ?? {};
    const missing = Math.max(0, Number(st.hpMax ?? 0) - Number(st.hpCurrent ?? 0));
    return sum + Math.ceil(missing / 50);
  }, 0);

  const hullRepairKits = hpMax > hpValue ? Math.ceil((hpMax - hpValue) / 50) : 0;
  const repairKits = componentRepairKits + hullRepairKits;
  const hullDockCost = hullRepairKits * 5;

  const combat = foundry.utils.mergeObject(
    {
      driftTokens: 0,
      powerPoints: 0,
      powerPointsMax: 0,
      spendAmount: 0,
      restoreAmount: 0,
      partyActions: 0,
      partyActionsMax: 0,
      fires: 0,
      crossingTheT: false,
      notes: ""
    },
    sheetState?.combat ?? {},
    { inplace: false }
  );

  const derivedShip = computeDerivedShipStats(actor, hull, classifiedRaw, combat);
  const shipValueBreakdown = getShipValueBreakdown(actor, { hull, remainingOnly: false });
  const hullSubtitle = getHullTierSubtitle(hull);
  combat.powerPointsMax = derivedShip.power.total;
  combat.powerPoints = Math.min(Number(combat.powerPoints ?? 0), derivedShip.power.total);
  const powerGlow = combat.powerPointsMax > 0
    ? Math.max(0, Math.min(1, Number(combat.powerPoints ?? 0) / Number(combat.powerPointsMax ?? 1)))
    : 0;
  const fireCount = Math.max(0, Number(combat.fires ?? 0));
  const fireGlow = Math.max(0, Math.min(1, fireCount / 6));
  combat.powerGlow = powerGlow.toFixed(3);
  combat.fireGlow = fireGlow.toFixed(3);
  let optionalFireRulesAutomation = false;
  try {
    optionalFireRulesAutomation = Boolean(game.settings?.get?.(MODULE_ID, "enableOptionalFireRulesAutomation"));
  } catch (_err) {
    optionalFireRulesAutomation = false;
  }
  combat.optionalFireRulesAutomation = optionalFireRulesAutomation;
  combat.firePenaltyWarning = optionalFireRulesAutomation && fireCount >= 3;
  combat.runawayFireWarning = optionalFireRulesAutomation && fireCount >= 4;
  const treasury = prepareTreasuryContext(actor, hull);
  const crewEntries = getCrewEntries(actor).map((entry, index) => {
    const actorId = String(entry?.actorId ?? "");
    const actorUuid = String(entry?.actorUuid ?? "");
    const linkedActor = actorId ? game.actors?.get?.(actorId) : null;
    const displayName = String(linkedActor?.name ?? entry?.name ?? "Crew Member");
    const displayImg = String(linkedActor?.img ?? entry?.img ?? "icons/svg/mystery-man.svg");
    const actorType = String(linkedActor?.type ?? entry?.actorType ?? "character");
    const levelValue = Number(linkedActor?.system?.details?.level ?? linkedActor?.system?.details?.cr ?? NaN);
    return {
      id: String(entry?.id ?? `crew-${index}`),
      actorId,
      actorUuid,
      name: displayName,
      img: displayImg,
      actorType,
      role: String(entry?.role ?? ""),
      levelDisplay: Number.isFinite(levelValue) && levelValue > 0 ? String(levelValue) : "—"
    };
  });
  const uniqueCrewKeys = new Set();
  for (const entry of crewEntries) {
    const actorId = String(entry?.actorId ?? "").trim();
    const actorUuid = String(entry?.actorUuid ?? "").trim();
    const nameKey = String(entry?.name ?? "").trim().toLowerCase();
    const key = actorId || actorUuid || (nameKey ? `name:${nameKey}` : `row:${entry?.id ?? uniqueCrewKeys.size}`);
    uniqueCrewKeys.add(key);
  }
  const uniqueCrewCount = uniqueCrewKeys.size;
  const derivedPartyActionsMax = Math.max(0, uniqueCrewCount * 5);
  combat.partyActionsMax = derivedPartyActionsMax;
  combat.partyActions = Math.max(0, Math.min(Number(combat.partyActions ?? derivedPartyActionsMax), derivedPartyActionsMax));

  return {
    cnc: getCncFlags(actor),
    hull,
    frame: hull?.frame ?? {},
    stats: hull?.stats ?? {},
    abilities: hull?.abilities ?? {},
    installedFromHull: hull?.installed ?? {},
    sheetState,
    combat,
    classified,
    allClassified,
    battleWeapons,
    repairLists,
    cargo: {
      entries: cargoEntries,
      capacity: `${cargoCapacityNumber} tons`,
      used: `${cargoUsedTons.toFixed(2).replace(/\.00$/, "")} tons`,
      remaining: `${cargoRemaining.toFixed(2).replace(/\.00$/, "")} tons`,
      percent: cargoPercent
    },
    crew: {
      entries: crewEntries,
      count: uniqueCrewCount,
      listedCount: crewEntries.length,
      required: Number(hull?.stats?.crewRequired ?? system?.crew?.quantity ?? 0),
      passengers: Number(hull?.stats?.passengerCapacity ?? system?.passengers?.quantity ?? 0)
    },
    treasury,
    validation,
    hullSubtitle,
    shipValue: {
      hullValue: shipValueBreakdown.hullValue,
      hullValueDisplay: formatTreasuryNumber(shipValueBreakdown.hullValue),
      componentValue: shipValueBreakdown.componentValue,
      componentValueDisplay: formatTreasuryNumber(shipValueBreakdown.componentValue),
      totalValue: shipValueBreakdown.totalValue,
      totalValueDisplay: formatTreasuryNumber(shipValueBreakdown.totalValue)
    },
    derivedShip,
    systemCounts: {
      helm: classifiedRaw.helm.length,
      powerCore: classifiedRaw.powerCore.length,
      engine: classifiedRaw.engine.length,
      utility: classifiedRaw.utility.length
    },
    derived: {
      isShip: isShipActor(actor),
      hp: { value: hpValue, max: hpMax },
      ac: derivedShip.ac.total || ac,
      turnRate: (derivedShip.turnRate.total || (hull?.stats?.turnRate ?? null)),
      driftTokens: Number(combat.driftTokens ?? 0),
      powerPoints: Number(combat.powerPoints ?? 0),
      powerPointsMax: Number(combat.powerPointsMax ?? 0),
      fires: Number(combat.fires ?? 0),
      hullPercent: hpMax > 0 ? Math.max(0, Math.min(100, Math.round((hpValue / hpMax) * 100))) : 0,
      hullState: (() => {
        const pct = hpMax > 0 ? Math.max(0, Math.min(100, Math.round((hpValue / hpMax) * 100))) : 0;
        if (pct <= 25) return "low";
        if (pct <= 60) return "mid";
        return "high";
      })(),
      counts: {
        helms: classifiedRaw.helm.length,
        powerCores: classifiedRaw.powerCore.length,
        engines: classifiedRaw.engine.length,
        utilities: classifiedRaw.utility.length,
        weapons: classifiedRaw.weapon.length
      },
      limits: validation.limits,
      tierCaps: validation.tierCaps,
      repairKits,
      hullDockCost
    }
  };
}

export function validateItemForSlot(actor, item, slot, currentBuckets = null) {
  const hull = getHullData(actor);
  const flaggedType = getComponentType(item);
  const componentType = getResolvedComponentType(item);

  if (!componentType) {
    return { ok: false, reason: `${item.name} could not be matched to a Cannons and Chaos component type.` };
  }

  if (componentType !== slot) {
    const source = flaggedType ? "tagged" : "classified";
    return { ok: false, reason: `${item.name} is ${source} as ${componentType}, not ${slot}.` };
  }

  const items = Array.from(actor?.items ?? []);
  const classified = currentBuckets ?? classifyInstalledItems(items, hull);
  const validation = buildValidationProfile(actor, classified);
  const currentCount = classified[slot]?.length ?? 0;
  const limit = validation.limits[slot];
  const installedIds = hullInstalledIdSet(hull);
  const alreadyAssigned = getItemCncFlags(item).installed === true || installedIds.has(item.id);

  if ((slot === "helm" || slot === "powerCore") && !alreadyAssigned && currentCount >= 1) {
    const existing = classified[slot]?.[0];
    return {
      ok: false,
      reason: `${actor.name} already has an installed ${slot === "powerCore" ? "power core" : "helm"}${existing ? ` (${existing.name})` : ""}. Remove it first.`
    };
  }

  if (!alreadyAssigned && currentCount >= limit) {
    const label = slot === "powerCore" ? "power core" : slot;
    return { ok: false, reason: `No open ${label} slots remain (${currentCount}/${limit}).` };
  }

  if (slot === "engine") {
    const usedMounts = new Set((classified.engine ?? []).map(e => Number(getResolvedMountIndex(e))).filter(Number.isFinite));
    let mountIndex = getResolvedMountIndex(item);

    if (mountIndex == null) {
      const maxMounts = normalizeLimit(hull?.frame?.engineMounts, limit);
      let found = null;
      for (let i = 1; i <= maxMounts; i++) {
        if (!usedMounts.has(i)) {
          found = i;
          break;
        }
      }
      if (found == null) {
        return { ok: false, reason: `No open engine mounts remain (${currentCount}/${limit}).` };
      }
      mountIndex = found;
    }

    const existingMount = (classified.engine ?? []).find(e =>
      e.id !== item.id && Number(getResolvedMountIndex(e)) === Number(mountIndex)
    );

    if (existingMount) {
      return {
        ok: false,
        reason: `Engine mount ${mountIndex} is already occupied by ${existingMount.name}. Remove it first.`
      };
    }
  }

  const tier = getResolvedComponentTier(item);
  const shipTier = getEffectiveShipTier(hull);

  if (slot === "weapon") {
    const frameCap = normalizeLimit(hull?.frame?.maxWeaponTier, 0);
    const effectiveCap = frameCap > 0 && shipTier > 0 ? Math.min(frameCap, shipTier) : (frameCap || shipTier);
    if (tier != null && effectiveCap > 0 && tier > effectiveCap) {
      return { ok: false, reason: `${item.name} is tier ${tier}, above the allowed weapon tier cap of ${effectiveCap}.` };
    }
  }

  if (slot === "utility") {
    const frameCap = normalizeLimit(hull?.frame?.maxUtilityTier, 0);
    const effectiveCap = frameCap > 0 && shipTier > 0 ? Math.min(frameCap, shipTier) : (frameCap || shipTier);
    if (tier != null && effectiveCap > 0 && tier > effectiveCap) {
      return { ok: false, reason: `${item.name} is tier ${tier}, above the allowed utility tier cap of ${effectiveCap}.` };
    }
  }

  if (slot === "powerCore") {
    const requiredTier = normalizeLimit(hull?.frame?.requiredPowerCoreTier, validation.tierCaps.powerCore);
    if (tier != null && requiredTier > 0 && tier < requiredTier) {
      return { ok: false, reason: `${item.name} is tier ${tier}, but this ship requires a power core of tier ${requiredTier} or higher.` };
    }
  }

  return { ok: true };
}

export async function markItemInstalled(actor, item, shouldInstall) {
  const hull = foundry.utils.deepClone(getHullData(actor) ?? {});
  hull.installed ??= { helm: null, powerCore: null, engines: [], weapons: [], utilities: [] };

  const componentType = getResolvedComponentType(item);
  let mountIndex = getResolvedMountIndex(item);

  if (shouldInstall && componentType === "engine" && mountIndex == null) {
    const installedEngines = hull.installed.engines ?? [];
    const usedMounts = new Set(installedEngines.map(e => Number(e.mountIndex)).filter(Number.isFinite));
    const maxMounts = normalizeLimit(hull?.frame?.engineMounts, installedEngines.length + 1);

    for (let i = 1; i <= maxMounts; i++) {
      if (!usedMounts.has(i)) {
        mountIndex = i;
        break;
      }
    }

    if (mountIndex != null) {
      await item.setFlag(CNC_MODULE_ID, "mountIndex", mountIndex);
    }
  }

  // API-path capacity warnings. The sheet UI hard-blocks via validateItemForSlot; calls that
  // bypass the sheet (e.g. HullGeneratorAPI or macro scripts) still get a console warning so
  // developers can catch over-installation during testing.
  if (shouldInstall && hull?.frame) {
    const frame = hull.frame;
    if (componentType === "weapon") {
      const cap = frame.weaponHardpoints ?? frame.weaponHardpointsMax;
      const current = (hull.installed.weapons ?? []).length;
      if (cap != null && current >= cap) {
        console.warn(
          `[cannons-and-chaos] markItemInstalled: "${item.name}" installed on "${actor.name}" ` +
          `exceeds weapon hardpoint capacity (${current}/${cap}). ` +
          `This hull's rolled hardpoints should be respected — use the sheet UI to enforce the limit.`
        );
      }
    } else if (componentType === "utility") {
      const cap = frame.utilityHardpoints ?? frame.utilityHardpointsMax;
      const current = (hull.installed.utilities ?? []).length;
      if (cap != null && current >= cap) {
        console.warn(
          `[cannons-and-chaos] markItemInstalled: "${item.name}" installed on "${actor.name}" ` +
          `exceeds utility hardpoint capacity (${current}/${cap}). ` +
          `This hull's rolled hardpoints should be respected — use the sheet UI to enforce the limit.`
        );
      }
    } else if (componentType === "engine") {
      const cap = frame.engineMounts;
      const current = (hull.installed.engines ?? []).length;
      if (cap != null && current >= cap) {
        console.warn(
          `[cannons-and-chaos] markItemInstalled: "${item.name}" installed on "${actor.name}" ` +
          `exceeds engine mount capacity (${current}/${cap}). ` +
          `This hull's rolled engine mounts should be respected — use the sheet UI to enforce the limit.`
        );
      }
    }
  }

  await item.setFlag(CNC_MODULE_ID, "installed", shouldInstall);

  const itemData = {
    id: item.id,
    name: item.name,
    componentType,
    tier: getResolvedComponentTier(item),
    mountIndex: mountIndex,
    arc: getResolvedArc(item),
    powerCost: getResolvedPowerCost(item)
  };

  if (componentType === "helm") hull.installed.helm = shouldInstall ? itemData : null;
  if (componentType === "powerCore") hull.installed.powerCore = shouldInstall ? itemData : null;

  if (componentType === "engine") {
    hull.installed.engines = (hull.installed.engines ?? []).filter(x => x.id !== item.id);
    if (shouldInstall) hull.installed.engines.push(itemData);
    hull.installed.engines.sort((a, b) => (a.mountIndex ?? 999) - (b.mountIndex ?? 999));
  }

  if (componentType === "weapon") {
    hull.installed.weapons = (hull.installed.weapons ?? []).filter(x => x.id !== item.id);
    if (shouldInstall) hull.installed.weapons.push(itemData);
  }

  if (componentType === "utility") {
    hull.installed.utilities = (hull.installed.utilities ?? []).filter(x => x.id !== item.id);
    if (shouldInstall) hull.installed.utilities.push(itemData);
  }

  await actor.setFlag(CNC_MODULE_ID, "hullData", hull);
}

export async function ensureItemHasEmbeddedFlags(actor, item) {
  const current = getItemCncFlags(item);
  const repaired = buildCncFlagsForItem(item, { installed: current.installed ?? false });

  if (
    current.componentType === repaired.componentType &&
    current.tier === repaired.tier &&
    current.mountIndex === repaired.mountIndex &&
    current.arc === repaired.arc &&
    current.powerCost === repaired.powerCost &&
    current.installed === repaired.installed
  ) {
    return item;
  }

  await item.update({ [`flags.${CNC_MODULE_ID}`]: repaired });
  return actor.items.get(item.id) ?? item;
}
