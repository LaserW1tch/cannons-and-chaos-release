import { CNC_MODULE_ID, MODULE_ID } from "./derived.js";

const HULL_ICON = "icons/environment/settlement/ship.webp";

const SHIP_CLASSES = {
  "Civilian Vessel": {
    tier: 1,
    powerCoreTier: 1,
    weaponHardpointsMax: 3,
    weaponMaxTier: "I",
    utilityHardpointsMax: 2,
    utilityMaxTier: "I",
    powerPoolRange: [4, 6],
    cargoNormal: 6,
    cargoTrade: 32,
    ac: [12, 14],
    hp: [250, 300],
    dt: [10, 12],
    speedRange: [5, 20],
    engineMounts: [1, 20],
    turnRate: [1, 3],
    cost: [8000, 25000],
    crew: [1, 6],
    passengers: [5, 10],
    propulsion: ["Arcane Sails", "Propeller Engine", "Arcane Thruster", "Arcane Jet"],
    abilities: {
      str: [8, 12], dex: [14, 16], con: [8, 12], int: [8, 12], wis: [10, 14], cha: [8, 12]
    }
  },
  "Frigate": {
    tier: 2,
    powerCoreTier: 2,
    weaponHardpointsMax: 5,
    weaponMaxTier: "II",
    utilityHardpointsMax: 3,
    utilityMaxTier: "II",
    powerPoolRange: [8, 10],
    cargo: 16,
    ac: [14, 16],
    hp: [300, 500],
    dt: [12, 14],
    speedRange: [5, 12],
    engineMounts: [1, 12],
    turnRate: [1, 2],
    cost: [25000, 75000],
    crew: [5, 25],
    passengers: [10, 25],
    propulsion: ["Propeller Engine", "Arcane Thruster", "Arcane Jet"],
    abilities: {
      str: [12, 16], dex: [18, 20], con: [12, 16], int: [10, 14], wis: [12, 16], cha: [10, 14]
    }
  },
  "Cruiser": {
    tier: 3,
    powerCoreTier: 3,
    weaponHardpointsMax: 7,
    weaponMaxTier: "III",
    utilityHardpointsMax: 4,
    utilityMaxTier: "III",
    powerPoolRange: [12, 16],
    cargo: 24,
    ac: [16, 18],
    hp: [500, 700],
    dt: [14, 16],
    speedRange: [3, 10],
    engineMounts: [1, 10],
    turnRate: [1, 2],
    cost: [75000, 125000],
    crew: [25, 100],
    passengers: [25, 100],
    propulsion: ["Arcane Thruster", "Arcane Jet"],
    abilities: {
      str: [16, 20], dex: [22, 24], con: [16, 20], int: [14, 18], wis: [14, 18], cha: [12, 16]
    }
  },
  "Dreadnought": {
    tier: 4,
    powerCoreTier: 4,
    weaponHardpointsMax: 12,
    weaponMaxTier: "IV",
    utilityHardpointsMax: 5,
    utilityMaxTier: "IV",
    powerPoolRange: [18, 20],
    cargo: 32,
    ac: [18, 22],
    hp: [700, 1500],
    dt: [16, 20],
    speedRange: [3, 6],
    engineMounts: [1, 6],
    turnRate: [1, 1],
    cost: [125000, 250000],
    crew: [75, 125],
    passengers: [50, 100],
    propulsion: ["Arcane Jet"],
    abilities: {
      str: [20, 24], dex: [26, 28], con: [20, 24], int: [16, 20], wis: [16, 20], cha: [14, 18]
    }
  }
};

function weightedInt(min, max, samples = 3) {
  min = Math.round(Number(min ?? 0));
  max = Math.round(Number(max ?? min));
  if (min >= max) return min;
  let total = 0;
  for (let i = 0; i < samples; i += 1) total += Math.random();
  return Math.round(min + ((total / samples) * (max - min)));
}

function weightedHardpoints(max) {
  return weightedInt(1, max, 3);
}

function formatNumber(value) {
  return Math.round(Number(value ?? 0)).toLocaleString();
}

function slugify(text) {
  return String(text ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function uniqueActorName(baseName) {
  let name = baseName;
  let counter = 2;
  while (game.actors.some(actor => actor.name === name)) {
    name = `${baseName} ${counter}`;
    counter += 1;
  }
  return name;
}

function buildBiography(hull) {
  const propulsion = hull.frame.propulsionOptions.join(", ");
  const cargoProfileLine = hull.civilianCargoProfile
    ? `<p><strong>Civilian Cargo Profile:</strong> ${hull.civilianCargoProfile}</p>`
    : "";

  return `
<h2>Cannons &amp; Chaos Hull Frame</h2>
<p><strong>Class:</strong> ${hull.class} (Tier ${hull.tier})</p>
${cargoProfileLine}
<p><strong>Status:</strong> Empty hull only. No installed helm, power core, engines, weapons, or utility modules.</p>

<h3>Frame Data</h3>
<ul>
  <li><strong>Required Power Core Tier:</strong> ${hull.frame.requiredPowerCoreTier}</li>
  <li><strong>Weapon Hardpoints:</strong> ${hull.frame.weaponHardpoints} / ${hull.frame.weaponHardpointsMax}</li>
  <li><strong>Max Weapon Tier:</strong> ${hull.frame.maxWeaponTier}</li>
  <li><strong>Utility Hardpoints:</strong> ${hull.frame.utilityHardpoints} / ${hull.frame.utilityHardpointsMax}</li>
  <li><strong>Max Utility Tier:</strong> ${hull.frame.maxUtilityTier}</li>
  <li><strong>Engine Mounts:</strong> ${hull.frame.engineMounts}</li>
  <li><strong>Allowed Propulsion:</strong> ${propulsion}</li>
  <li><strong>Turn Rate:</strong> ${hull.stats.turnRate}</li>
  <li><strong>Power Pool Range:</strong> ${hull.frame.powerPointPoolRange.min}-${hull.frame.powerPointPoolRange.max}</li>
  <li><strong>Speed Range:</strong> ${hull.stats.speedRange.min}-${hull.stats.speedRange.max}</li>
  <li><strong>Cost:</strong> ${formatNumber(hull.stats.costShards)} shards</li>
  <li><strong>Power Pool:</strong> None until a power core is installed</li>
</ul>

<h3>Hull Stats</h3>
<ul>
  <li><strong>AC:</strong> ${hull.stats.ac}</li>
  <li><strong>HP:</strong> ${hull.stats.hp}</li>
  <li><strong>Damage Threshold:</strong> ${hull.stats.damageThreshold}</li>
  <li><strong>Max Cargo:</strong> ${hull.stats.cargoMaxTons} tons</li>
  <li><strong>Crew Required:</strong> ${hull.stats.crewRequired}</li>
  <li><strong>Passenger Capacity:</strong> ${hull.stats.passengerCapacity}</li>
</ul>

<h3>Ability Scores</h3>
<ul>
  <li><strong>STR:</strong> ${hull.abilities.str}</li>
  <li><strong>DEX:</strong> ${hull.abilities.dex}</li>
  <li><strong>CON:</strong> ${hull.abilities.con}</li>
  <li><strong>INT:</strong> ${hull.abilities.int}</li>
  <li><strong>WIS:</strong> ${hull.abilities.wis}</li>
  <li><strong>CHA:</strong> ${hull.abilities.cha}</li>
</ul>`.trim();
}

function generateHullData({ shipClass, civilianCargo = "normal" } = {}) {
  const cls = SHIP_CLASSES[shipClass];
  if (!cls) throw new Error(`Unknown ship class: ${shipClass}`);

  const cargoMax = shipClass === "Civilian Vessel"
    ? (civilianCargo === "trade" ? cls.cargoTrade : cls.cargoNormal)
    : cls.cargo;

  const civilianCargoProfile = shipClass === "Civilian Vessel"
    ? (civilianCargo === "trade" ? "Trade Vessel" : "Normal Vessel")
    : null;

  return {
    id: foundry.utils.randomID(),
    class: shipClass,
    tier: cls.tier,
    schemaVersion: 1,
    importedBy: MODULE_ID,
    emptyHullOnly: true,
    civilianCargoProfile,
    frame: {
      requiredPowerCoreTier: cls.powerCoreTier,
      weaponHardpoints: weightedHardpoints(cls.weaponHardpointsMax),
      weaponHardpointsMax: cls.weaponHardpointsMax,
      maxWeaponTier: cls.weaponMaxTier,
      utilityHardpoints: weightedHardpoints(cls.utilityHardpointsMax),
      utilityHardpointsMax: cls.utilityHardpointsMax,
      maxUtilityTier: cls.utilityMaxTier,
      engineMounts: weightedInt(cls.engineMounts[0], cls.engineMounts[1], 3),
      propulsionOptions: [...cls.propulsion],
      powerPointPoolRange: { min: cls.powerPoolRange[0], max: cls.powerPoolRange[1] }
    },
    stats: {
      ac: weightedInt(cls.ac[0], cls.ac[1], 3),
      hp: weightedInt(cls.hp[0], cls.hp[1], 3),
      damageThreshold: weightedInt(cls.dt[0], cls.dt[1], 3),
      speedRange: { min: cls.speedRange[0], max: cls.speedRange[1] },
      turnRate: weightedInt(cls.turnRate[0], cls.turnRate[1], 3),
      cargoMaxTons: cargoMax,
      crewRequired: weightedInt(cls.crew[0], cls.crew[1], 3),
      passengerCapacity: weightedInt(cls.passengers[0], cls.passengers[1], 3),
      costShards: weightedInt(cls.cost[0], cls.cost[1], 3)
    },
    abilities: {
      str: weightedInt(cls.abilities.str[0], cls.abilities.str[1], 3),
      dex: weightedInt(cls.abilities.dex[0], cls.abilities.dex[1], 3),
      con: weightedInt(cls.abilities.con[0], cls.abilities.con[1], 3),
      int: weightedInt(cls.abilities.int[0], cls.abilities.int[1], 3),
      wis: weightedInt(cls.abilities.wis[0], cls.abilities.wis[1], 3),
      cha: weightedInt(cls.abilities.cha[0], cls.abilities.cha[1], 3)
    },
    installed: {
      helm: null,
      powerCore: null,
      engines: [],
      weapons: [],
      utilities: []
    }
  };
}

function buildActorData(hull) {
  const actorName = uniqueActorName(`${hull.class} Hull`);
  const biographyHtml = buildBiography(hull);
  const hullData = foundry.utils.deepClone(hull);

  return {
    name: actorName,
    type: "vehicle",
    img: HULL_ICON,
    system: {
      source: { custom: "Custom Naval Vehicle Sheet Hull Generator" },
      details: {
        type: { value: "space", subtype: "" },
        biography: { value: biographyHtml }
      },
      traits: { size: "grg" },
      attributes: {
        ac: { calc: "flat", flat: hull.stats.ac },
        hp: { value: hull.stats.hp, max: hull.stats.hp, dt: hull.stats.damageThreshold },
        capacity: { cargo: { value: hull.stats.cargoMaxTons, units: "tn" } },
        price: { value: hull.stats.costShards }
      },
      currency: { pp: 0, gp: 0, ep: 0, sp: 0, cp: 0 },
      crew: { quantity: hull.stats.crewRequired },
      passengers: { quantity: hull.stats.passengerCapacity },
      abilities: {
        str: { value: hull.abilities.str }, dex: { value: hull.abilities.dex }, con: { value: hull.abilities.con },
        int: { value: hull.abilities.int }, wis: { value: hull.abilities.wis }, cha: { value: hull.abilities.cha }
      }
    },
    prototypeToken: { name: actorName, disposition: 0, actorLink: false },
    flags: {
      [CNC_MODULE_ID]: {
        hullData,
        importedBy: MODULE_ID,
        emptyHullOnly: true
      },
      [MODULE_ID]: {
        sheetState: {
          activeTab: "overview",
          cargo: { entries: [] },
          combat: { componentStates: {} },
          treasury: {
            balance: 0,
            startLevel: null,
            linkedShipUuid: "",
            ledger: []
          }
        },
        weaponLoadStates: {}
      }
    }
  };
}

export async function createHull({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) {
  const hull = generateHullData({ shipClass, civilianCargo });
  const actorData = buildActorData(hull);
  const actor = await Actor.create(actorData, { renderSheet });

  // Explicitly stamp canonical Cannons & Chaos hull flags after creation.
  // This is more reliable than relying only on nested creation-time flags.
  await actor.setFlag(CNC_MODULE_ID, "hullData", foundry.utils.deepClone(hull));
  await actor.setFlag(CNC_MODULE_ID, "importedBy", MODULE_ID);
  await actor.setFlag(CNC_MODULE_ID, "emptyHullOnly", true);

  const sheetState = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "sheetState") ?? {});
  sheetState.treasury ??= { balance: 0, startLevel: null, linkedShipUuid: actor.uuid, ledger: [] };
  sheetState.treasury.linkedShipUuid = actor.uuid;
  await actor.setFlag(MODULE_ID, "sheetState", sheetState);

  if (createChatMessage) {
    const summaryHtml = `
<div style="font-family:monospace; color:#ffffff; line-height:1.5; background:rgba(4,7,15,0.94); border:1px solid rgba(78,205,196,0.45); padding:12px; border-radius:8px;">
  <h2 style="margin:0 0 0.5rem 0; color:#ff9fdb;">Random Hull Generated</h2>
  <p><strong>Created:</strong> ${actor.name}</p>
  ${hull.civilianCargoProfile ? `<p><strong>Civilian Cargo Profile:</strong> ${hull.civilianCargoProfile}</p>` : ""}
  <p><strong>Status:</strong> Empty hull only. No installed helm, power core, engines, weapons, or utility modules.</p>
  <hr>
  <p><strong>Class:</strong> ${hull.class} (Tier ${hull.tier})</p>
  <p><strong>AC:</strong> ${hull.stats.ac} &nbsp; <strong>HP:</strong> ${hull.stats.hp} &nbsp; <strong>DT:</strong> ${hull.stats.damageThreshold}</p>
  <p><strong>Turn Rate:</strong> ${hull.stats.turnRate} &nbsp; <strong>Engine Mounts:</strong> ${hull.frame.engineMounts}</p>
  <p><strong>Weapon Hardpoints:</strong> ${hull.frame.weaponHardpoints}/${hull.frame.weaponHardpointsMax} (max Tier ${hull.frame.maxWeaponTier})</p>
  <p><strong>Utility Hardpoints:</strong> ${hull.frame.utilityHardpoints}/${hull.frame.utilityHardpointsMax} (max Tier ${hull.frame.maxUtilityTier})</p>
  <p><strong>Cargo Max:</strong> ${hull.stats.cargoMaxTons} tons &nbsp; <strong>Crew:</strong> ${hull.stats.crewRequired} &nbsp; <strong>Passengers:</strong> ${hull.stats.passengerCapacity}</p>
  <p><strong>Hull Cost:</strong> ${formatNumber(hull.stats.costShards)} shards</p>
  <p><strong>Allowed Propulsion:</strong> ${hull.frame.propulsionOptions.join(", ")}</p>
</div>`;

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: summaryHtml
    });
  }

  return { actor, hull };
}

export async function openDialog() {
  const classOptions = Object.keys(SHIP_CLASSES)
    .map(c => `<option value="${c}">${c}</option>`)
    .join("");

  const content = `
  <form>
    <div class="form-group">
      <label>Ship Class</label>
      <select name="shipClass">${classOptions}</select>
    </div>

    <div class="form-group" data-civilian-cargo-group>
      <label>Civilian Cargo Profile</label>
      <select name="civilianCargo">
        <option value="normal" selected>Normal Vessel (6 tons max)</option>
        <option value="trade">Trade Vessel (32 tons max)</option>
      </select>
    </div>

    <p style="margin-top:8px; opacity:0.85;">
      Creates an empty hull actor only. No helm, power core, engines, weapons, or utility modules are installed.
    </p>
  </form>`;

  return new Promise(resolve => {
    new Dialog({
      title: "Generate Random Hull",
      content,
      buttons: {
        generate: {
          label: "Generate",
          callback: async html => {
            const root = html[0];
            const shipClass = root.querySelector('[name="shipClass"]')?.value;
            const civilianCargo = root.querySelector('[name="civilianCargo"]')?.value ?? "normal";
            try {
              const result = await createHull({ shipClass, civilianCargo, renderSheet: true, createChatMessage: true });
              resolve(result);
            } catch (err) {
              console.error(`${MODULE_ID} | Hull generation failed`, err);
              ui.notifications.error("Hull generation failed. Check the console for details.");
              resolve(null);
            }
          }
        },
        cancel: {
          label: "Cancel",
          callback: () => resolve(null)
        }
      },
      default: "generate",
      render: html => {
        const root = html[0];
        const shipClassSelect = root.querySelector('[name="shipClass"]');
        const cargoGroup = root.querySelector('[data-civilian-cargo-group]');
        const updateVisibility = () => {
          cargoGroup.style.display = shipClassSelect.value === "Civilian Vessel" ? "" : "none";
        };
        shipClassSelect.addEventListener("change", updateVisibility);
        updateVisibility();
      }
    }).render(true);
  });
}
