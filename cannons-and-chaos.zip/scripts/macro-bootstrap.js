
Hooks.once("ready", async () => {
  const MODULE_ID = "cannons-and-chaos";

  const macros = [
    {
      name: "Generate Random Hull",
      command: "game.cannonsAndChaos.HullGeneratorAPI.openDialog();"
    },
    {
      name: "Salvage Selected Ship",
      command: "game.cannonsAndChaos.SalvageAPI.salvageSelectedShip();"
    },
    {
      name: "Guild Recovery Charter Quote",
      command: "game.cannonsAndChaos.CharterAPI.quoteForCurrentShip();"
    },
    {
      name: "Guild Recovery Charter Payout",
      command: "game.cannonsAndChaos.CharterPayoutAPI.payoutSelectedShip();"
    },
    {
      name: "Chop Shop (Current Ship)",
      command: "game.cannonsAndChaos.ChopShopAPI.openForCurrentShip();"
    },
    {
      name: "Arcane Shield Projector Calculator",
      command: "game.cannonsAndChaos.ArcaneShieldProjectorAPI.openCalculator();"
    }
  ];

  for (let m of macros) {
    let existing = game.macros.find(x => x.name === m.name);

    if (!existing) {
      await Macro.create({
        name: m.name,
        type: "script",
        command: m.command,
        img: "icons/svg/d20.svg",
        flags: {
          [MODULE_ID]: { managed: true }
        }
      });
    } else if (existing.flags?.[MODULE_ID]?.managed) {
      // update existing managed macros
      await existing.update({ command: m.command });
    }
  }

  console.log("C&C | Macros ensured and updated.");
});
