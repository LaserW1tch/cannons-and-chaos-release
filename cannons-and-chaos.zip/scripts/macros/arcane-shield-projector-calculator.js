import { getPrimaryTreasuryShipActor, isShipActor, prepareNavalContext } from "../helpers/derived.js";

function formatSigned(value) {
  const num = Number(value ?? 0);
  if (!Number.isFinite(num) || num === 0) return "0";
  return num > 0 ? `+${num}` : `${num}`;
}

function clampDamage(value) {
  const num = Number(value ?? 0);
  if (!Number.isFinite(num)) return 0;
  return Math.max(0, Math.floor(num));
}

async function resolveTargetShipActor() {
  const controlled = Array.from(canvas?.tokens?.controlled ?? [])
    .map(token => token?.actor)
    .filter(actor => isShipActor(actor));

  if (controlled.length === 1) return controlled[0];
  if (controlled.length > 1) {
    throw new Error("Select exactly one ship token, or clear your selection to use the Primary Treasury Ship.");
  }

  const primary = await getPrimaryTreasuryShipActor();
  if (isShipActor(primary)) return primary;

  throw new Error("Select exactly one ship token, or set a Primary Treasury Ship first.");
}

function buildResultHtml({
  actorName,
  baseDt,
  shieldBonus,
  effectiveDt,
  incomingDamage,
  damageMode,
  excessDamage,
  preventedDamage,
  finalDamage
} = {}) {
  const modeLabel = damageMode === "dtIgnoring"
    ? "DT-Ignoring Attack"
    : damageMode === "fire"
      ? "Fire Damage"
      : "Standard Attack";

  const bypassesShield = damageMode === "dtIgnoring" || damageMode === "fire";

  const summaryLines = bypassesShield
    ? [
        `<li><strong>Incoming Damage:</strong> ${incomingDamage}</li>`,
        `<li><strong>Attack Type:</strong> ${modeLabel}</li>`,
        `<li><strong>Shield Interaction:</strong> Arcane Shield Projector does not reduce this damage.</li>`,
        `<li><strong>Final Applied Damage:</strong> ${finalDamage}</li>`
      ]
    : [
        `<li><strong>Base DT:</strong> ${baseDt}</li>`,
        `<li><strong>Shield Bonus:</strong> ${formatSigned(shieldBonus)} DT</li>`,
        `<li><strong>Effective DT While Shielded:</strong> ${effectiveDt}</li>`,
        `<li><strong>Incoming Damage:</strong> ${incomingDamage}</li>`,
        `<li><strong>Excess Over DT:</strong> ${excessDamage}</li>`,
        `<li><strong>Shield Reduction:</strong> ${preventedDamage}</li>`,
        `<li><strong>Final Applied Damage:</strong> ${finalDamage}</li>`
      ];

  const formulaText = bypassesShield
    ? `${incomingDamage} damage applies in full.`
    : incomingDamage <= effectiveDt
      ? `${incomingDamage} does not exceed ${effectiveDt}, so the shielded DT absorbs the hit.`
      : `${incomingDamage} - floor((${incomingDamage} - ${effectiveDt}) / 2) = ${finalDamage}`;

  return `
    <div class="cnc-activation-card cnc-arcane-shield-calculator-card">
      <h3>Arcane Shield Projector Calculator</h3>
      <p><strong>Ship:</strong> ${foundry.utils.escapeHTML(actorName || "Unknown Ship")}</p>
      <p><strong>Attack Type:</strong> ${modeLabel}</p>
      <ul style="margin:0 0 10px 18px; padding:0;">
        ${summaryLines.join("")}
      </ul>
      <p><strong>Formula:</strong> ${formulaText}</p>
      <p><em>Fire damage and DT-ignoring attacks bypass both the +12 DT bonus and the overflow reduction.</em></p>
    </div>
  `;
}

function calculateShieldedDamage({ baseDt = 0, incomingDamage = 0, damageMode = "standard" } = {}) {
  const normalizedBaseDt = Math.max(0, Number(baseDt ?? 0) || 0);
  const normalizedIncoming = clampDamage(incomingDamage);
  const normalizedMode = ["standard", "dtIgnoring", "fire"].includes(damageMode) ? damageMode : "standard";
  const shieldBonus = normalizedMode === "standard" ? 12 : 0;
  const effectiveDt = normalizedBaseDt + shieldBonus;

  if (normalizedMode !== "standard") {
    return {
      baseDt: normalizedBaseDt,
      shieldBonus,
      effectiveDt,
      incomingDamage: normalizedIncoming,
      damageMode: normalizedMode,
      excessDamage: 0,
      preventedDamage: 0,
      finalDamage: normalizedIncoming
    };
  }

  if (normalizedIncoming <= effectiveDt) {
    return {
      baseDt: normalizedBaseDt,
      shieldBonus,
      effectiveDt,
      incomingDamage: normalizedIncoming,
      damageMode: normalizedMode,
      excessDamage: 0,
      preventedDamage: normalizedIncoming,
      finalDamage: 0
    };
  }

  const excessDamage = normalizedIncoming - effectiveDt;
  const preventedDamage = Math.floor(excessDamage / 2);
  const finalDamage = Math.max(0, normalizedIncoming - preventedDamage);

  return {
    baseDt: normalizedBaseDt,
    shieldBonus,
    effectiveDt,
    incomingDamage: normalizedIncoming,
    damageMode: normalizedMode,
    excessDamage,
    preventedDamage,
    finalDamage
  };
}

export async function openArcaneShieldProjectorCalculator() {
  let actor;
  try {
    actor = await resolveTargetShipActor();
  } catch (err) {
    ui.notifications.warn(err?.message ?? "No valid ship available for Arcane Shield Projector calculation.");
    return null;
  }

  const context = prepareNavalContext(actor);
  const baseDt = Math.max(0, Number(context?.derivedShip?.damageThreshold?.total ?? 0) || 0);

  const content = `
    <form class="cnc-arcane-shield-calculator-form" autocomplete="off">
      <div class="form-group">
        <label>Ship</label>
        <input type="text" name="shipName" value="${foundry.utils.escapeHTML(actor.name ?? "")}" disabled>
      </div>
      <div class="form-group">
        <label>Current DT</label>
        <input type="number" name="baseDt" value="${baseDt}" min="0" step="1">
      </div>
      <div class="form-group">
        <label>Incoming Damage</label>
        <input type="number" name="incomingDamage" value="0" min="0" step="1">
      </div>
      <div class="form-group">
        <label>Damage Type</label>
        <select name="damageMode">
          <option value="standard" selected>Standard Attack</option>
          <option value="dtIgnoring">DT-Ignoring Attack</option>
          <option value="fire">Fire Damage</option>
        </select>
      </div>
      <p class="notes">Standard attacks gain the Arcane Shield Projector's +12 DT and overflow reduction. Fire damage and DT-ignoring attacks bypass the projector.</p>
    </form>
  `;

  return new Promise(resolve => {
    let settled = false;
    const finish = value => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    new Dialog({
      title: "Arcane Shield Projector Calculator",
      content,
      buttons: {
        calculate: {
          label: "Calculate",
          callback: async html => {
            const root = html[0] ?? html;
            const form = root?.querySelector?.("form");
            const formData = new FormData(form);
            const result = calculateShieldedDamage({
              baseDt: formData.get("baseDt"),
              incomingDamage: formData.get("incomingDamage"),
              damageMode: formData.get("damageMode")
            });
            const chatContent = buildResultHtml({ actorName: actor.name, ...result });
            await ChatMessage.create({
              speaker: ChatMessage.getSpeaker({ actor }),
              content: chatContent
            });
            finish(result);
          }
        },
        cancel: {
          label: "Cancel",
          callback: () => finish(null)
        }
      },
      default: "calculate",
      render: html => {
        const incoming = html[0]?.querySelector?.('input[name="incomingDamage"]');
        if (incoming) incoming.focus();
      },
      close: () => finish(null)
    }, { width: 460 }).render(true);
  });
}
