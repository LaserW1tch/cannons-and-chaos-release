await game.cannonsAndChaos.ChopShopAPI.openForCurrentShip();
