/**
 * Guild Recovery Charter Payout
 * Uses CNC CharterPayoutAPI to print payout to chat (no treasury deposit)
 */

if (!game?.customNavalVehicleSheet?.CharterPayoutAPI) {
  ui.notifications.error("CharterPayoutAPI not available. Is the module active?");
  return;
}

await game.cannonsAndChaos.CharterPayoutAPI.payoutSelectedShip();
