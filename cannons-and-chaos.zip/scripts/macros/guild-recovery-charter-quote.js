/**
 * Guild Recovery Charter Quote
 * Prefers the Primary Treasury Ship if one is designated.
 * Falls back to the currently selected vehicle token.
 */

if (!game?.customNavalVehicleSheet?.CharterAPI) {
  ui.notifications.error("CharterAPI not available. Is the module active?");
  return;
}

await game.cannonsAndChaos.CharterAPI.quoteForCurrentShip();
