(async () => {
  if (!game?.customNavalVehicleSheet?.SalvageAPI?.salvageSelectedShip) {
    ui.notifications.error("Custom Naval Vehicle Sheet salvage API is not available.");
    return;
  }

  try {
    const result = await game.cannonsAndChaos.SalvageAPI.salvageSelectedShip({
      createChatMessage: true
    });

    ui.notifications.info(`Recovered ${result.recoveredShards.toLocaleString()} shards from ${result.actor.name}.`);
  } catch (err) {
    console.error("Custom Naval Vehicle Sheet | Salvage macro failed", err);
    ui.notifications.error(err?.message ?? "Salvage operation failed.");
  }
})();
