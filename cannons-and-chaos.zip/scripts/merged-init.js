import { NavalShipSheet } from "./sheets/ship-sheet.js";
import { MiniNavalShipSheet } from "./sheets/mini-ship-sheet.js";
import { MODULE_ID } from "./helpers/derived.js";

Hooks.once("init", () => {
  console.log(`${MODULE_ID} | merged-init registering vehicle sheet`);

  game.cannonsAndChaos ??= {};

  const registerKey = `${MODULE_ID}.registerForVehicles`;
  const primaryKey = `${MODULE_ID}.primaryTreasuryShipUuid`;

  if (!game.settings.settings.has(registerKey)) {
    game.settings.register(MODULE_ID, "registerForVehicles", {
      name: "Register Custom Naval Sheet for Vehicle Actors",
      hint: "Makes the custom sheet available in the sheet dropdown for dnd5e vehicle actors.",
      scope: "world",
      config: true,
      type: Boolean,
      default: true
    });
  }

  if (!game.settings.settings.has(primaryKey)) {
    game.settings.register(MODULE_ID, "primaryTreasuryShipUuid", {
      name: "Primary Treasury Ship UUID",
      hint: "Internal setting used to route salvage and other treasury deposits to the designated ship.",
      scope: "world",
      config: false,
      type: String,
      default: ""
    });
  }

  const baselineKey = `${MODULE_ID}.startingShipBaseline`;
  if (!game.settings.settings.has(baselineKey)) {
    game.settings.register(MODULE_ID, "startingShipBaseline", {
      name: "Starting Ship Baseline (Shards)",
      hint: "Ideal-curve wealth planning assumes the party began with one free Tier I ship worth this many shards.",
      scope: "world",
      config: true,
      type: Number,
      default: 18000
    });
  }

  const shouldRegister = game.settings.get(MODULE_ID, "registerForVehicles");
  if (!shouldRegister) return;

  try {
    Actors.registerSheet(MODULE_ID, NavalShipSheet, {
      types: ["vehicle"],
      makeDefault: false,
      label: "C&C Vehicle Sheet"
    });
    Actors.registerSheet(MODULE_ID, MiniNavalShipSheet, {
      types: ["vehicle"],
      makeDefault: false,
      label: "MINI C&C Vehicle Sheet"
    });
    console.log(`${MODULE_ID} | vehicle sheets registered`);
  } catch (err) {
    console.error(`${MODULE_ID} | vehicle sheet registration failed`, err);
  }
});
