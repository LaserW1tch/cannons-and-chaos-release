import { NavalShipSheet } from "./sheets/ship-sheet.js";
import { MiniNavalShipSheet } from "./sheets/mini-ship-sheet.js";
import {
  MODULE_ID,
  addTreasuryTransaction,
  calculateChopShopOutcome,
  calculateRecoveryCharterPayout,
  calculateRecoveryCharterQuote,
  calculateSalvageOutcome,
  createRecoveryCharterPayoutCard,
  createRecoveryCharterQuote,
  ensureTreasuryState,
  getChopShopComponents,
  getPrimaryTreasuryShipActor,
  getPrimaryTreasuryShipUuid,
  openChopShopForActor,
  processAllChopShopComponents,
  processChopShopComponent,
  salvageShipToTreasury,
  setPrimaryTreasuryShip,
  transferTreasuryToShip
} from "./helpers/derived.js";
import { createHull as createGeneratedHull, openDialog as openHullGeneratorDialog } from "./helpers/hull-generator.js";
import { openRoleManagerForActor, openRoleManagerForCurrentUser } from "./role-manager.js";


function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

const MASS_DIFFERENTIAL_PENDING = new Map();
const MASS_DIFFERENTIAL_TIMEOUT_MS = 30000;

function getMassDifferentialQueue(userId) {
  const key = String(userId ?? "").trim();
  if (!key) return [];
  const existing = MASS_DIFFERENTIAL_PENDING.get(key);
  if (Array.isArray(existing)) return existing;
  const queue = [];
  MASS_DIFFERENTIAL_PENDING.set(key, queue);
  return queue;
}

function pruneExpiredMassDifferentialContexts(userId) {
  const key = String(userId ?? "").trim();
  if (!key) return [];
  const queue = getMassDifferentialQueue(key);
  const now = Date.now();
  const fresh = queue.filter(entry => Number(entry?.expiresAt ?? 0) >= now);
  if (fresh.length) MASS_DIFFERENTIAL_PENDING.set(key, fresh);
  else MASS_DIFFERENTIAL_PENDING.delete(key);
  return fresh;
}

function registerPendingMassDifferentialContext(context = {}) {
  const userId = String(context?.userId ?? game.user?.id ?? "").trim();
  if (!userId) return;
  const queue = pruneExpiredMassDifferentialContexts(userId);
  queue.push({
    ...context,
    userId,
    createdAt: Date.now(),
    expiresAt: Date.now() + MASS_DIFFERENTIAL_TIMEOUT_MS
  });
  MASS_DIFFERENTIAL_PENDING.set(userId, queue);
}

function clearPendingMassDifferentialContext(userId) {
  const key = String(userId ?? "").trim();
  if (!key) return;
  MASS_DIFFERENTIAL_PENDING.delete(key);
}

function getPendingMassDifferentialContext(userId) {
  const queue = pruneExpiredMassDifferentialContexts(userId);
  return queue[0] ?? null;
}

function consumeMatchingPendingMassDifferentialContext(message) {
  const messageUserId = String(message?.user?.id ?? message?.user ?? "").trim();
  if (!messageUserId) return null;
  const queue = pruneExpiredMassDifferentialContexts(messageUserId);
  if (!queue.length) return null;

  const index = queue.findIndex(entry => messageMatchesPendingMassDifferential(message, entry));
  if (index === -1) return null;

  const [match] = queue.splice(index, 1);
  if (queue.length) MASS_DIFFERENTIAL_PENDING.set(messageUserId, queue);
  else MASS_DIFFERENTIAL_PENDING.delete(messageUserId);
  return match;
}

function getMessageDamageTotal(message) {
  const firstRollTotal = Number(message?.rolls?.[0]?.total);
  if (Number.isFinite(firstRollTotal)) return Math.max(0, firstRollTotal);
  const flaggedTotal = Number(foundry.utils.getProperty(message, "flags.dnd5e.roll.total"));
  if (Number.isFinite(flaggedTotal)) return Math.max(0, flaggedTotal);
  return null;
}

function getMessageRollType(message) {
  return String(
    foundry.utils.getProperty(message, "flags.dnd5e.roll.type")
    ?? foundry.utils.getProperty(message, "flags.dnd5e.rollType")
    ?? ""
  ).trim().toLowerCase();
}

function messageLooksLikeDamageRoll(message) {
  if (!message) return false;
  if (foundry.utils.getProperty(message, `flags.${MODULE_ID}.massDifferentialReference`) === true) return false;
  const rollType = getMessageRollType(message);
  if (rollType.includes("damage")) return true;
  const flavor = String(message.flavor ?? "");
  const content = String(message.content ?? "");
  const combined = `${flavor}\n${content}`.toLowerCase();
  return combined.includes("damage") && !combined.includes("attack");
}

function messageMatchesPendingMassDifferential(message, pending) {
  if (!message || !pending) return false;
  const messageUserId = String(message.user?.id ?? message.user ?? "").trim();
  if (messageUserId !== String(pending.userId ?? "").trim()) return false;

  const createdAt = Number(message.timestamp ?? message._source?.timestamp ?? 0);
  if (createdAt && createdAt < Number(pending.createdAt ?? 0)) return false;

  const pendingActorId = String(pending.actorId ?? "").trim();
  const speakerActorId = String(message.speaker?.actor ?? "").trim();
  if (pendingActorId && speakerActorId && pendingActorId != speakerActorId) return false;

  const candidateItemIds = new Set([
    foundry.utils.getProperty(message, "flags.dnd5e.item.id"),
    foundry.utils.getProperty(message, "flags.dnd5e.itemId"),
    foundry.utils.getProperty(message, "flags.dnd5e.roll.itemId"),
    foundry.utils.getProperty(message, "flags.itemId")
  ].map(v => String(v ?? "").trim()).filter(Boolean));

  const pendingItemId = String(pending.itemId ?? "").trim();
  if (candidateItemIds.size && pendingItemId && !candidateItemIds.has(pendingItemId)) return false;

  return true;
}

function buildMassDifferentialReferenceContent({ actorName = "", itemName = "", damageTotal = 0, crossingTheT = false } = {}) {
  const baseDamage = Math.max(0, Number(damageTotal ?? 0));
  const tiers = [
    { gap: 1, multiplier: 1.25 },
    { gap: 2, multiplier: 1.5 },
    { gap: 3, multiplier: 2.0 }
  ].map(({ gap, multiplier }) => {
    const finalDamage = Math.ceil(baseDamage * multiplier);
    const additionalDamage = Math.max(0, finalDamage - baseDamage);
    const cascadeDamage = Math.ceil(finalDamage / 2);
    return { gap, additionalDamage, finalDamage, cascadeDamage };
  });

  return `
    <div class="cnc-activation-card cnc-mass-differential-card">
      <h3>${escapeHtml(itemName || "Weapon")} — Mass Differential Reference</h3>
      <p><strong>Ship:</strong> ${escapeHtml(actorName || "Unknown Ship")}</p>
      <p><strong>Damage Rolled:</strong> ${baseDamage}</p>
      <p><strong>Crossing the T:</strong> ${crossingTheT ? "Active" : "Inactive"}</p>
      <hr>
      ${tiers.map(entry => `
        <div class="cnc-mass-differential-card__tier-block">
          <p><strong>${entry.gap} Tier Mass Differential Modifier:</strong> +${entry.additionalDamage} additional damage</p>
          <p><strong>Final Damage:</strong> ${entry.finalDamage}</p>
          <p><strong>Cascade Component Damage (if triggered):</strong> ${entry.cascadeDamage}</p>
        </div>
      `).join("")}
      <hr>
      <p><em>Cascade Trigger: if final damage from a single hit is at least 25% of the target ship's maximum HP, one random component also takes half the final damage (rounded up).</em></p>
    </div>
  `;
}

async function postMassDifferentialReferenceDirect(data = {}) {
  if (!game.settings?.get?.(MODULE_ID, "enableMassDifferentialWarnings")) return false;
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: game.actors?.get?.(data.actorId) ?? null }),
    content: buildMassDifferentialReferenceContent(data),
    flags: {
      [MODULE_ID]: {
        massDifferentialReference: true,
        direct: true,
        actorId: data.actorId ?? null,
        itemId: data.itemId ?? null
      }
    }
  });
  return true;
}

async function postMassDifferentialReferenceFromMessage(message) {
  if (!game.settings?.get?.(MODULE_ID, "enableMassDifferentialWarnings")) return;
  if (!messageLooksLikeDamageRoll(message)) return;
  const pending = consumeMatchingPendingMassDifferentialContext(message);
  if (!pending) return;
  const damageTotal = getMessageDamageTotal(message);
  if (!Number.isFinite(damageTotal)) return;
  await postMassDifferentialReferenceDirect({
    actorId: pending.actorId,
    actorName: pending.actorName,
    itemId: pending.itemId,
    itemName: pending.itemName,
    damageTotal,
    crossingTheT: pending.crossingTheT === true
  });
}

function ensureApiRoot() {
  game.cannonsAndChaos ??= {};
  return game.cannonsAndChaos;
}

Hooks.once("init", () => {
  console.log(`${MODULE_ID} | Initializing merged sheet systems`);
  game.settings.register(MODULE_ID, "registerForVehicles", {
    name: "Register Custom Naval Sheet for Vehicle Actors",
    hint: "Makes the custom sheet available in the sheet dropdown for dnd5e vehicle actors.",
    scope: "world", config: true, type: Boolean, default: true
  });
  game.settings.register(MODULE_ID, "primaryTreasuryShipUuid", {
    name: "Primary Treasury Ship UUID",
    hint: "Internal setting used to route salvage and other treasury deposits to the designated ship.",
    scope: "world", config: false, type: String, default: ""
  });
  game.settings.register(MODULE_ID, "enableOptionalFireRulesAutomation", {
    name: "Enable Optional Fire Rules Automation",
    hint: "Legacy setting retained for compatibility. New worlds should use the separate fire-rule warning toggles instead.",
    scope: "world", config: false, type: Boolean, default: false
  });
  game.settings.register(MODULE_ID, "enableFirePenaltyWarning", {
    name: "Enable Optional Fire Rule Warning: 3+ Fires",
    hint: "Shows the optional warning that Repair and Extinguish checks are made at disadvantage when a ship has 3 or more active fires.",
    scope: "world", config: true, type: Boolean, default: false
  });
  game.settings.register(MODULE_ID, "enableRunawayFireWarning", {
    name: "Enable Optional Fire Rule Warning: 4+ Fires",
    hint: "Shows the optional warning that a ship gains +1 fire per turn when it has 4 or more active fires.",
    scope: "world", config: true, type: Boolean, default: false
  });
  game.settings.register(MODULE_ID, "enableMassDifferentialWarnings", {
    name: "Enable Optional Mass Differential Rule Warnings",
    hint: "Posts a reference chat card after eligible ship-weapon damage rolls showing the 1-tier, 2-tier, and 3-tier Mass Differential outcomes.",
    scope: "world", config: true, type: Boolean, default: false
  });
  game.settings.register(MODULE_ID, "startingShipBaseline", {
    name: "Starting Ship Baseline (Shards)",
    hint: "Ideal-curve wealth planning assumes the party began with one free Tier I ship worth this many shards.",
    scope: "world", config: true, type: Number, default: 18000
  });
  Actors.registerSheet(MODULE_ID, NavalShipSheet, { types: ["vehicle"], makeDefault: false, label: "C&C Vehicle Sheet" });
  Actors.registerSheet(MODULE_ID, MiniNavalShipSheet, { types: ["vehicle"], makeDefault: false, label: "MINI C&C Vehicle Sheet" });
  const api = ensureApiRoot();
  api.HullGeneratorAPI = {
    createHull: async ({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) => createGeneratedHull({ shipClass, civilianCargo, renderSheet, createChatMessage }),
    openDialog: async () => openHullGeneratorDialog()
  };
  api.RoleManagerAPI = {
    openForActor: async (actorRef) => openRoleManagerForActor(actorRef),
    openForCurrentUser: async (options = {}) => openRoleManagerForCurrentUser(options)
  };
  api.registerPendingMassDifferentialContext = registerPendingMassDifferentialContext;
  api.clearPendingMassDifferentialContext = clearPendingMassDifferentialContext;
  api.postMassDifferentialReference = postMassDifferentialReferenceDirect;
});


async function resolveActorReference(reference) {
  if (!reference) return null;
  if (reference.documentName === "Actor") return reference;
  if (typeof reference === "string") {
    const byId = game.actors?.get?.(reference);
    if (byId) return byId;
    try {
      const byUuid = await fromUuid(reference);
      if (byUuid?.documentName === "Actor") return byUuid;
    } catch (err) {
      console.warn(`${MODULE_ID} | Failed to resolve actor reference`, err);
    }
  }
  return null;
}

Hooks.once("ready", () => {
  console.log(`${MODULE_ID} | Ready`);
  const api = ensureApiRoot();
  api.TreasuryAPI = {
    addTransaction: async ({ actor, actorId, actorUuid, amount = 0, source = "Manual Adjustment", type = "manual", notes = "" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("TreasuryAPI.addTransaction could not resolve the target ship actor.");
      return addTreasuryTransaction(resolvedActor, { amount, source, type, notes });
    },
    transferTreasuryToShip: async (sourceReference, targetReference, options = {}) => {
      const sourceActor = await resolveActorReference(sourceReference);
      const targetActor = await resolveActorReference(targetReference);
      if (!sourceActor || !targetActor) throw new Error("TreasuryAPI.transferTreasuryToShip could not resolve one or both ship actors.");
      return transferTreasuryToShip(sourceActor, targetActor, options);
    },
    ensureState: async (reference) => {
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.ensureState could not resolve the target ship actor.");
      return ensureTreasuryState(actor);
    },
    setPrimaryShip: async (reference) => {
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.setPrimaryShip could not resolve the target ship actor.");
      await ensureTreasuryState(actor);
      await setPrimaryTreasuryShip(actor);
      return actor;
    },
    getPrimaryShipUuid: () => getPrimaryTreasuryShipUuid(),
    getPrimaryShip: async () => getPrimaryTreasuryShipActor()
  };
  api.CharterAPI = {
    calculate: async ({ actor, actorId, actorUuid, treasuryActor = null, treasuryActorId = null, treasuryActorUuid = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterAPI.calculate could not resolve the target ship actor.");
      const resolvedTreasuryActor = await resolveActorReference(treasuryActor ?? treasuryActorUuid ?? treasuryActorId) ?? await getPrimaryTreasuryShipActor() ?? resolvedActor;
      return calculateRecoveryCharterQuote(resolvedActor, { treasuryActor: resolvedTreasuryActor });
    },
    quoteForShip: async ({ actor, actorId, actorUuid, treasuryActor = null, treasuryActorId = null, treasuryActorUuid = null, createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterAPI.quoteForShip could not resolve the target ship actor.");
      const resolvedTreasuryActor = await resolveActorReference(treasuryActor ?? treasuryActorUuid ?? treasuryActorId) ?? await getPrimaryTreasuryShipActor() ?? resolvedActor;
      return createRecoveryCharterQuote(resolvedActor, { treasuryActor: resolvedTreasuryActor, createChatMessage, whisper, preferPrimary: true });
    },
    quoteSelectedShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      const treasuryActor = await getPrimaryTreasuryShipActor() ?? actor;
      return createRecoveryCharterQuote(actor, { treasuryActor, createChatMessage, whisper, preferPrimary: true });
    },
    quoteForCurrentShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const primary = await getPrimaryTreasuryShipActor();
      if (primary) return createRecoveryCharterQuote(primary, { treasuryActor: primary, createChatMessage, whisper, preferPrimary: true });
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return createRecoveryCharterQuote(actor, { treasuryActor: actor, createChatMessage, whisper, preferPrimary: false });
    }
  };
  api.CharterPayoutAPI = {
    calculate: async ({ actor, actorId, actorUuid } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterPayoutAPI.calculate could not resolve the target ship actor.");
      return calculateRecoveryCharterPayout(resolvedActor);
    },
    payoutForShip: async ({ actor, actorId, actorUuid, createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterPayoutAPI.payoutForShip could not resolve the target ship actor.");
      return createRecoveryCharterPayoutCard(resolvedActor, { createChatMessage, whisper });
    },
    payoutSelectedShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return createRecoveryCharterPayoutCard(actor, { createChatMessage, whisper });
    }
  };
  api.SalvageAPI = {
    calculate: async ({ actor, actorId, actorUuid, rollTotal = null, source = null, notes = "" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.calculate could not resolve the target ship actor.");
      return calculateSalvageOutcome(resolvedActor, { rollTotal, source, notes });
    },
    salvageShip: async ({ actor, actorId, actorUuid, source = null, notes = "", createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.salvageShip could not resolve the target ship actor.");
      return salvageShipToTreasury(resolvedActor, { source, notes, createChatMessage, whisper });
    },
    salvageSelectedShip: async ({ createChatMessage = true, notes = "", source = null, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one ship token to salvage.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return salvageShipToTreasury(actor, { source, notes, createChatMessage, whisper });
    }
  };
  api.ChopShopAPI = {
    getCurrentShip: async () => {
      const primary = await getPrimaryTreasuryShipActor();
      if (primary) return primary;
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return actor;
    },
    calculate: async ({ actor, actorId, actorUuid, item, itemId, shopTier = "established" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.calculate could not resolve the target ship actor.");
      const resolvedItem = item ?? (itemId ? resolvedActor.items.get(itemId) : null);
      if (!resolvedItem) throw new Error("ChopShopAPI.calculate could not resolve the target component item.");
      return calculateChopShopOutcome(resolvedActor, resolvedItem, { shopTier });
    },
    getComponents: async ({ actor, actorId, actorUuid, includeDestroyed = false } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId) ?? await api.ChopShopAPI.getCurrentShip();
      return getChopShopComponents(resolvedActor, { includeDestroyed });
    },
    processComponent: async ({ actor, actorId, actorUuid, item, itemId, shopTier = "established", createChatMessage = true } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.processComponent could not resolve the target ship actor.");
      const resolvedItem = item ?? (itemId ? resolvedActor.items.get(itemId) : null);
      if (!resolvedItem) throw new Error("ChopShopAPI.processComponent could not resolve the target component item.");
      return processChopShopComponent(resolvedActor, resolvedItem, { shopTier, createChatMessage });
    },
    processAll: async ({ actor, actorId, actorUuid, shopTier = "established", createChatMessage = true } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.processAll could not resolve the target ship actor.");
      return processAllChopShopComponents(resolvedActor, { shopTier, createChatMessage });
    },
    openForShip: async ({ actor, actorId, actorUuid } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.openForShip could not resolve the target ship actor.");
      return openChopShopForActor(resolvedActor);
    },
    openForCurrentShip: async () => {
      const actor = await api.ChopShopAPI.getCurrentShip();
      return openChopShopForActor(actor);
    }
  };
  api.HullGeneratorAPI = {
    createHull: async ({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) => createGeneratedHull({ shipClass, civilianCargo, renderSheet, createChatMessage }),
    openDialog: async () => openHullGeneratorDialog()
  };
  api.RoleManagerAPI = {
    openForActor: async (actorRef) => openRoleManagerForActor(actorRef),
    openForCurrentUser: async (options = {}) => openRoleManagerForCurrentUser(options)
  };
  api.registerPendingMassDifferentialContext = registerPendingMassDifferentialContext;
  api.clearPendingMassDifferentialContext = clearPendingMassDifferentialContext;
  api.postMassDifferentialReference = postMassDifferentialReferenceDirect;
});


Hooks.on("createChatMessage", (message) => {
  postMassDifferentialReferenceFromMessage(message).catch(err => {
    console.warn(`${MODULE_ID} | Failed to post Mass Differential reference card`, err);
  });
});

Hooks.on("renderActorSheet5eCharacter", (app, html) => {
  injectRoleManagerButton(app, html);
});


function injectRoleManagerButton(app, html) {
  try {
    const actor = app?.actor ?? app?.document ?? null;
    if (!actor || actor.type !== "character") return;
    if (!game.user?.isGM && !actor.isOwner) return;

    const root =
      html?.[0] ??
      html?.element?.[0] ??
      html?.element ??
      app?.element?.[0] ??
      app?.element ??
      document.querySelector(`[data-appid="${app?.appId ?? ""}"]`) ??
      document.querySelector(`[data-application-id="${app?.id ?? ""}"]`) ??
      null;

    if (!root) return;
    if (root.querySelector?.('[data-cnc-role-launcher="true"]')) return;

    const button = document.createElement("button");
    button.type = "button";
    button.dataset.cncRoleLauncher = "true";
    button.className = "cnc-role-launcher";
    button.innerHTML = '<i class="fas fa-anchor"></i> Ship Role';
    button.style.position = "absolute";
    button.style.top = "10px";
    button.style.right = "42px";
    button.style.zIndex = "100";
    button.style.display = "inline-flex";
    button.style.alignItems = "center";
    button.style.gap = "6px";
    button.style.padding = "5px 9px";
    button.style.border = "1px solid rgba(200,185,122,0.65)";
    button.style.borderRadius = "6px";
    button.style.background = "rgba(8,12,24,0.96)";
    button.style.color = "#c8b97a";
    button.style.cursor = "pointer";
    button.style.fontSize = "12px";
    button.style.boxShadow = "0 0 10px rgba(0,0,0,0.25)";
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      await game.cannonsAndChaos?.RoleManagerAPI?.openForActor?.(actor);
    });

    const positionedRoot =
      root.querySelector(".window-content") ||
      root.querySelector("section.window-content") ||
      root;

    if (positionedRoot instanceof HTMLElement) {
      if (!positionedRoot.style.position) positionedRoot.style.position = "relative";
      positionedRoot.appendChild(button);
    }
  } catch (err) {
    console.warn(`${MODULE_ID} | Failed to inject Role Manager button`, err);
  }
}

