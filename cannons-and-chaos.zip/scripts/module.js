import { NavalShipSheet } from "./sheets/ship-sheet.js";
import { MiniNavalShipSheet } from "./sheets/mini-ship-sheet.js";
import {
  MODULE_ID,
  addTreasuryTransaction,
  calculateChopShopOutcome,
  calculateRecoveryCharterPayout,
  calculateRecoveryCharterQuote,
  calculateSalvageOutcome,
  createRecoveryCharterPayoutCard,
  createRecoveryCharterQuote,
  ensureTreasuryState,
  getChopShopComponents,
  getPrimaryTreasuryShipActor,
  getPrimaryTreasuryShipUuid,
  openChopShopForActor,
  processAllChopShopComponents,
  processChopShopComponent,
  salvageShipToTreasury,
  setPrimaryTreasuryShip,
  transferTreasuryToShip
} from "./helpers/derived.js";
import { createHull as createGeneratedHull, openDialog as openHullGeneratorDialog } from "./helpers/hull-generator.js";
import { openRoleManagerForActor, openRoleManagerForCurrentUser } from "./role-manager.js";

function ensureApiRoot() {
  game.cannonsAndChaos ??= {};
  return game.cannonsAndChaos;
}

Hooks.once("init", () => {
  console.log(`${MODULE_ID} | Initializing merged sheet systems`);
  game.settings.register(MODULE_ID, "registerForVehicles", {
    name: "Register Custom Naval Sheet for Vehicle Actors",
    hint: "Makes the custom sheet available in the sheet dropdown for dnd5e vehicle actors.",
    scope: "world", config: true, type: Boolean, default: true
  });
  game.settings.register(MODULE_ID, "primaryTreasuryShipUuid", {
    name: "Primary Treasury Ship UUID",
    hint: "Internal setting used to route salvage and other treasury deposits to the designated ship.",
    scope: "world", config: false, type: String, default: ""
  });
  game.settings.register(MODULE_ID, "enableOptionalFireRulesAutomation", {
    name: "Enable Optional Fire Rules Automation",
    hint: "Shows optional fire-rule alerts on ship sheets when active fires reach 3+ or 4+.",
    scope: "world", config: true, type: Boolean, default: false
  });
  game.settings.register(MODULE_ID, "startingShipBaseline", {
    name: "Starting Ship Baseline (Shards)",
    hint: "Ideal-curve wealth planning assumes the party began with one free Tier I ship worth this many shards.",
    scope: "world", config: true, type: Number, default: 18000
  });
  Actors.registerSheet(MODULE_ID, NavalShipSheet, { types: ["vehicle"], makeDefault: false, label: "C&C Vehicle Sheet" });
  Actors.registerSheet(MODULE_ID, MiniNavalShipSheet, { types: ["vehicle"], makeDefault: false, label: "MINI C&C Vehicle Sheet" });
  const api = ensureApiRoot();
  api.HullGeneratorAPI = {
    createHull: async ({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) => createGeneratedHull({ shipClass, civilianCargo, renderSheet, createChatMessage }),
    openDialog: async () => openHullGeneratorDialog()
  };
  api.RoleManagerAPI = {
    openForActor: async (actorRef) => openRoleManagerForActor(actorRef),
    openForCurrentUser: async (options = {}) => openRoleManagerForCurrentUser(options)
  };
});


async function resolveActorReference(reference) {
  if (!reference) return null;
  if (reference.documentName === "Actor") return reference;
  if (typeof reference === "string") {
    const byId = game.actors?.get?.(reference);
    if (byId) return byId;
    try {
      const byUuid = await fromUuid(reference);
      if (byUuid?.documentName === "Actor") return byUuid;
    } catch (err) {
      console.warn(`${MODULE_ID} | Failed to resolve actor reference`, err);
    }
  }
  return null;
}

Hooks.once("ready", () => {
  console.log(`${MODULE_ID} | Ready`);
  const api = ensureApiRoot();
  api.TreasuryAPI = {
    addTransaction: async ({ actor, actorId, actorUuid, amount = 0, source = "Manual Adjustment", type = "manual", notes = "" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("TreasuryAPI.addTransaction could not resolve the target ship actor.");
      return addTreasuryTransaction(resolvedActor, { amount, source, type, notes });
    },
    transferTreasuryToShip: async (sourceReference, targetReference, options = {}) => {
      const sourceActor = await resolveActorReference(sourceReference);
      const targetActor = await resolveActorReference(targetReference);
      if (!sourceActor || !targetActor) throw new Error("TreasuryAPI.transferTreasuryToShip could not resolve one or both ship actors.");
      return transferTreasuryToShip(sourceActor, targetActor, options);
    },
    ensureState: async (reference) => {
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.ensureState could not resolve the target ship actor.");
      return ensureTreasuryState(actor);
    },
    setPrimaryShip: async (reference) => {
      const actor = await resolveActorReference(reference);
      if (!actor) throw new Error("TreasuryAPI.setPrimaryShip could not resolve the target ship actor.");
      await ensureTreasuryState(actor);
      await setPrimaryTreasuryShip(actor);
      return actor;
    },
    getPrimaryShipUuid: () => getPrimaryTreasuryShipUuid(),
    getPrimaryShip: async () => getPrimaryTreasuryShipActor()
  };
  api.CharterAPI = {
    calculate: async ({ actor, actorId, actorUuid, treasuryActor = null, treasuryActorId = null, treasuryActorUuid = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterAPI.calculate could not resolve the target ship actor.");
      const resolvedTreasuryActor = await resolveActorReference(treasuryActor ?? treasuryActorUuid ?? treasuryActorId) ?? await getPrimaryTreasuryShipActor() ?? resolvedActor;
      return calculateRecoveryCharterQuote(resolvedActor, { treasuryActor: resolvedTreasuryActor });
    },
    quoteForShip: async ({ actor, actorId, actorUuid, treasuryActor = null, treasuryActorId = null, treasuryActorUuid = null, createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterAPI.quoteForShip could not resolve the target ship actor.");
      const resolvedTreasuryActor = await resolveActorReference(treasuryActor ?? treasuryActorUuid ?? treasuryActorId) ?? await getPrimaryTreasuryShipActor() ?? resolvedActor;
      return createRecoveryCharterQuote(resolvedActor, { treasuryActor: resolvedTreasuryActor, createChatMessage, whisper, preferPrimary: true });
    },
    quoteSelectedShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      const treasuryActor = await getPrimaryTreasuryShipActor() ?? actor;
      return createRecoveryCharterQuote(actor, { treasuryActor, createChatMessage, whisper, preferPrimary: true });
    },
    quoteForCurrentShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const primary = await getPrimaryTreasuryShipActor();
      if (primary) return createRecoveryCharterQuote(primary, { treasuryActor: primary, createChatMessage, whisper, preferPrimary: true });
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return createRecoveryCharterQuote(actor, { treasuryActor: actor, createChatMessage, whisper, preferPrimary: false });
    }
  };
  api.CharterPayoutAPI = {
    calculate: async ({ actor, actorId, actorUuid } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterPayoutAPI.calculate could not resolve the target ship actor.");
      return calculateRecoveryCharterPayout(resolvedActor);
    },
    payoutForShip: async ({ actor, actorId, actorUuid, createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("CharterPayoutAPI.payoutForShip could not resolve the target ship actor.");
      return createRecoveryCharterPayoutCard(resolvedActor, { createChatMessage, whisper });
    },
    payoutSelectedShip: async ({ createChatMessage = true, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return createRecoveryCharterPayoutCard(actor, { createChatMessage, whisper });
    }
  };
  api.SalvageAPI = {
    calculate: async ({ actor, actorId, actorUuid, rollTotal = null, source = null, notes = "" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.calculate could not resolve the target ship actor.");
      return calculateSalvageOutcome(resolvedActor, { rollTotal, source, notes });
    },
    salvageShip: async ({ actor, actorId, actorUuid, source = null, notes = "", createChatMessage = true, whisper = null } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("SalvageAPI.salvageShip could not resolve the target ship actor.");
      return salvageShipToTreasury(resolvedActor, { source, notes, createChatMessage, whisper });
    },
    salvageSelectedShip: async ({ createChatMessage = true, notes = "", source = null, whisper = null } = {}) => {
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("Select exactly one ship token to salvage.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return salvageShipToTreasury(actor, { source, notes, createChatMessage, whisper });
    }
  };
  api.ChopShopAPI = {
    getCurrentShip: async () => {
      const primary = await getPrimaryTreasuryShipActor();
      if (primary) return primary;
      const controlled = Array.from(canvas?.tokens?.controlled ?? []);
      if (controlled.length !== 1) throw new Error("No primary treasury ship is set. Select exactly one vehicle token.");
      const actor = controlled[0]?.actor;
      if (!actor || actor.type !== "vehicle") throw new Error("Selected token is not a vehicle ship.");
      return actor;
    },
    calculate: async ({ actor, actorId, actorUuid, item, itemId, shopTier = "established" } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.calculate could not resolve the target ship actor.");
      const resolvedItem = item ?? (itemId ? resolvedActor.items.get(itemId) : null);
      if (!resolvedItem) throw new Error("ChopShopAPI.calculate could not resolve the target component item.");
      return calculateChopShopOutcome(resolvedActor, resolvedItem, { shopTier });
    },
    getComponents: async ({ actor, actorId, actorUuid, includeDestroyed = false } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId) ?? await api.ChopShopAPI.getCurrentShip();
      return getChopShopComponents(resolvedActor, { includeDestroyed });
    },
    processComponent: async ({ actor, actorId, actorUuid, item, itemId, shopTier = "established", createChatMessage = true } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.processComponent could not resolve the target ship actor.");
      const resolvedItem = item ?? (itemId ? resolvedActor.items.get(itemId) : null);
      if (!resolvedItem) throw new Error("ChopShopAPI.processComponent could not resolve the target component item.");
      return processChopShopComponent(resolvedActor, resolvedItem, { shopTier, createChatMessage });
    },
    processAll: async ({ actor, actorId, actorUuid, shopTier = "established", createChatMessage = true } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.processAll could not resolve the target ship actor.");
      return processAllChopShopComponents(resolvedActor, { shopTier, createChatMessage });
    },
    openForShip: async ({ actor, actorId, actorUuid } = {}) => {
      const resolvedActor = await resolveActorReference(actor ?? actorUuid ?? actorId);
      if (!resolvedActor) throw new Error("ChopShopAPI.openForShip could not resolve the target ship actor.");
      return openChopShopForActor(resolvedActor);
    },
    openForCurrentShip: async () => {
      const actor = await api.ChopShopAPI.getCurrentShip();
      return openChopShopForActor(actor);
    }
  };
  api.HullGeneratorAPI = {
    createHull: async ({ shipClass, civilianCargo = "normal", renderSheet = true, createChatMessage = true } = {}) => createGeneratedHull({ shipClass, civilianCargo, renderSheet, createChatMessage }),
    openDialog: async () => openHullGeneratorDialog()
  };
  api.RoleManagerAPI = {
    openForActor: async (actorRef) => openRoleManagerForActor(actorRef),
    openForCurrentUser: async (options = {}) => openRoleManagerForCurrentUser(options)
  };
});


Hooks.on("renderActorSheet5eCharacter", (app, html) => {
  injectRoleManagerButton(app, html);
});


function injectRoleManagerButton(app, html) {
  try {
    const actor = app?.actor ?? app?.document ?? null;
    if (!actor || actor.type !== "character") return;
    if (!game.user?.isGM && !actor.isOwner) return;

    const root =
      html?.[0] ??
      html?.element?.[0] ??
      html?.element ??
      app?.element?.[0] ??
      app?.element ??
      document.querySelector(`[data-appid="${app?.appId ?? ""}"]`) ??
      document.querySelector(`[data-application-id="${app?.id ?? ""}"]`) ??
      null;

    if (!root) return;
    if (root.querySelector?.('[data-cnc-role-launcher="true"]')) return;

    const button = document.createElement("button");
    button.type = "button";
    button.dataset.cncRoleLauncher = "true";
    button.className = "cnc-role-launcher";
    button.innerHTML = '<i class="fas fa-anchor"></i> Ship Role';
    button.style.position = "absolute";
    button.style.top = "10px";
    button.style.right = "42px";
    button.style.zIndex = "100";
    button.style.display = "inline-flex";
    button.style.alignItems = "center";
    button.style.gap = "6px";
    button.style.padding = "5px 9px";
    button.style.border = "1px solid rgba(200,185,122,0.65)";
    button.style.borderRadius = "6px";
    button.style.background = "rgba(8,12,24,0.96)";
    button.style.color = "#c8b97a";
    button.style.cursor = "pointer";
    button.style.fontSize = "12px";
    button.style.boxShadow = "0 0 10px rgba(0,0,0,0.25)";
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      await game.cannonsAndChaos?.RoleManagerAPI?.openForActor?.(actor);
    });

    const positionedRoot =
      root.querySelector(".window-content") ||
      root.querySelector("section.window-content") ||
      root;

    if (positionedRoot instanceof HTMLElement) {
      if (!positionedRoot.style.position) positionedRoot.style.position = "relative";
      positionedRoot.appendChild(button);
    }
  } catch (err) {
    console.warn(`${MODULE_ID} | Failed to inject Role Manager button`, err);
  }
}

