
import { MODULE_ID } from "./helpers/derived.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

export const ROLE_RULES = {
  milestonePcLevels: [8, 14],
  roles: [
    {
      id: "captain",
      label: "Captain",
      theme: "Morale, Command, Momentum",
      tiers: {
        1: [
          {
            id: "captain_t1_command_relay",
            name: "Command Relay",
            description: "Once per round when a crew member succeeds on an action, the Captain can choose another crew member: they automatically succeed their next action as well."
          },
          {
            id: "captain_t1_directed_fire",
            name: "Directed Fire",
            description: "When the Captain uses Inspire Crew successfully on a Gunner, the weapon fired by that Gunner deals +1 additional damage die."
          },
          {
            id: "captain_t1_crew_discipline",
            name: "Crew Discipline",
            description: "The Captain selects one crew member per turn: that party member has one extra action to spend (you may select yourself)."
          }
        ],
        2: [
          {
            id: "captain_t2_keep_the_momentum",
            name: "Keep the momentum!",
            description: "The first time your ship deals damage in a round, gain 1 power point."
          },
          {
            id: "captain_t2_some_of_you_may_die",
            name: "Some of you may die, but that is a sacrifice I am willing to make…",
            description: "The Captain may cause the ship to completely avoid the damage of all weapon attacks for one round by sacrificing any and all passengers."
          },
          {
            id: "captain_t2_keep_trying_you_fools",
            name: "Keep trying you fools!",
            description: "When a PC fails a repair, extinguish fire, or Overcharge roll, the Captain may immediately allow the roll to be attempted again with a +2 bonus."
          }
        ],
        3: [
          {
            id: "captain_t3_press_the_advantage",
            name: "Press the advantage",
            description: "Once per combat when your ship destroys a component or reduces an enemy ship below half HP, the crew gains advantage for the turn."
          },
          {
            id: "captain_t3_unyielding",
            name: "Unyielding",
            description: "Once per combat when the ship would be reduced to 0 hull HP, it instead remains at 10 HP."
          },
          {
            id: "captain_t3_master_and_commander",
            name: "Master and Commander",
            description: "At the start of each round the Captain may move 1 Drift Token between ships involved in combat (remove from one ship and give to another)."
          }
        ]
      }
    },
    {
      id: "helm_officer",
      label: "Helm Officer",
      theme: "Maneuvering, Positioning, Firing Angles",
      tiers: {
        1: [
          {
            id: "helm_officer_t1_cut_the_engines_and_coast",
            name: "Cut the engines and coast…",
            description: "The first turn made during movement each round does not cost movement."
          },
          {
            id: "helm_officer_t1_defensive_drift",
            name: "Defensive Drift",
            description: "After expending all available movement, increase ship AC by +1 until the end of the round."
          },
          {
            id: "helm_officer_t1_slip_position",
            name: "Slip Position",
            description: "If your ship begins the round adjacent to an enemy ship, you may immediately move 1 hex away (this does not count against your total movement)."
          }
        ],
        2: [
          {
            id: "helm_officer_t2_reserve_power_to_engines",
            name: "Reserve power to engines!",
            description: "Once per round you may spend 1 power to increase movement by +2 hexes this round."
          },
          {
            id: "helm_officer_t2_confusing_paint_job",
            name: "Confusing Paint Job",
            description: "If your movement passes directly through an enemy ship’s firing arc, that enemy suffers −1 to attack rolls against you until the end of their next turn."
          },
          {
            id: "helm_officer_t2_vicious_flanking_action",
            name: "Vicious Flanking Action",
            description: "If you end movement in a hex behind an enemy ship’s stern arc, the first weapon fired at that ship this round deals +2 additional damage dice."
          }
        ],
        3: [
          {
            id: "helm_officer_t3_perfect_alignment",
            name: "Perfect Alignment",
            description: "When your ship crosses the T, you gain +2 to additional damage dice instead of +1."
          },
          {
            id: "helm_officer_t3_fast_and_furious_astral_drift",
            name: "Fast and Furious: Astral Drift",
            description: "Once per round after moving, rotate the ship freely to any facing."
          },
          {
            id: "helm_officer_t3_ghost_run",
            name: "Ghost Run",
            description: "If you successfully cross the T and attack, you gain one additional full movement afterward."
          }
        ]
      }
    },
    {
      id: "engineer",
      label: "Engineer",
      theme: "Power Economy, Repairs, Fire Management",
      tiers: {
        1: [
          {
            id: "engineer_t1_efficient_conduits",
            name: "Efficient Conduits",
            description: "When Overcharge Power Core succeeds, restore +1 additional power."
          },
          {
            id: "engineer_t1_rapid_fire_control",
            name: "Rapid Fire Control",
            description: "If a fire would start, roll an additional d6. On 4-6, the fire is immediately extinguished."
          },
          {
            id: "engineer_t1_field_repair_teams",
            name: "Field Repair Teams",
            description: "When repairing a component, restore an additional 1d10 HP."
          }
        ],
        2: [
          {
            id: "engineer_t2_power_redistribution",
            name: "Power Redistribution",
            description: "Shut down one ship system for the turn in order to make more power points available. Choose between Helm, Engines, Weapons, or Utility Hardpoints. Those systems are unavailable for this turn, but you gain 4 additional power points."
          },
          {
            id: "engineer_t2_reinforced_machinery",
            name: "Reinforced Machinery",
            description: "The first component that would be destroyed in combat instead remains at 5 HP."
          },
          {
            id: "engineer_t2_heat_sink_arrays",
            name: "Heat Sink Arrays",
            description: "Weapons that normally cost 2 or more power cost 1 less power the first time they fire each round."
          }
        ],
        3: [
          {
            id: "engineer_t3_arcane_stabilizers",
            name: "Arcane Stabilizers",
            description: "The ship ignores the first instance of hull damage each round."
          },
          {
            id: "engineer_t3_emergency_hull_patch",
            name: "Emergency Hull Patch",
            description: "Once per combat restore 10d10 hull HP."
          },
          {
            id: "engineer_t3_power_core_mastery",
            name: "Power Core Mastery",
            description: "Each turn, you may spend 2 of your actions to increase the ship's power point pool by +3."
          }
        ]
      }
    },
    {
      id: "navigator",
      label: "Navigator",
      theme: "Drift Control, Positioning, Tactics",
      tiers: {
        1: [
          {
            id: "navigator_t1_battle_anticipation",
            name: "Battle Anticipation",
            description: "At the start of combat, your ship automatically gains 1 Drift Token regardless of its positioning."
          },
          {
            id: "navigator_t1_charted_routes",
            name: "Charted Routes",
            description: "When gaining a Drift Token, you may move the ship 1 hex."
          },
          {
            id: "navigator_t1_wise_distribution_of_resources",
            name: "Wise Distribution of Resources",
            description: "Whenever you would gain a Drift Token, you may choose to instead gain a power point."
          }
        ],
        2: [
          {
            id: "navigator_t2_astral_savant",
            name: "Astral Savant",
            description: "Drift Tokens may be spent to gain +3 movement instead of +2."
          },
          {
            id: "navigator_t2_tactical_map",
            name: "Tactical Map",
            description: "Once per round the Navigator may designate a hex. The first weapon attack targeting a ship in that hex deals +3 damage dice."
          },
          {
            id: "navigator_t2_spatial_awareness",
            name: "Spatial Awareness",
            description: "If an enemy ship moves into a hex adjacent to your ship, gain 1 power point."
          }
        ],
        3: [
          {
            id: "navigator_t3_platinum_drift",
            name: "Platinum Drift",
            description: "Maximum Drift Tokens increases from 3 to 5."
          },
          {
            id: "navigator_t3_battlefield_geometry",
            name: "Battlefield Geometry",
            description: "When an enemy ship crosses your T, you may use an action to have your ship gain +2 AC until the end of the turn."
          },
          {
            id: "navigator_t3_celestial_vectoring",
            name: "Celestial Vectoring",
            description: "Once per round you may rotate the ship 90° without affecting its movement."
          }
        ]
      }
    },
    {
      id: "gunner",
      label: "Gunner",
      theme: "Weapons, Damage, Targeting",
      tiers: {
        1: [
          {
            id: "gunner_t1_heavy_hand",
            name: "Heavy Hand",
            description: "Weapon damage rolls of 1 or 2 are rerolled."
          },
          {
            id: "gunner_t1_armor_cracker",
            name: "Armor Cracker",
            description: "Your weapon attacks reduce the target’s Damage Threshold by 4 for that attack."
          },
          {
            id: "gunner_t1_swift_reload",
            name: "Swift Reload",
            description: "After firing a weapon, you may reload it immediately, with no action cost, once per round."
          }
        ],
        2: [
          {
            id: "gunner_t2_overcharged_shot",
            name: "Overcharged Shot",
            description: "Before rolling damage, spend 1 power to add +2 damage dice."
          },
          {
            id: "gunner_t2_targeted_barrage",
            name: "Targeted Barrage",
            description: "If you target a component and hit, deal an additional 2d10 damage."
          },
          {
            id: "gunner_t2_suppressive_fire",
            name: "Suppressive Fire",
            description: "If your weapon deals hull damage, the target ship loses 1 movement next round."
          }
        ],
        3: [
          {
            id: "gunner_t3_catastrophic_impact",
            name: "Catastrophic Impact",
            description: "Whenever you hit with a powered weapon, roll a d6. On a 5–6 the target gains a fire."
          },
          {
            id: "gunner_t3_weapon_savant",
            name: "Weapon Savant",
            description: "Once per round you may fire a weapon without spending its power cost."
          },
          {
            id: "gunner_t3_devastator",
            name: "Devastator",
            description: "When a weapon destroys a component, deal half the damage rolled to the ship’s hull as well."
          }
        ]
      }
    }
  ]
};

const ROLE_INDEX = new Map();
for (const role of ROLE_RULES.roles) {
  for (const [tier, abilities] of Object.entries(role.tiers)) {
    for (const ability of abilities) {
      ROLE_INDEX.set(ability.id, {
        ...ability,
        roleId: role.id,
        roleLabel: role.label,
        roleTheme: role.theme,
        tier: Number(tier)
      });
    }
  }
}

const ROLE_ABILITY_ROLLS = {
  engineer_t1_rapid_fire_control: {
    formula: "1d6",
    label: "Rapid Fire Control",
    successText: "On 4–6, the fire is immediately extinguished."
  },
  engineer_t1_field_repair_teams: {
    formula: "1d10",
    label: "Field Repair Teams",
    resultLabel: "Additional component HP restored"
  },
  engineer_t3_emergency_hull_patch: {
    formula: "10d10",
    label: "Emergency Hull Patch",
    resultLabel: "Hull HP restored"
  },
  gunner_t2_targeted_barrage: {
    formula: "2d10",
    label: "Targeted Barrage",
    resultLabel: "Additional component damage"
  },
  gunner_t3_catastrophic_impact: {
    formula: "1d6",
    label: "Catastrophic Impact",
    successText: "On 5–6, the target gains a fire."
  }
};

function getAbilityRollConfig(abilityId) {
  return ROLE_ABILITY_ROLLS[String(abilityId ?? "")] ?? null;
}


function getPcLevel(actor) {
  const raw = Number(actor?.system?.details?.level ?? actor?.system?.details?.cr ?? 0);
  return Number.isFinite(raw) ? raw : 0;
}

export function getRoleData(actor) {
  const data = foundry.utils.deepClone(actor?.getFlag?.(MODULE_ID, "roleData") ?? {});
  data.picks ??= [];
  return data;
}

function hasTier(roleData, roleId, tier) {
  return roleData.picks.some((pick) => String(pick.roleId) === String(roleId) && Number(pick.tier) === Number(tier));
}

function getEarnedPicks(actor, roleData) {
  const pcLevel = getPcLevel(actor);
  const initialAwarded = roleData.initialAwarded === true || (Array.isArray(roleData.picks) && roleData.picks.length > 0);
  let earned = initialAwarded ? 1 : 0;
  for (const level of ROLE_RULES.milestonePcLevels) {
    if (pcLevel >= level) earned += 1;
  }
  return earned;
}

function getAvailableAbilities(actor, roleData) {
  const remaining = getEarnedPicks(actor, roleData) - roleData.picks.length;
  const byTier = { 1: [], 2: [], 3: [] };

  for (const role of ROLE_RULES.roles) {
    const has1 = hasTier(roleData, role.id, 1);
    const has2 = hasTier(roleData, role.id, 2);
    const has3 = hasTier(roleData, role.id, 3);

    if (!has1) {
      for (const ability of role.tiers[1]) byTier[1].push({ ...ability, roleId: role.id, roleLabel: role.label, roleTheme: role.theme, tier: 1, canAcquire: remaining > 0 });
    }
    if (has1 && !has2) {
      for (const ability of role.tiers[2]) byTier[2].push({ ...ability, roleId: role.id, roleLabel: role.label, roleTheme: role.theme, tier: 2, canAcquire: remaining > 0 });
    }
    if (has2 && !has3) {
      for (const ability of role.tiers[3]) byTier[3].push({ ...ability, roleId: role.id, roleLabel: role.label, roleTheme: role.theme, tier: 3, canAcquire: remaining > 0 });
    }
  }

  return byTier;
}

export function getAcquiredAbilities(actor, roleData) {
  return (roleData.picks ?? []).map((pick) => {
    const indexed = ROLE_INDEX.get(pick.id) ?? {};
    return {
      id: pick.id,
      roleId: pick.roleId ?? indexed.roleId,
      roleLabel: pick.roleLabel ?? indexed.roleLabel ?? pick.roleId,
      roleTheme: indexed.roleTheme ?? "",
      tier: Number(pick.tier ?? indexed.tier ?? 0),
      name: pick.name ?? indexed.name ?? "Role Ability",
      description: pick.description ?? indexed.description ?? "",
      rollConfig: getAbilityRollConfig(pick.id ?? indexed.id ?? ""),
      acquiredAtPcLevel: Number(pick.acquiredAtPcLevel ?? 0),
      acquiredAt: Number(pick.acquiredAt ?? 0)
    };
  }).sort((a, b) => (a.roleLabel.localeCompare(b.roleLabel) || a.tier - b.tier || a.name.localeCompare(b.name)));
}

function buildChatCard(actor, ability, rollResult = null) {
  const rollConfig = ability?.rollConfig ?? getAbilityRollConfig(ability?.id);
  const rollBlock = rollConfig ? `
      <div class="cnc-role-chat-card__roll">
        <strong>Roll:</strong> ${foundry.utils.escapeHTML(rollConfig.formula)}
        ${rollConfig.resultLabel ? `<div>${foundry.utils.escapeHTML(rollConfig.resultLabel)}</div>` : ""}
        ${rollConfig.successText ? `<div>${foundry.utils.escapeHTML(rollConfig.successText)}</div>` : ""}
      </div>` : "";
  const resultBlock = rollResult ? `
      <div class="cnc-role-chat-card__result">
        <strong>Result:</strong> ${foundry.utils.escapeHTML(String(rollResult.total))}
      </div>` : "";
  return `
    <div class="cnc-role-chat-card">
      <div class="cnc-role-chat-card__eyebrow">${foundry.utils.escapeHTML(ability.roleLabel)} — Tier ${ability.tier}</div>
      <h3 class="cnc-role-chat-card__title">${foundry.utils.escapeHTML(ability.name)}</h3>
      <div class="cnc-role-chat-card__body">${foundry.utils.escapeHTML(ability.description).replace(/\n/g, "<br>")}</div>
      ${rollBlock}
      ${resultBlock}
      <div class="cnc-role-chat-card__footer">${foundry.utils.escapeHTML(actor.name)}</div>
    </div>
  `;
}

export async function useRoleAbility(actor, ability) {
  const rollConfig = ability?.rollConfig ?? getAbilityRollConfig(ability?.id);
  let evaluatedRoll = null;
  if (rollConfig?.formula) {
    evaluatedRoll = await (new Roll(rollConfig.formula)).evaluate({ async: true });
    await evaluatedRoll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor }),
      flavor: `${ability.roleLabel} — ${ability.name}`
    });
  }
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: buildChatCard(actor, ability, evaluatedRoll)
  });
}


function getAssignableCharacters() {
  return game.actors
    .filter(actor => actor?.type === "character" && actor.testUserPermission?.(game.user, "OWNER"))
    .sort((a, b) => String(a.name ?? "").localeCompare(String(b.name ?? "")));
}

async function resolveAssignedRoleActorForUser() {
  const saved = await game.user.getFlag(MODULE_ID, "roleManagerActorUuid");
  if (!saved) return null;
  try {
    const actor = await fromUuid(saved);
    if (actor?.documentName === "Actor" && actor.type === "character" && actor.testUserPermission?.(game.user, "OWNER")) {
      return actor;
    }
  } catch (err) {
    console.warn(`${MODULE_ID} | Could not resolve assigned Role Manager actor`, err);
  }
  return null;
}

async function chooseAssignedCharacterDialog() {
  const choices = getAssignableCharacters();
  if (!choices.length) {
    ui.notifications?.warn("You do not own any PC character sheets that can use the Role Manager.");
    return null;
  }

  const current = await game.user.getFlag(MODULE_ID, "roleManagerActorUuid");
  const options = choices.map(actor => {
    const selected = String(actor.uuid ?? "") === String(current ?? "") ? "selected" : "";
    return `<option value="${foundry.utils.escapeHTML(String(actor.uuid ?? ""))}" ${selected}>${foundry.utils.escapeHTML(String(actor.name ?? "Unnamed Character"))}</option>`;
  }).join("");

  return await new Promise(resolve => {
    new Dialog({
      title: "Choose Your Role Manager Character",
      content: `
        <form>
          <div class="form-group">
            <label>Character</label>
            <select name="actorUuid">${options}</select>
          </div>
          <p>Select the PC whose Ship Role manager should open for you. This choice will be remembered.</p>
        </form>
      `,
      buttons: {
        confirm: {
          label: "Open Role Manager",
          callback: async html => {
            const selectedUuid = String(html.find('[name="actorUuid"]').val() || "");
            if (!selectedUuid) return resolve(null);
            try {
              const actor = await fromUuid(selectedUuid);
              if (actor?.documentName === "Actor" && actor.type === "character") {
                await game.user.setFlag(MODULE_ID, "roleManagerActorUuid", selectedUuid);
                await openRoleManagerForActor(actor);
      resolve(actor);
                return;
              }
            } catch (err) {
              console.warn(`${MODULE_ID} | Failed to set assigned Role Manager character`, err);
            }
            resolve(null);
          }
        },
        cancel: {
          label: "Cancel",
          callback: () => resolve(null)
        }
      },
      default: "confirm",
      close: () => resolve(null)
    }).render(true);
  });
}

export async function openRoleManagerForCurrentUser({ forceChoose = false } = {}) {
  let actor = null;
  if (!forceChoose) {
    actor = await resolveAssignedRoleActorForUser();
  }
  if (!actor) {
    actor = await chooseAssignedCharacterDialog();
  }
  if (!actor) return null;
  return openRoleManagerForActor(actor);
}

export async function openRoleManagerForActor(actor) {
  let resolved = actor;
  if (typeof actor === "string") {
    resolved = game.actors?.get?.(actor) ?? await fromUuid(actor).catch(() => null);
  }
  if (!resolved || resolved.documentName !== "Actor" || resolved.type !== "character") {
    ui.notifications?.warn("Role Manager can only be opened for PC character actors.");
    return null;
  }
  const app = new RoleManagerApp({ actor: resolved });
  await app.render(true);
  return app;
}

export class RoleManagerApp extends HandlebarsApplicationMixin(ApplicationV2) {
  constructor({ actor }, options = {}) {
    super(options);
    this.actor = actor;
  }

  static DEFAULT_OPTIONS = foundry.utils.mergeObject(foundry.utils.deepClone(super.DEFAULT_OPTIONS), {
    id: "cannons-and-chaos-role-manager",
    classes: ["cnd5e2", "cnc-role-manager-app"],
    tag: "section",
    position: {
      width: 1120,
      height: 900
    },
    window: {
      title: "Cannons & Chaos — Role Manager",
      resizable: true
    }
  });

  static PARTS = {
    main: {
      template: "modules/cannons-and-chaos/templates/role-manager.hbs"
    }
  };

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const roleData = getRoleData(this.actor);
    const pcLevel = getPcLevel(this.actor);
    const initialAwarded = roleData.initialAwarded === true || roleData.picks.length > 0;
    const earnedPicks = getEarnedPicks(this.actor, roleData);
    const spentPicks = roleData.picks.length;
    const remainingPicks = Math.max(0, earnedPicks - spentPicks);
    const acquired = getAcquiredAbilities(this.actor, roleData);
    const available = getAvailableAbilities(this.actor, roleData);

    return {
      ...context,
      actor: this.actor,
      pcLevel,
      initialAwarded,
      earnedPicks,
      spentPicks,
      remainingPicks,
      canAwardInitial: !initialAwarded,
      acquiredAbilities: acquired.map((a) => ({ ...a, hasRoll: !!getAbilityRollConfig(a.id) })),
      availableSections: [
        { tier: 1, label: "Tier I — New Role", abilities: available[1].map((a) => ({ ...a, hasRoll: !!getAbilityRollConfig(a.id) })) },
        { tier: 2, label: "Tier II — Upgrade Existing Role", abilities: available[2].map((a) => ({ ...a, hasRoll: !!getAbilityRollConfig(a.id) })) },
        { tier: 3, label: "Tier III — Master Existing Role", abilities: available[3].map((a) => ({ ...a, hasRoll: !!getAbilityRollConfig(a.id) })) }
      ],
      roleSummary: ROLE_RULES.roles.map((role) => ({
        id: role.id,
        label: role.label,
        theme: role.theme,
        has1: hasTier(roleData, role.id, 1),
        has2: hasTier(roleData, role.id, 2),
        has3: hasTier(roleData, role.id, 3)
      }))
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const root = this.element;
    if (!root) return;

    root.querySelectorAll("[data-action]").forEach((el) => {
      el.addEventListener("click", this.#onAction.bind(this));
    });
  }

  async #onAction(event) {
    event.preventDefault?.();
    const action = String(event.currentTarget?.dataset?.action ?? "");
    if (!action) return;

    const roleData = getRoleData(this.actor);

    if (action === "award-initial-role") {
      roleData.initialAwarded = true;
      await this.actor.setFlag(MODULE_ID, "roleData", roleData);
      return this.render(true);
    }

    if (action === "change-assigned-character") {
      const nextApp = await openRoleManagerForCurrentUser({ forceChoose: true });
      if (nextApp) await this.close();
      return;
    }

    if (action === "send-role-to-chat") {
      const abilityId = String(event.currentTarget.dataset.abilityId ?? "");
      const ability = getAcquiredAbilities(this.actor, roleData).find((a) => a.id === abilityId);
      if (!ability) return;
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: this.actor }),
        content: buildChatCard(this.actor, ability)
      });
      return;
    }

    if (action === "use-role-ability") {
      const abilityId = String(event.currentTarget.dataset.abilityId ?? "");
      const ability = getAcquiredAbilities(this.actor, roleData).find((a) => a.id === abilityId);
      if (!ability) return;
      await useRoleAbility(this.actor, ability);
      return;
    }

    if (action === "acquire-role-ability") {
      const abilityId = String(event.currentTarget.dataset.abilityId ?? "");
      const ability = ROLE_INDEX.get(abilityId);
      if (!ability) return;

      const available = getAvailableAbilities(this.actor, roleData);
      const legal = [...available[1], ...available[2], ...available[3]].some((a) => a.id === abilityId);
      const remainingPicks = Math.max(0, getEarnedPicks(this.actor, roleData) - roleData.picks.length);
      if (!legal || remainingPicks <= 0) {
        ui.notifications?.warn("That Role ability is not currently available.");
        return;
      }

      roleData.picks.push({
        id: ability.id,
        roleId: ability.roleId,
        roleLabel: ability.roleLabel,
        tier: ability.tier,
        name: ability.name,
        description: ability.description,
        acquiredAtPcLevel: getPcLevel(this.actor),
        acquiredAt: Date.now()
      });

      await this.actor.setFlag(MODULE_ID, "roleData", roleData);
      ui.notifications?.info(`${this.actor.name} acquired ${ability.name}.`);
      return this.render(true);
    }
  }
}

export function injectRoleManagerButton(app, html) {
  return;
}
