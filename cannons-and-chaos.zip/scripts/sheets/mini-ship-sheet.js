import { NavalShipSheet } from "./ship-sheet.js";

export class MiniNavalShipSheet extends NavalShipSheet {
  static DEFAULT_OPTIONS = foundry.utils.mergeObject(foundry.utils.deepClone(NavalShipSheet.DEFAULT_OPTIONS), {
    id: "cannons-and-chaos-mini-ship-sheet",
    classes: [...new Set([...(NavalShipSheet.DEFAULT_OPTIONS.classes ?? []), "naval-ship-sheet--mini"])],
    position: {
      width: 1120,
      height: 760
    }
  });

  static PARTS = {
    ...NavalShipSheet.PARTS,
    sheet: {
      template: "modules/cannons-and-chaos/templates/mini-ship-sheet.hbs"
    }
  };

  get title() {
    return `${this.document.name} — MINI C&C Vehicle Sheet`;
  }
}
