import {
  MODULE_ID,
  CNC_MODULE_ID,
  prepareNavalContext,
  validateItemForSlot,
  markItemInstalled,
  ensureShipComponentsHydrated,
  ensureWeaponLoadState,
  ensureComponentStates,
  ensureTurnPowerState,
  ensureTreasuryState,
  addTreasuryTransaction,
  setPrimaryTreasuryShip,
  transferTreasuryToShip,
  buildCncFlagsForItem,
  getHullData,
  getSheetState,
  getResolvedComponentType,
  getResolvedArc,
  getResolvedPowerCost,
  getWeaponLoadedState,
  getWeaponLoadStates,
  ensureItemHasEmbeddedFlags,
  getComponentState
} from "../helpers/derived.js";

const { ActorSheetV2 } = foundry.applications.sheets;
const { HandlebarsApplicationMixin } = foundry.applications.api;

function normalizeArcLabel(value) {
  const normalized = String(value ?? "").trim().toLowerCase();
  if (normalized === "stern") return "aft";
  return normalized;
}

const PENDING_FIRE_BURST = new Map();

function matchesArc(actor, item, arc) {
  const sheetState = getSheetState(actor);
  const hull = getHullData(actor);
  const itemId = item?.id ?? item?._id ?? null;
  const assignedArc = itemId ? sheetState?.battleArcAssignments?.[itemId] : null;
  const installedArc = itemId ? (hull?.installed?.weapons ?? []).find(w => w?.id === itemId)?.arc : null;
  const resolvedArc = assignedArc ?? installedArc ?? getResolvedArc(item);
  return normalizeArcLabel(resolvedArc) === normalizeArcLabel(arc);
}

function getPrimaryDamageFormula(item, extraDice = 0, critical = false) {
  const base = item?.system?.damage?.base ?? {};
  const count = Math.max(0, Number(base?.number ?? 0));
  const faces = Math.max(0, Number(base?.denomination ?? 0));
  const bonus = String(base?.bonus ?? "").trim();
  if (!count || !faces) return null;

  let finalCount = count + Math.max(0, Number(extraDice ?? 0));
  if (critical) finalCount *= 2;

  let formula = `${finalCount}d${faces}`;
  if (bonus) {
    const trimmed = bonus.replace(/^\s*\+\s*/, "").trim();
    if (trimmed) formula += ` + ${trimmed}`;
  }
  return formula;
}

function getWeaponAttackModifier(actor, item) {
  const naval = prepareNavalContext(actor);
  const shared = Number(naval?.derivedShip?.weapons?.attackBonus ?? 0);
  const activitiesRaw = item?.system?.activities ?? item?.activities ?? {};
  const activities = Array.isArray(activitiesRaw) ? activitiesRaw : Object.values(activitiesRaw ?? {});
  const activity = activities[0] ?? {};
  const activityBonus = Number(activity?.attack?.bonus ?? 0);
  return shared + (Number.isFinite(activityBonus) ? activityBonus : 0);
}

function getDamageTypeLabel(item) {
  const base = item?.system?.damage?.base ?? {};
  const types = Array.isArray(base?.types) ? base.types.filter(Boolean) : [];
  return types.join(", ") || "damage";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export class NavalShipSheet extends HandlebarsApplicationMixin(ActorSheetV2) {
  static DEFAULT_OPTIONS = foundry.utils.mergeObject(foundry.utils.deepClone(super.DEFAULT_OPTIONS), {
    id: "cannons-and-chaos-ship-sheet",
    classes: ["dnd5e2", "sheet", "actor", "vehicle", "naval-ship-sheet"],
    tag: "form",
    form: {
      submitOnChange: true,
      closeOnSubmit: false
    },
    position: {
      width: 1600,
      height: 980
    },
    window: {
      resizable: true
    },
    dragDrop: [
      {
        dragSelector: "[data-item-id]",
        dropSelector: "[data-slot-drop], [data-cargo-drop], [data-crew-drop]"
      }
    ]
  });

  static PARTS = {
    sheet: {
      template: "modules/cannons-and-chaos/templates/ship-sheet.hbs"
    }
  };

  get title() {
    const ship = this.document?.getFlag?.(CNC_MODULE_ID, "ship") === true ? "Cannons & Chaos Ship" : "Naval Sheet";
    return `${this.document.name} — ${ship}`;
  }

  async _prepareContext(options) {
    await ensureShipComponentsHydrated(this.document);
    await ensureWeaponLoadState(this.document);
    await ensureComponentStates(this.document);
    await ensureTurnPowerState(this.document);
    await ensureTreasuryState(this.document);
    const context = await super._prepareContext(options);
    const naval = prepareNavalContext(this.document);

    return {
      ...context,
      actor: this.document,
      system: this.document.system,
      naval,
      editable: this.isEditable,
      owner: this.document.isOwner
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);

    const html = this.element;
    if (!html) return;

    html.querySelectorAll("[data-crew-drop]").forEach((el) => {
      el.addEventListener("dragover", (event) => {
        event.preventDefault();
        el.classList.add("wh-crew-dropzone--active");
      });
      el.addEventListener("dragleave", () => {
        el.classList.remove("wh-crew-dropzone--active");
      });
      el.addEventListener("drop", async (event) => {
        event.preventDefault();
        event.stopPropagation();
        el.classList.remove("wh-crew-dropzone--active");
        await this._onDrop(event);
      });
    });

    html.querySelectorAll("[data-action]").forEach((el) => {
      el.addEventListener("click", this.#onAction.bind(this));
    });

    html.querySelectorAll("[data-item-open]").forEach((el) => {
      el.addEventListener("click", (event) => {
        if (event.target.closest("button, input, textarea, select, label, a")) return;
        const itemId = el.dataset.itemOpen;
        const item = this.document.items.get(itemId);
        if (!item) return;
        item.sheet?.render?.(true);
      });
    });

    html.querySelectorAll("[data-cargo-field]").forEach((el) => {
      el.addEventListener("change", this.#onCargoFieldChange.bind(this));
    });

    html.querySelectorAll("[data-crew-field]").forEach((el) => {
      el.addEventListener("change", this.#onCrewFieldChange.bind(this));
    });

    html.querySelectorAll("[data-component-field]").forEach((el) => {
      el.addEventListener("change", this.#onComponentFieldChange.bind(this));
    });

    html.querySelectorAll('[data-action="set-hull-hp"]').forEach((el) => {
      const commitHullHp = async (event) => {
        event.preventDefault?.();
        event.stopPropagation?.();
        event.stopImmediatePropagation?.();

        const maxHull = Math.max(0, Number(this.actor.system?.attributes?.hp?.max ?? 0));
        const currentHull = Math.max(0, Number(this.actor.system?.attributes?.hp?.value ?? 0));
        const rawValue = String(event.currentTarget.value ?? "").trim();

        let parsedHull = currentHull;
        if (/^[+-]\d+$/.test(rawValue)) {
          parsedHull = currentHull + Number(rawValue);
        } else if (/^\d+$/.test(rawValue)) {
          parsedHull = Number(rawValue);
        }

        const nextHull = Math.max(0, Math.min(maxHull, parsedHull));
        event.currentTarget.value = String(nextHull);

        await this.actor.update({ "system.attributes.hp.value": nextHull });

        await this.#rememberActiveTab();
        return this.render(true);
      };

      el.addEventListener("change", commitHullHp);
      el.addEventListener("keydown", async (event) => {
        if (event.key !== "Enter") return;
        await commitHullHp(event);
      });
    });

    html.querySelectorAll('[data-action="rename-ship"]').forEach((el) => {
      const commitRename = async (event) => {
        event.preventDefault?.();
        event.stopPropagation?.();
        event.stopImmediatePropagation?.();

        const newName = String(event.currentTarget.value ?? "").trim();
        if (!newName || newName === this.actor.name) {
          event.currentTarget.value = this.actor.name;
          return;
        }

        await this.actor.update({ name: newName });
        await this.#rememberActiveTab();
        return this.render(true);
      };

      el.addEventListener("change", commitRename);
      el.addEventListener("keydown", async (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          await commitRename(event);
        }
        if (event.key === "Escape") {
          event.currentTarget.value = this.actor.name;
          event.currentTarget.blur();
        }
      });
      // Prevent the sheet's global click handler from swallowing focus
      el.addEventListener("click", (event) => event.stopPropagation());
    });

    html.querySelectorAll('.wh-tab').forEach((el) => {
      el.addEventListener("click", async () => {
        const tab = el.dataset.tab;
        html.querySelectorAll(".wh-tab").forEach((tabEl) => tabEl.classList.remove("active"));
        html.querySelectorAll(".wh-tab-panel").forEach((panel) => panel.classList.remove("active"));
        html.querySelector(`.wh-tab[data-tab="${tab}"]`)?.classList.add("active");
        html.querySelector(`.wh-tab-panel[data-tab-panel="${tab}"]`)?.classList.add("active");
        await this.#rememberActiveTab(tab);
      });
    });

    const savedTab = this.document.getFlag(MODULE_ID, "sheetState")?.activeTab;
    if (savedTab) {
      html.querySelectorAll(".wh-tab").forEach((tabEl) => tabEl.classList.remove("active"));
      html.querySelectorAll(".wh-tab-panel").forEach((panel) => panel.classList.remove("active"));
      html.querySelector(`.wh-tab[data-tab="${savedTab}"]`)?.classList.add("active");
      html.querySelector(`.wh-tab-panel[data-tab-panel="${savedTab}"]`)?.classList.add("active");
    }

    this.#renderTreasuryCharts();

    const pendingFireBurstAt = PENDING_FIRE_BURST.get(this.document.id);
    if (pendingFireBurstAt && (Date.now() - pendingFireBurstAt) < 3000) {
      this.#triggerFireBurst(html);
      PENDING_FIRE_BURST.delete(this.document.id);
    }
  }

  #triggerFireBurst(root) {
    const container = root?.querySelector?.(".wh-stat-box--fire") ?? root?.closest?.(".wh-stat-box--fire");
    if (!container) return;

    container.classList.remove("wh-stat-box--fire-burst");
    void container.offsetWidth;
    container.classList.add("wh-stat-box--fire-burst");

    const existing = container.querySelectorAll(".wh-fire-burst-overlay");
    existing.forEach((node) => node.remove());

    const overlay = document.createElement("div");
    overlay.className = "wh-fire-burst-overlay";
    overlay.innerHTML = '<span class="wh-fire-burst-flame"></span><span class="wh-fire-burst-flame"></span><span class="wh-fire-burst-flame"></span><span class="wh-fire-burst-flame"></span><span class="wh-fire-burst-flame"></span><span class="wh-fire-burst-flame"></span>';
    container.appendChild(overlay);

    window.setTimeout(() => {
      container.classList.remove("wh-stat-box--fire-burst");
      overlay.remove();
    }, 2200);
  }

  async #onComponentFieldChange(event) {
    event.preventDefault?.();
    event.stopPropagation?.();
    event.stopImmediatePropagation?.();

    const target = event.currentTarget;
    const itemId = target.dataset.componentId;
    const field = target.dataset.componentField;
    if (!itemId || !field) return;

    const actor = this.document;
    const item = actor.items.get(itemId);
    if (!item) return;

    const sheetState = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "sheetState") ?? {});
    sheetState.combat ??= {};
    sheetState.combat.componentStates ??= {};

    const baseState = foundry.utils.deepClone(getComponentState(actor, item));
    const existingState = foundry.utils.deepClone(sheetState.combat.componentStates[itemId] ?? {});
    const current = {
      ...baseState,
      ...existingState
    };

    const hpMaxExisting = Math.max(0, Number(current.hpMax ?? baseState.hpMax ?? 1));
    const hpCurrentExisting = Math.max(0, Number(current.hpCurrent ?? baseState.hpCurrent ?? hpMaxExisting));

    if (field === "onFire") {
      current.onFire = target.checked === true;
    } else if (field === "ac") {
      current.ac = Math.max(0, Number(target.value ?? current.ac ?? baseState.ac ?? 0));
    } else if (field === "hpMax") {
      current.hpMax = Math.max(0, Number(target.value ?? hpMaxExisting));
      const hpCurrent = Math.max(0, Number(current.hpCurrent ?? hpCurrentExisting));
      current.hpCurrent = Math.min(hpCurrent, current.hpMax);
      if (current.hpCurrent > 0 && current.state !== "destroyed") current.state = "operational";
    } else if (field === "hpCurrent") {
      current.hpMax = Math.max(0, Number(current.hpMax ?? hpMaxExisting));
      const nextHp = Math.max(0, Math.min(Number(target.value ?? hpCurrentExisting), current.hpMax));
      const prevHp = hpCurrentExisting;
      current.hpCurrent = nextHp;

      if (nextHp > 0) {
        current.state = "operational";
      } else if (prevHp > 0 && nextHp === 0) {
        const roll = await (new Roll("1d6")).evaluate({ async: true });
        current.state = roll.total <= 3 ? "disabled" : "destroyed";
        const speaker = ChatMessage.getSpeaker({ actor });
        await ChatMessage.create({
          speaker,
          content: `<div class="cnc-activation-card"><h3>${item.name} Critical State</h3><p><strong>Roll:</strong> ${roll.total} on 1d6</p><p><strong>Result:</strong> ${current.state.charAt(0).toUpperCase() + current.state.slice(1)}</p></div>`
        });
      }
    }

    sheetState.combat.componentStates[itemId] = current;
    await actor.setFlag(MODULE_ID, "sheetState", sheetState);
    await this.#rememberActiveTab();
    return this.render(true);
  }

  async #addCargoEntryFromDropData(data) {
    let dropped = null;

    try {
      dropped = await Item.implementation.fromDropData(data);
    } catch (err) {
      console.warn("cannons-and-chaos | Failed to resolve cargo drop item", err);
    }

    if (!dropped) return false;

    const quantity = Math.max(1, Number(
      dropped.system?.quantity ??
      dropped.system?.uses?.value ??
      dropped.system?.container?.capacity?.count ??
      1
    ));

    const rawWeight = Math.max(0, Number(
      dropped.system?.weight?.value ??
      dropped.system?.weight ??
      0
    ));

    const sourceUnitRaw = String(
      dropped.system?.weight?.units ??
      dropped.system?.weight?.unit ??
      dropped.system?.weightUnit ??
      "lbs"
    ).trim().toLowerCase();

    const weightUnit = (sourceUnitRaw === "ton" || sourceUnitRaw === "tons" || sourceUnitRaw === "t") ? "tons" : "lbs";

    const sheetState = foundry.utils.deepClone(this.document.getFlag(MODULE_ID, "sheetState") ?? {});
    sheetState.cargo ??= {};
    sheetState.cargo.entries ??= [];
    sheetState.cargo.entries.push({
      id: `cargo-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: String(dropped.name ?? "Cargo"),
      qty: quantity,
      weightEach: rawWeight,
      weightUnit,
      notes: ""
    });

    await this.document.setFlag(MODULE_ID, "sheetState", sheetState);
    ui.notifications?.info(`${dropped.name} added to cargo.`);
    await this.#rememberActiveTab("cargo");
    await this.render(true);
    return true;
  }


  async #onCargoFieldChange(event) {
    event.preventDefault?.();
    event.stopPropagation?.();
    event.stopImmediatePropagation?.();

    const target = event.currentTarget;
    const cargoId = target.dataset.cargoId;
    const field = target.dataset.cargoField;
    if (!cargoId || !field) return;

    const actor = this.document;
    const sheetState = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "sheetState") ?? {});
    sheetState.cargo ??= {};
    sheetState.cargo.entries ??= [];

    const idx = sheetState.cargo.entries.findIndex(entry => String(entry?.id) === String(cargoId));
    if (idx === -1) return;

    const entry = foundry.utils.deepClone(sheetState.cargo.entries[idx] ?? {});
    if (field === "name" || field === "notes") {
      entry[field] = String(target.value ?? "");
    } else if (field === "qty") {
      entry.qty = Math.max(0, Number(target.value ?? 0));
    } else if (field === "weightEach" || field === "tonsEach") {
      entry.weightEach = Math.max(0, Number(target.value ?? 0));
    } else if (field === "weightUnit") {
      const rawUnit = String(target.value ?? "lbs").trim().toLowerCase();
      entry.weightUnit = rawUnit === "tons" ? "tons" : "lbs";
    }

    sheetState.cargo.entries[idx] = entry;
    await actor.setFlag(MODULE_ID, "sheetState", sheetState);
    await this.#rememberActiveTab();
    return this.render(true);
  }



  async #openTreasuryAdjustDialog(direction = 1) {
    const actor = this.document;

    return new Promise(resolve => {
      const title = direction > 0 ? "Add Shards" : "Subtract Shards";
      const signLabel = direction > 0 ? "Add" : "Subtract";

      new Dialog({
        title,
        content: `
          <form class="wh-dialog-form">
            <div class="form-group">
              <label>Amount</label>
              <input type="number" name="amount" min="1" step="1" value="0">
            </div>
            <div class="form-group">
              <label>Source</label>
              <input type="text" name="source" value="Manual Adjustment">
            </div>
            <div class="form-group">
              <label>Type</label>
              <select name="type">
                <option value="manual">Manual</option>
                <option value="salvage">Salvage</option>
                <option value="recovery">Recovery</option>
                <option value="purchase">Purchase</option>
                <option value="repair">Repair</option>
                <option value="upgrade">Upgrade</option>
                <option value="adjustment">Adjustment</option>
              </select>
            </div>
            <div class="form-group">
              <label>Notes</label>
              <input type="text" name="notes" value="">
            </div>
          </form>
        `,
        buttons: {
          confirm: {
            label: signLabel,
            callback: async (html) => {
              const amount = Math.max(0, Math.round(Number(html.find('[name="amount"]').val() ?? 0)));
              if (!amount) return;

              const source = String(html.find('[name="source"]').val() ?? "Manual Adjustment").trim() || "Manual Adjustment";
              const type = String(html.find('[name="type"]').val() ?? "manual").trim() || "manual";
              const notes = String(html.find('[name="notes"]').val() ?? "").trim();

              await addTreasuryTransaction(actor, {
                amount: amount * direction,
                source,
                type,
                notes
              });
              await this.#rememberActiveTab("treasury");
              await this.render(true);
            }
          },
          cancel: {
            label: "Cancel"
          }
        },
        default: "confirm",
        close: () => resolve()
      }).render(true);
    });
  }

  async #resetTreasury() {
    const actor = this.document;

    return new Promise(resolve => {
      new Dialog({
        title: "Reset Treasury",
        content: `<p>Clear the shard balance and the entire treasury ledger for this ship?</p>`,
        buttons: {
          yes: {
            label: "Reset",
            callback: async () => {
              const sheetState = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "sheetState") ?? {});
              sheetState.treasury = {
                balance: 0,
                startLevel: Number.isFinite(Number(sheetState.treasury?.startLevel)) ? Number(sheetState.treasury.startLevel) : null,
                linkedShipUuid: actor.uuid,
                ledger: []
              };
              await actor.setFlag(MODULE_ID, "sheetState", sheetState);
              await this.#rememberActiveTab("treasury");
              await this.render(true);
            }
          },
          no: {
            label: "Cancel"
          }
        },
        default: "no",
        close: () => resolve()
      }).render(true);
    });
  }

  #renderTreasuryCharts() {
    const html = this.element;
    if (!html) return;

    const treasury = prepareNavalContext(this.document)?.treasury ?? {};

    const historyCanvas = html.querySelector("[data-treasury-chart]");
    const miniCanvas = html.querySelector("[data-treasury-combat-chart]");
    const chartFallback = html.querySelector(".wh-treasury-chart-fallback");
    const miniFallback = html.querySelector(".wh-treasury-mini-fallback");

    if (historyCanvas) {
      const hasHistory = Array.isArray(treasury?.chart?.values) && treasury.chart.values.length > 1;
      historyCanvas.style.display = hasHistory ? "block" : "none";
      if (chartFallback) chartFallback.style.display = hasHistory ? "none" : "grid";
      if (hasHistory) {
        this.#drawTreasuryLineChart(historyCanvas, {
          primary: treasury.chart.values,
          secondary: treasury.chart.projection,
          primaryColor: "#46ffd9",
          secondaryColor: "#ff58d0",
          fill: true,
          secondaryDashed: true,
          glow: true,
          showAxes: true
        });
      }
    }

    if (miniCanvas) {
      const combatPoints = Array.isArray(treasury?.combatOutlook?.points) ? treasury.combatOutlook.points : [];
      const statusClass = String(treasury?.combatOutlook?.cls ?? "good");
      const statusColor = statusClass === "bad" ? "#ff7f9b" : (statusClass === "warn" ? "#ffd77f" : "#59ffd5");
      const hasCombat = combatPoints.length > 1;
      miniCanvas.style.display = hasCombat ? "block" : "none";
      if (miniFallback) miniFallback.style.display = hasCombat ? "none" : "grid";
      if (hasCombat) {
        this.#drawTreasuryLineChart(miniCanvas, {
          primary: combatPoints,
          secondary: [],
          primaryColor: statusColor,
          fill: false,
          glow: true,
          showAxes: false
        });
      }
    }
  }

  #drawTreasuryLineChart(canvas, {
    primary = [],
    secondary = [],
    primaryColor = "#46ffd9",
    secondaryColor = "#ff58d0",
    fill = false,
    glow = false,
    secondaryDashed = false,
    showAxes = true
  } = {}) {
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const width = Math.max(10, Math.round(rect.width || canvas.clientWidth || 400));
    const height = Math.max(10, Math.round(rect.height || canvas.clientHeight || 200));
    const ratio = Math.max(1, window.devicePixelRatio || 1);

    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, width, height);

    const padding = showAxes ? { top: 14, right: 16, bottom: 24, left: 18 } : { top: 10, right: 10, bottom: 10, left: 10 };
    const chartWidth = Math.max(1, width - padding.left - padding.right);
    const chartHeight = Math.max(1, height - padding.top - padding.bottom);
    const allValues = [...primary, ...secondary].map(v => Number(v ?? 0));
    const min = Math.min(...allValues, 0);
    const max = Math.max(...allValues, 1);
    const range = Math.max(1, max - min);

    const toPoints = (values) => values.map((value, index) => {
      const x = padding.left + (values.length <= 1 ? chartWidth / 2 : (chartWidth * index) / (values.length - 1));
      const y = padding.top + chartHeight - (((Number(value ?? 0) - min) / range) * chartHeight);
      return { x, y };
    });

    const primaryPoints = toPoints(primary);
    const secondaryPoints = toPoints(secondary);

    ctx.save();
    ctx.strokeStyle = "rgba(255, 0, 200, 0.10)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 6; i += 1) {
      const y = padding.top + (chartHeight * i) / 6;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
    }
    if (showAxes) {
      for (let i = 0; i <= 8; i += 1) {
        const x = padding.left + (chartWidth * i) / 8;
        ctx.beginPath();
        ctx.moveTo(x, padding.top);
        ctx.lineTo(x, height - padding.bottom);
        ctx.stroke();
      }
    }
    ctx.restore();

    const drawSeries = (points, color, { dashed = false, areaFill = false } = {}) => {
      if (!points.length) return;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i += 1) {
        const prev = points[i - 1];
        const curr = points[i];
        const cx = (prev.x + curr.x) / 2;
        ctx.quadraticCurveTo(cx, prev.y, curr.x, curr.y);
      }
      if (areaFill) {
        ctx.lineTo(points[points.length - 1].x, padding.top + chartHeight);
        ctx.lineTo(points[0].x, padding.top + chartHeight);
        ctx.closePath();
        ctx.fillStyle = 'rgba(255,255,255,0.01)';
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i += 1) {
          const prev = points[i - 1];
          const curr = points[i];
          const cx = (prev.x + curr.x) / 2;
          ctx.quadraticCurveTo(cx, prev.y, curr.x, curr.y);
        }
      }
      ctx.strokeStyle = color;
      ctx.lineWidth = 2.4;
      ctx.setLineDash(dashed ? [8, 6] : []);
      if (glow) {
        ctx.shadowColor = color;
        ctx.shadowBlur = 12;
      }
      ctx.stroke();
      ctx.restore();
    };

    const withAlpha = (hex, alpha) => {
      if (!String(hex).startsWith("#")) return hex;
      const raw = hex.slice(1);
      const expanded = raw.length === 3 ? raw.split("").map(ch => ch + ch).join("") : raw;
      const r = Number.parseInt(expanded.slice(0, 2), 16);
      const g = Number.parseInt(expanded.slice(2, 4), 16);
      const b = Number.parseInt(expanded.slice(4, 6), 16);
      return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    };

    // redraw fill-capable function with alpha-aware colors
    if (secondaryPoints.length) drawSeries(secondaryPoints, secondaryColor, { dashed: secondaryDashed, areaFill: false });
    if (primaryPoints.length) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(primaryPoints[0].x, primaryPoints[0].y);
      for (let i = 1; i < primaryPoints.length; i += 1) {
        const prev = primaryPoints[i - 1];
        const curr = primaryPoints[i];
        const cx = (prev.x + curr.x) / 2;
        ctx.quadraticCurveTo(cx, prev.y, curr.x, curr.y);
      }
      if (fill) {
        ctx.lineTo(primaryPoints[primaryPoints.length - 1].x, padding.top + chartHeight);
        ctx.lineTo(primaryPoints[0].x, padding.top + chartHeight);
        ctx.closePath();
        const gradient = ctx.createLinearGradient(0, padding.top, 0, padding.top + chartHeight);
        gradient.addColorStop(0, withAlpha(primaryColor, 0.24));
        gradient.addColorStop(1, withAlpha(primaryColor, 0.02));
        ctx.fillStyle = gradient;
        ctx.fill();
      }
      ctx.restore();
      drawSeries(primaryPoints, primaryColor, { dashed: false, areaFill: false });
    }

    if (showAxes) {
      ctx.save();
      ctx.fillStyle = "rgba(143, 255, 224, 0.72)";
      ctx.font = "11px monospace";
      ctx.fillText(`${Math.round(max).toLocaleString()} SH`, padding.left, 10);
      ctx.fillText(`${Math.round(min).toLocaleString()} SH`, padding.left, height - 6);
      ctx.restore();
    }
  }

  async #setAsPrimaryTreasuryShip() {
    const actor = this.document;
    await ensureTreasuryState(actor);
    await setPrimaryTreasuryShip(actor);
    ui.notifications?.info(`${actor.name} is now the primary treasury ship.`);
    await this.#rememberActiveTab("treasury");
    return this.render(true);
  }

  async #transferTreasuryToSelectedShip() {
    const sourceActor = this.document;
    const controlled = Array.from(canvas?.tokens?.controlled ?? []);
    if (controlled.length !== 1) {
      ui.notifications?.warn("Select exactly one target vehicle token to receive the treasury.");
      return;
    }

    const targetActor = controlled[0]?.actor;
    if (!targetActor || targetActor.type !== "vehicle") {
      ui.notifications?.warn("The selected token must be a vehicle.");
      return;
    }

    if (String(targetActor.uuid) === String(sourceActor.uuid)) {
      ui.notifications?.warn("Select a different ship to receive the treasury.");
      return;
    }

    return new Promise(resolve => {
      new Dialog({
        title: "Transfer Treasury",
        content: `<p>Transfer the full treasury from <strong>${sourceActor.name}</strong> to <strong>${targetActor.name}</strong>?</p><p>The receiving ship will inherit the current balance, ledger, and treasury history. The current ship treasury will be cleared.</p>`,
        buttons: {
          transfer: {
            label: "Transfer",
            callback: async () => {
              await transferTreasuryToShip(sourceActor, targetActor, {
                clearSource: true,
                logTransfer: true,
                notes: `Transferred via ${sourceActor.name} treasury console.`
              });
              ui.notifications?.info(`Treasury transferred to ${targetActor.name}.`);
              await this.#rememberActiveTab("treasury");
              await this.render(true);
            }
          },
          cancel: {
            label: "Cancel"
          }
        },
        default: "transfer",
        close: () => resolve()
      }).render(true);
    });
  }

  async #rememberActiveTab(tab = null) {
    const activeTab = tab
      ?? this.element?.querySelector?.(".wh-tab.active")?.dataset?.tab
      ?? "battle";

    const sheetState = foundry.utils.deepClone(this.document.getFlag(MODULE_ID, "sheetState") ?? {});
    sheetState.activeTab = activeTab;
    await this.document.setFlag(MODULE_ID, "sheetState", sheetState);
  }

async #onAction(event) {
  event.preventDefault();

  const action = event.currentTarget.dataset.action;
  const actor = this.document;
  const sheetState = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "sheetState") ?? {});
  sheetState.combat ??= {};

  const getInputNumber = (selector, fallback = 0) => {
    const el = this.element?.querySelector?.(selector);
    if (!el) return Math.max(0, Number(fallback ?? 0));
    return Math.max(0, Number(el.value ?? fallback ?? 0));
  };

  sheetState.combat.spendAmount = getInputNumber('input[name="sheetState.combat.spendAmount"]', sheetState.combat.spendAmount ?? 0);
  sheetState.combat.restoreAmount = getInputNumber('input[name="sheetState.combat.restoreAmount"]', sheetState.combat.restoreAmount ?? 0);
  sheetState.combat.powerPoints = getInputNumber('input[name="sheetState.combat.powerPoints"]', sheetState.combat.powerPoints ?? 0);
  sheetState.combat.powerPointsMax = getInputNumber('input[name="sheetState.combat.powerPointsMax"]', sheetState.combat.powerPointsMax ?? 0);
  sheetState.combat.partyActions = getInputNumber('input[name="sheetState.combat.partyActions"]', sheetState.combat.partyActions ?? 0);
  const crewEntries = Array.isArray(sheetState?.crew?.entries) ? sheetState.crew.entries : [];
  const uniqueCrewKeys = new Set();
  for (const entry of crewEntries) {
    const actorId = String(entry?.actorId ?? "").trim();
    const actorUuid = String(entry?.actorUuid ?? "").trim();
    const nameKey = String(entry?.name ?? "").trim().toLowerCase();
    const key = actorId || actorUuid || (nameKey ? `name:${nameKey}` : `row:${entry?.id ?? uniqueCrewKeys.size}`);
    uniqueCrewKeys.add(key);
  }
  sheetState.combat.partyActionsMax = Math.max(0, uniqueCrewKeys.size * 5);
  sheetState.combat.partyActions = Math.max(0, Math.min(Number(sheetState.combat.partyActions ?? sheetState.combat.partyActionsMax), sheetState.combat.partyActionsMax));

  const saveAndRender = async () => {
    await actor.setFlag(MODULE_ID, "sheetState", sheetState);
    await this.#rememberActiveTab();
    return this.render(true);
  };

  switch (action) {
    case "battle-repair": {
      const selected = Array.from(this.element?.querySelectorAll?.('input[data-repair-scope="battle"]:checked') ?? []).map(el => el.dataset.repairId).filter(Boolean);
      if (!selected.length) {
        ui.notifications?.warn("Select at least one eligible component.");
        return;
      }

      const currentActions = Math.max(0, Number(sheetState.combat.partyActions ?? 0));
      if (currentActions < selected.length) {
        ui.notifications?.warn("Not enough party actions remaining.");
        return;
      }

      sheetState.combat.componentStates ??= {};
      const results = [];
      for (const itemId of selected) {
        const item = actor.items.get(itemId);
        if (!item) continue;

        const st = getComponentState(actor, item);
        if (!(st.state === "operational" && st.hpCurrent > 0 && st.hpCurrent < st.hpMax)) continue;

        const roll = await (new Roll("2d10+5")).evaluate({ async: true });
        const nextHp = Math.min(st.hpMax, st.hpCurrent + roll.total);

        const existingBattleState = foundry.utils.deepClone(sheetState.combat.componentStates[itemId] ?? {});
        sheetState.combat.componentStates[itemId] = {
          ...existingBattleState,
          hpCurrent: nextHp,
          hpMax: st.hpMax,
          ac: st.ac,
          onFire: st.onFire,
          state: "operational"
        };
        
        results.push(`${item.name}: +${roll.total} HP (${st.hpCurrent} → ${nextHp})`);
      }

      sheetState.combat.partyActions = Math.max(0, currentActions - results.length);
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);

      if (results.length) {
        await ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `<div class="cnc-activation-card"><h3>Battle Repairs</h3><ul>${results.map(r => `<li>${r}</li>`).join("")}</ul></div>`
        });
      }

      await this.#rememberActiveTab();
      return this.render(true);
    }

    case "treasury-add":
      return this.#openTreasuryAdjustDialog(1);

    case "treasury-subtract":
      return this.#openTreasuryAdjustDialog(-1);

    case "treasury-reset":
      return this.#resetTreasury();

    case "treasury-transfer":
      return this.#transferTreasuryToSelectedShip();

    case "treasury-set-primary":
      return this.#setAsPrimaryTreasuryShip();

    case "post-repair": {
      const selected = Array.from(this.element?.querySelectorAll?.('input[data-repair-scope="post"]:checked') ?? []).map(el => el.dataset.repairId).filter(Boolean);
      if (!selected.length) {
        ui.notifications?.warn("Select at least one repair target.");
        return;
      }

      sheetState.combat.componentStates ??= {};
      const results = [];

      for (const repairId of selected) {
        if (repairId === "__hull__") {
          const currentHull = Math.max(0, Number(actor.system?.attributes?.hp?.value ?? 0));
          const maxHull = Math.max(0, Number(actor.system?.attributes?.hp?.max ?? 0));
          if (currentHull < maxHull) {
            const nextHull = Math.min(maxHull, currentHull + 50);
            await actor.update({ "system.attributes.hp.value": nextHull });
            results.push(`Hull: +50 HP (${currentHull} → ${nextHull})`);
          }
          continue;
        }

        const item = actor.items.get(repairId);
        if (!item) continue;

        const st = getComponentState(actor, item);
        const eligible = ((st.state === "operational" && st.hpCurrent > 0 && st.hpCurrent < st.hpMax) || st.state === "disabled");
        if (!eligible || st.state === "destroyed") continue;

        const nextHp = Math.min(st.hpMax, st.hpCurrent + 50);
        const existingComponentState = foundry.utils.deepClone(sheetState.combat.componentStates[repairId] ?? {});
        sheetState.combat.componentStates[repairId] = {
          ...existingComponentState,
          hpCurrent: nextHp,
          hpMax: st.hpMax,
          ac: st.ac,
          onFire: st.onFire,
          state: nextHp > 0 ? "operational" : st.state
        };
        results.push(`${item.name}: +50 HP (${st.hpCurrent} → ${nextHp})`);
      }

      await actor.setFlag(MODULE_ID, "sheetState", sheetState);

      if (results.length) {
        await ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content: `<div class="cnc-activation-card"><h3>Post-Battle Repairs</h3><ul>${results.map(r => `<li>${r}</li>`).join("")}</ul></div>`
        });
      }

      await this.#rememberActiveTab();
      return this.render(true);
    }

    case "crew-open-actor": {
      const actorId = String(event.currentTarget.dataset.actorId ?? "");
      const crewActor = actorId ? game.actors?.get?.(actorId) : null;
      crewActor?.sheet?.render?.(true);
      return;
    }

    case "crew-remove-row": {
      const crewId = String(event.currentTarget.dataset.crewId ?? "");
      sheetState.crew ??= {};
      sheetState.crew.entries ??= [];
      sheetState.crew.entries = sheetState.crew.entries.filter(entry => String(entry?.id) !== crewId);
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);
      await this.#rememberActiveTab("crew");
      return this.render(true);
    }

    case "cargo-add-row": {
      sheetState.cargo ??= {};
      sheetState.cargo.entries ??= [];
      const nextId = `cargo-${Date.now()}`;
      sheetState.cargo.entries.push({
        id: nextId,
        name: "",
        qty: 0,
        weightEach: 0,
        weightUnit: "lbs",
        notes: ""
      });
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);
      await this.#rememberActiveTab();
      return this.render(true);
    }

    case "cargo-remove-row": {
      const cargoId = event.currentTarget.dataset.cargoId;
      sheetState.cargo ??= {};
      sheetState.cargo.entries ??= [];
      sheetState.cargo.entries = sheetState.cargo.entries.filter(entry => String(entry?.id) !== String(cargoId));
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);
      await this.#rememberActiveTab();
      return this.render(true);
    }

    case "end-turn": {
      const maxPower = Number(sheetState.combat.powerPointsMax ?? 0);
      const maxActions = Number(sheetState.combat.partyActionsMax ?? 0);
      sheetState.combat.powerPoints = maxPower;
      sheetState.combat.partyActions = maxActions;
      sheetState.combat.crossingTheT = false;
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);
      return this.render(true);
    }

    case "toggle-crossing-the-t":
      sheetState.combat.crossingTheT = !(sheetState.combat.crossingTheT === true);
      return saveAndRender();
    case "drift-plus":
      sheetState.combat.driftTokens = Math.min(3, Number(sheetState.combat.driftTokens ?? 0) + 1);
      return saveAndRender();

    case "drift-minus":
      sheetState.combat.driftTokens = Math.max(0, Number(sheetState.combat.driftTokens ?? 0) - 1);
      return saveAndRender();

    case "power-plus":
    case "power-restore-1": {
      const maxPower = Math.max(0, Number(sheetState.combat.powerPointsMax ?? 0));
      sheetState.combat.powerPoints = Math.min(maxPower, Number(sheetState.combat.powerPoints ?? 0) + 1);
      return saveAndRender();
    }

    case "power-minus":
    case "power-spend-1":
      sheetState.combat.powerPoints = Math.max(0, Number(sheetState.combat.powerPoints ?? 0) - 1);
      return saveAndRender();

    case "power-spend-custom":
      sheetState.combat.powerPoints = Math.max(0, Number(sheetState.combat.powerPoints ?? 0) - Number(sheetState.combat.spendAmount ?? 0));
      return saveAndRender();

    case "power-restore-custom": {
      const maxPower = Math.max(0, Number(sheetState.combat.powerPointsMax ?? 0));
      sheetState.combat.powerPoints = Math.min(maxPower, Number(sheetState.combat.powerPoints ?? 0) + Number(sheetState.combat.restoreAmount ?? 0));
      return saveAndRender();
    }

    case "party-actions-plus":
    case "party-actions-restore-1": {
      const maxActions = Math.max(0, Number(sheetState.combat.partyActionsMax ?? 0));
      const currentActions = Math.max(0, Number(sheetState.combat.partyActions ?? 0));
      sheetState.combat.partyActions = maxActions > 0 ? Math.min(maxActions, currentActions + 1) : (currentActions + 1);
      return saveAndRender();
    }

    case "party-actions-minus":
    case "party-actions-spend-1":
      sheetState.combat.partyActions = Math.max(0, Number(sheetState.combat.partyActions ?? 0) - 1);
      return saveAndRender();

    case "party-actions-refresh":
      sheetState.combat.partyActions = Math.max(0, Number(sheetState.combat.partyActionsMax ?? 0));
      return saveAndRender();

    case "power-refresh":
      sheetState.combat.powerPoints = Math.max(0, Number(sheetState.combat.powerPointsMax ?? 0));
      return saveAndRender();

    case "power-empty":
      sheetState.combat.powerPoints = 0;
      return saveAndRender();

    case "fire-plus":
      sheetState.combat.fires = Number(sheetState.combat.fires ?? 0) + 1;
      PENDING_FIRE_BURST.set(actor.id, Date.now());
      this.#triggerFireBurst(event.currentTarget?.closest?.(".wh-stat-box"));
      return saveAndRender();

    case "fire-minus":
      sheetState.combat.fires = Math.max(0, Number(sheetState.combat.fires ?? 0) - 1);
      PENDING_FIRE_BURST.set(actor.id, Date.now());
      this.#triggerFireBurst(event.currentTarget?.closest?.(".wh-stat-box"));
      return saveAndRender();

    case "apply-fire-damage": {
      const fires = Math.max(0, Number(sheetState.combat.fires ?? 0));
      if (fires <= 0) {
        ui.notifications?.warn("There are no active fires to resolve.");
        return;
      }
      const formula = `${fires}d10`;
      const roll = await (new Roll(formula)).evaluate({ async: true });
      const currentHull = Math.max(0, Number(actor.system?.attributes?.hp?.value ?? 0));
      const nextHull = Math.max(0, currentHull - Math.max(0, Number(roll.total ?? 0)));
      await actor.update({ "system.attributes.hp.value": nextHull });
      await ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `<div class="cnc-activation-card"><h3>Total Fire Damage</h3><p><strong>Formula:</strong> ${formula}</p><p><strong>Damage Applied:</strong> ${roll.total ?? 0}</p><p><strong>Hull:</strong> ${currentHull} → ${nextHull}</p></div>`,
        rolls: [roll]
      });
      await this.#rememberActiveTab();
      return this.render(true);
    }

    case "activate-item": {
      const itemId = event.currentTarget.dataset.itemId;
      const item = actor.items.get(itemId);
      if (!item) {
        ui.notifications?.warn("Could not find that installed component.");
        return;
      }

      const itemType = getResolvedComponentType(item);
      const powerCost = Math.max(0, Number(event.currentTarget.dataset.powerCost ?? 0));
      const currentPower = Math.max(0, Number(sheetState.combat.powerPoints ?? 0));
      const currentPartyActions = Math.max(0, Number(sheetState.combat.partyActions ?? 0));
      const loaded = itemType === "weapon" ? (getWeaponLoadedState(actor, item) !== false) : true;

      if (powerCost > currentPower) {
        ui.notifications?.warn(`Not enough power to use ${item.name}. Need ${powerCost}, have ${currentPower}.`);
        return;
      }

      if (currentPartyActions < 1) {
        ui.notifications?.warn(`Not enough party actions to use ${item.name}. Need 1, have ${currentPartyActions}.`);
        return;
      }

      if (itemType === "weapon" && !loaded) {
        ui.notifications?.warn(`${item.name} is unloaded and must be reloaded before firing.`);
        return;
      }

      const newPower = Math.max(0, currentPower - powerCost);
      const newActions = Math.max(0, currentPartyActions - 1);
      sheetState.combat.powerPoints = newPower;
      sheetState.combat.partyActions = newActions;
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);

      if (itemType === "weapon") {
        await this.#setWeaponLoadedState([item.id], false);
      }

      await this.#executeWeaponFire(item, event);

      ui.notifications?.info(`${item.name} used for ${powerCost} power and 1 party action.`);
      await this.#rememberActiveTab();
    return this.render(true);
    }

    case "fire-arc": {
      const arc = event.currentTarget.dataset.arc;
      const installedWeapons = Array.from(actor.items ?? []).filter(item =>
        getResolvedComponentType(item) === "weapon" &&
        item.getFlag?.(CNC_MODULE_ID, "installed") === true &&
        matchesArc(actor, item, arc) &&
        getWeaponLoadedState(actor, item) !== false
      );

      if (!installedWeapons.length) {
        ui.notifications?.warn(`No loaded installed ${arc} weapons to fire.`);
        return;
      }

      const totalCost = installedWeapons.reduce((sum, item) => sum + Math.max(0, Number(getResolvedPowerCost(item) ?? 0)), 0);
      const shots = installedWeapons.length;
      const currentPower = Math.max(0, Number(sheetState.combat.powerPoints ?? 0));
      const currentPartyActions = Math.max(0, Number(sheetState.combat.partyActions ?? 0));

      if (totalCost > currentPower) {
        ui.notifications?.warn(`Not enough power to fire the ${arc} arc. Need ${totalCost}, have ${currentPower}.`);
        return;
      }

      if (shots > currentPartyActions) {
        ui.notifications?.warn(`Not enough party actions to fire the ${arc} arc. Need ${shots}, have ${currentPartyActions}.`);
        return;
      }

      const newPower = Math.max(0, currentPower - totalCost);
      const newActions = Math.max(0, currentPartyActions - shots);
      sheetState.combat.powerPoints = newPower;
      sheetState.combat.partyActions = newActions;
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);

      if (installedWeapons.length) {
        await this.#setWeaponLoadedState(installedWeapons.map(item => item.id), false);
      }

      for (const weapon of installedWeapons) {
        await this.#executeWeaponFire(weapon, event);
      }

      ui.notifications?.info(`${actor.name} fired the ${arc} arc for ${totalCost} power and ${shots} party actions.`);
      await this.#rememberActiveTab();
    return this.render(true);
    }

    case "reload-weapon": {
      const itemId = event.currentTarget.dataset.itemId;
      const item = actor.items.get(itemId);
      if (!item) {
        ui.notifications?.warn("Could not find that installed weapon.");
        return;
      }

      if (getResolvedComponentType(item) !== "weapon") {
        ui.notifications?.warn(`${item.name} is not a weapon.`);
        return;
      }

      const loaded = getWeaponLoadedState(actor, item) !== false;
      if (loaded) {
        ui.notifications?.warn(`${item.name} is already loaded.`);
        return;
      }

      const currentPartyActions = Math.max(0, Number(sheetState.combat.partyActions ?? 0));
      if (currentPartyActions < 1) {
        ui.notifications?.warn(`Not enough party actions to reload ${item.name}. Need 1, have ${currentPartyActions}.`);
        return;
      }

      const newActions = Math.max(0, currentPartyActions - 1);
      sheetState.combat.partyActions = newActions;
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);
      await this.#setWeaponLoadedState([item.id], true);

      ui.notifications?.info(`${item.name} reloaded for 1 party action.`);
      await this.#rememberActiveTab();
    return this.render(true);
    }

    case "reload-arc": {
      const arc = event.currentTarget.dataset.arc;
      const unloadedWeapons = Array.from(actor.items ?? []).filter(item =>
        getResolvedComponentType(item) === "weapon" &&
        item.getFlag?.(CNC_MODULE_ID, "installed") === true &&
        matchesArc(actor, item, arc) &&
        getWeaponLoadedState(actor, item) === false
      );

      if (!unloadedWeapons.length) {
        ui.notifications?.warn(`No unloaded installed ${arc} weapons to reload.`);
        return;
      }

      const cost = unloadedWeapons.length;
      const currentPartyActions = Math.max(0, Number(sheetState.combat.partyActions ?? 0));
      if (cost > currentPartyActions) {
        ui.notifications?.warn(`Not enough party actions to reload the ${arc} arc. Need ${cost}, have ${currentPartyActions}.`);
        return;
      }

      const newActions = Math.max(0, currentPartyActions - cost);
      sheetState.combat.partyActions = newActions;
      await actor.setFlag(MODULE_ID, "sheetState", sheetState);

      if (unloadedWeapons.length) {
        await this.#setWeaponLoadedState(unloadedWeapons.map(item => item.id), true);
      }

      ui.notifications?.info(`${actor.name} reloaded the ${arc} arc for ${cost} party actions.`);
      await this.#rememberActiveTab();
    return this.render(true);
    }


    case "print-item-card": {
      const itemId = event.currentTarget.dataset.itemId;
      const item = actor.items.get(itemId);
      if (!item) return;
      await this.#postItemDescriptionToChat(item);
      return;
    }

    case "uninstall-item": {
      const itemId = event.currentTarget.dataset.itemId;
      const item = actor.items.get(itemId);
      if (!item) return;
      await markItemInstalled(actor, item, false);

      const sheetState = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "sheetState") ?? {});
      if (sheetState?.battleArcAssignments?.[itemId] != null) {
        delete sheetState.battleArcAssignments[itemId];
        await actor.setFlag(MODULE_ID, "sheetState", sheetState);
      }

      ui.notifications?.info(`${item.name} removed from installed ${getResolvedComponentType(item) ?? "component"} list.`);
      await this.#rememberActiveTab();
    return this.render(true);
    }

    default:
      return;
  }
}

  async #setWeaponLoadedState(itemIds, loaded) {
    const ids = Array.from(new Set((itemIds ?? []).filter(Boolean)));
    if (!ids.length) return;
    const states = foundry.utils.deepClone(getWeaponLoadStates(this.document) ?? {});
    for (const id of ids) states[id] = loaded === true;
    await this.document.setFlag(MODULE_ID, "weaponLoadStates", states);
  }

  async #postCrossingTheTResult(item, { attackRoll, damageRoll, attackModifier = 0, critical = false } = {}) {
    const damageType = getDamageTypeLabel(item);
    const speaker = ChatMessage.getSpeaker({ actor: this.document });
    const critBadge = critical ? '<div class="cnc-activation-card__tag">Critical Hit</div>' : '';
    const arcText = escapeHtml(getResolvedArc(item) || '—');
    const content = `
      <div class="cnc-activation-card cnc-crossing-card">
        <h3>${escapeHtml(item.name)} — Crossing the T</h3>
        ${critBadge}
        <p><strong>Ship:</strong> ${escapeHtml(this.document.name)}</p>
        <p><strong>Arc:</strong> ${arcText}</p>
        <p><strong>Attack:</strong> Advantage (${escapeHtml(attackRoll.formula)}) + ${attackModifier} = <strong>${attackRoll.total}</strong></p>
        <p><strong>Damage:</strong> ${escapeHtml(damageRoll.formula)} ${damageType ? `(${escapeHtml(damageType)})` : ""} = <strong>${damageRoll.total}</strong></p>
        <p><em>Crossing the T: advantage on the attack and +1 die to the primary damage component.</em></p>
      </div>
    `;
    await ChatMessage.create({ speaker, content });
  }

  async #rollWeaponWithCrossingTheT(item) {
    if (!item) return false;
    const attackModifier = getWeaponAttackModifier(this.document, item);
    const attackRoll = await (new Roll(`2d20kh + ${attackModifier}`)).evaluate({ async: true });
    const dieResults = attackRoll.terms?.[0]?.results ?? [];
    const kept = dieResults.find(r => r?.active) ?? dieResults[0] ?? null;
    const keptTotal = Number(kept?.result ?? 0);
    const critical = keptTotal === 20;
    const damageFormula = getPrimaryDamageFormula(item, 1, critical);
    if (!damageFormula) {
      ui.notifications?.warn(`Could not determine a damage formula for ${item.name}.`);
      return false;
    }
    const damageRoll = await (new Roll(damageFormula)).evaluate({ async: true });
    await this.#postCrossingTheTResult(item, { attackRoll, damageRoll, attackModifier, critical });
    return true;
  }

  async #executeWeaponFire(item, event = null) {
    const currentSheetState = getSheetState(this.document);
    const crossing = currentSheetState?.combat?.crossingTheT === true;
    if (crossing) return this.#rollWeaponWithCrossingTheT(item);
    return this.#rollItemWithDialog(item, event);
  }

  async #rollItemWithDialog(item, event = null) {
    if (!item) return false;

    try {
      const itemAny = item;
      if (typeof itemAny.use === "function") {
        await itemAny.use({ event, configureDialog: true });
        return true;
      }

      const activities = Array.from(itemAny.activities ?? itemAny.system?.activities ?? []);
      const activity = activities[0];
      if (activity && typeof activity.use === "function") {
        await activity.use({ event, configureDialog: true });
        return true;
      }
    } catch (err) {
      console.warn("cannons-and-chaos | Failed to roll item with Foundry dialog", err);
    }

    ui.notifications?.warn(`Could not open the standard Foundry roll dialog for ${item.name}.`);
    return false;
  }

  async #postItemDescriptionToChat(item) {
    if (!item) return;
    const componentType = getResolvedComponentType(item) ?? "component";
    const descriptionHtml = item.system?.description?.value
      ?? item.system?.description
      ?? item.system?.details?.description
      ?? `<p>No description available.</p>`;
    const speaker = ChatMessage.getSpeaker({ actor: this.document });
    const content = `
      <div class="cnc-activation-card cnc-component-card">
        <h3>${item.name}</h3>
        <p><strong>Ship:</strong> ${this.document.name}</p>
        <p><strong>Type:</strong> ${componentType.charAt(0).toUpperCase() + componentType.slice(1)}</p>
        <div class="cnc-component-card__body">${descriptionHtml || `<p>No description available.</p>`}</div>
      </div>
    `;
    await ChatMessage.create({ speaker, content });
  }

  async _onDrop(event) {
    const data = TextEditor.getDragEventData(event);
    if (!data) return super._onDrop(event);

    const cargoDropTarget = event.target.closest("[data-cargo-drop]");
    if (cargoDropTarget) {
      if (data.type !== "Item") {
        ui.notifications?.warn("Only items can be dropped into cargo.");
        return;
      }
      const imported = await this.#addCargoEntryFromDropData(data);
      if (imported) return;
      return;
    }

    const crewDropTarget = event.target.closest("[data-crew-drop]");
    if (crewDropTarget) {
      if (data.type !== "Actor") {
        ui.notifications?.warn("Only character or NPC actor sheets can be dropped into Crew.");
        return;
      }
      const added = await this.#addCrewEntryFromDropData(data);
      if (added) return;
      return;
    }

    const dropTarget = event.target.closest("[data-slot-drop]");
    if (!dropTarget) return super._onDrop(event);

    const slot = dropTarget.dataset.slotDrop;
    const targetArc = dropTarget.dataset.arc || null;
    if (!slot) return super._onDrop(event);

    if (data.type !== "Item") {
      ui.notifications?.warn("Only items can be dropped onto ship component slots.");
      return;
    }

    let owned = await this.#resolveDroppedItem(data);
    if (!owned) {
      ui.notifications?.warn("Could not resolve the dropped item for this ship.");
      return;
    }

    owned = await ensureItemHasEmbeddedFlags(this.document, owned);

    const result = validateItemForSlot(this.document, owned, slot);
    if (!result.ok) {
      ui.notifications?.warn(result.reason);
      return;
    }

    if (slot === "weapon" && targetArc) {
      await owned.update({
        [`flags.${CNC_MODULE_ID}.arc`]: targetArc,
        [`flags.${CNC_MODULE_ID}.installed`]: true
      });
      owned = this.document.items.get(owned.id) ?? owned;
    }

    await markItemInstalled(this.document, owned, true);

    const existingFlags = foundry.utils.deepClone(owned.getFlag?.(CNC_MODULE_ID, "") ?? {});
    await this.document.updateEmbeddedDocuments("Item", [{
      _id: owned.id,
      flags: {
        [CNC_MODULE_ID]: {
          ...existingFlags,
          installed: true,
          arc: slot === "weapon" && targetArc ? targetArc : (existingFlags.arc ?? null)
        }
      }
    }]);
    owned = this.document.items.get(owned.id) ?? owned;

    if (slot === "weapon" && targetArc) {
      const hull = foundry.utils.deepClone(this.document.getFlag(CNC_MODULE_ID, "hullData") ?? {});
      hull.installed ??= {};
      hull.installed.weapons ??= [];
      hull.installed.weapons = (hull.installed.weapons ?? []).filter(w => w?.id !== owned.id);
      hull.installed.weapons.push({
        id: owned.id,
        name: owned.name,
        componentType: "weapon",
        tier: Number(owned.getFlag(CNC_MODULE_ID, "tier") ?? null),
        mountIndex: null,
        arc: targetArc,
        powerCost: Number(owned.getFlag(CNC_MODULE_ID, "powerCost") ?? null)
      });
      await this.document.setFlag(CNC_MODULE_ID, "hullData", hull);

      const sheetState = foundry.utils.deepClone(this.document.getFlag(MODULE_ID, "sheetState") ?? {});
      sheetState.battleArcAssignments ??= {};
      sheetState.battleArcAssignments[owned.id] = targetArc;
      await this.document.setFlag(MODULE_ID, "sheetState", sheetState);
    }

    ui.notifications?.info(`${owned.name} installed as ${slot}${slot === "weapon" && targetArc ? ` (${targetArc})` : ""}.`);
    await this.#rememberActiveTab();
    return this.render(true);
  }

  async #resolveDroppedItem(data) {
    let dropped = null;

    try {
      dropped = await Item.implementation.fromDropData(data);
    } catch (err) {
      console.error("cannons-and-chaos | Failed to read drop data", err);
    }

    if (dropped?.parent?.id === this.document.id) return dropped;

    if (data.uuid) {
      try {
        const uuidDoc = await fromUuid(data.uuid);
        if (uuidDoc?.documentName === "Item") {
          if (uuidDoc?.parent?.id === this.document.id) return uuidDoc;
          dropped = uuidDoc;
        }
      } catch (err) {
        console.warn("cannons-and-chaos | Could not resolve dropped UUID", err);
      }
    }

    const candidateIds = [data._id, data.id, data.data?._id].filter(Boolean);
    for (const id of candidateIds) {
      const existing = this.document.items.get(id);
      if (existing) return existing;
    }

    if (!dropped) return null;

    const sourceData = dropped.toObject();
    sourceData.flags ??= {};

    const sourceCncFlags = foundry.utils.deepClone(
      dropped.getFlag?.(CNC_MODULE_ID, "") ?? sourceData.flags[CNC_MODULE_ID] ?? {}
    );

    sourceData.flags[CNC_MODULE_ID] = foundry.utils.mergeObject(
      buildCncFlagsForItem(dropped, { installed: false }),
      sourceCncFlags,
      { inplace: false }
    );

    const created = await this.document.createEmbeddedDocuments("Item", [sourceData]);
    return created?.[0] ?? null;
  }


  async #resolveDroppedActor(data) {
    let dropped = null;

    try {
      dropped = await Actor.implementation.fromDropData(data);
    } catch (err) {
      console.warn("cannons-and-chaos | Failed to resolve crew drop actor", err);
    }

    if (!dropped && data.uuid) {
      try {
        const uuidDoc = await fromUuid(data.uuid);
        if (uuidDoc?.documentName === "Actor") dropped = uuidDoc;
      } catch (err) {
        console.warn("cannons-and-chaos | Could not resolve dropped actor UUID", err);
      }
    }

    if (!dropped) return null;
    if (!["character", "npc"].includes(String(dropped.type ?? ""))) return null;
    return dropped;
  }

  async #addCrewEntryFromDropData(data) {
    const dropped = await this.#resolveDroppedActor(data);
    if (!dropped) {
      ui.notifications?.warn("Only PC or NPC actor sheets can be assigned to Crew.");
      return false;
    }

    const sheetState = foundry.utils.deepClone(this.document.getFlag(MODULE_ID, "sheetState") ?? {});
    sheetState.crew ??= {};
    sheetState.crew.entries ??= [];

    const exists = sheetState.crew.entries.some(entry =>
      String(entry?.actorUuid ?? "") === String(dropped.uuid ?? "") ||
      (String(entry?.actorId ?? "") && String(entry?.actorId ?? "") === String(dropped.id ?? ""))
    );

    if (exists) {
      ui.notifications?.info(`${dropped.name} is already assigned to this ship's crew.`);
      await this.#rememberActiveTab("crew");
      await this.render(true);
      return true;
    }

    sheetState.crew.entries.push({
      id: `crew-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      actorId: String(dropped.id ?? ""),
      actorUuid: String(dropped.uuid ?? ""),
      actorType: String(dropped.type ?? ""),
      name: String(dropped.name ?? "Crew Member"),
      img: String(dropped.img ?? "icons/svg/mystery-man.svg"),
      role: ""
    });

    await this.document.setFlag(MODULE_ID, "sheetState", sheetState);
    ui.notifications?.info(`${dropped.name} assigned to crew.`);
    await this.#rememberActiveTab("crew");
    await this.render(true);
    return true;
  }

  async #onCrewFieldChange(event) {
    event.preventDefault?.();
    event.stopPropagation?.();
    event.stopImmediatePropagation?.();

    const target = event.currentTarget;
    const crewId = String(target.dataset.crewId ?? "");
    const field = String(target.dataset.crewField ?? "");
    if (!crewId || !field) return;

    const actor = this.document;
    const sheetState = foundry.utils.deepClone(actor.getFlag(MODULE_ID, "sheetState") ?? {});
    sheetState.crew ??= {};
    sheetState.crew.entries ??= [];

    const idx = sheetState.crew.entries.findIndex(entry => String(entry?.id) === crewId);
    if (idx === -1) return;

    const entry = foundry.utils.deepClone(sheetState.crew.entries[idx] ?? {});
    if (field === "role") {
      entry.role = String(target.value ?? "");
    }

    sheetState.crew.entries[idx] = entry;
    await actor.setFlag(MODULE_ID, "sheetState", sheetState);
    await this.#rememberActiveTab("crew");
    return this.render(true);
  }

  async _processFormData(event, form, formData) {
    const expanded = foundry.utils.expandObject(formData.object);
    const updates = {};

    if (expanded.name !== undefined) updates.name = expanded.name;
    if (expanded.img !== undefined) updates.img = expanded.img;

    if (Object.keys(updates).length) {
      await this.document.update(updates);
    }

    const existingSheetState = foundry.utils.deepClone(this.document.getFlag(MODULE_ID, "sheetState") ?? {});
    const mergedSheetState = foundry.utils.mergeObject(existingSheetState, expanded.sheetState ?? {}, { inplace: false });
    await this.document.setFlag(MODULE_ID, "sheetState", mergedSheetState);
  }
}
