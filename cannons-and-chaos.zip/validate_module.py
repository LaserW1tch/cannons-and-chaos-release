#!/usr/bin/env python3
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODULE_JSON = ROOT / "module.json"

ERRORS = []
WARNINGS = []

ABSOLUTE_PATTERNS = [
    re.compile(r"[A-Za-z]:\\"),
    re.compile(r"/mnt/[a-z]/", re.IGNORECASE),
    re.compile(r"%APPDATA%", re.IGNORECASE),
    re.compile(r"%LOCALAPPDATA%", re.IGNORECASE),
]

VALID_EXTENSIONS = (
    ".js", ".json", ".css", ".hbs",
    ".png", ".jpg", ".jpeg", ".webp", ".svg"
)


def fail(msg):
    ERRORS.append(msg)


def warn(msg):
    WARNINGS.append(msg)


def check_module_json():
    if not MODULE_JSON.exists():
        fail("module.json missing")
        return

    try:
        data = json.loads(MODULE_JSON.read_text(encoding="utf-8"))
    except Exception as e:
        fail(f"module.json invalid JSON: {e}")
        return

    required = ["id", "title", "version"]
    for key in required:
        if key not in data:
            fail(f"module.json missing key: {key}")

    if "version" in data:
        if not re.fullmatch(r"\d+\.\d+\.\d+", str(data["version"])):
            fail(f"Invalid version format: {data['version']}")


def check_absolute_paths():
    for root, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in (".git", ".tmp", "releases", "node_modules")]

        for f in files:
            path = Path(root) / f
            if path.suffix.lower() not in VALID_EXTENSIONS:
                continue

            try:
                text = path.read_text(encoding="utf-8")
            except Exception:
                continue

            for pat in ABSOLUTE_PATTERNS:
                if pat.search(text):
                    fail(f"Absolute path found in {path.relative_to(ROOT)}")


def check_missing_files():
    pattern = re.compile(r'["\']([^"\']+\.(js|css|hbs|json))["\']')

    for root, dirs, files in os.walk(ROOT):
        # Do not descend into build/junk directories
        dirs[:] = [d for d in dirs if d not in (".tmp", ".git", "node_modules", "releases")]

        for f in files:
            path = Path(root) / f

            if path.suffix.lower() not in (".js", ".json", ".css", ".hbs"):
                continue

            try:
                text = path.read_text(encoding="utf-8")
            except Exception:
                continue

            for match in pattern.findall(text):
                ref = match[0].replace("\\", "/")

                # Ignore runtime/system/external paths
                if ref.startswith(("http", "icons/", "systems/", "modules/")):
                    continue

                # Ignore bare filenames like "ballista-t1.json" used as data identifiers
                if "/" not in ref:
                    continue

                full = (path.parent / ref).resolve()

                if not full.exists():
                    fail(f"Missing file: {ref} referenced in {path.relative_to(ROOT)}")


def check_case_sensitivity():
    seen = {}

    for root, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in (".git", ".tmp", "releases", "node_modules")]

        for f in files:
            rel = str((Path(root) / f).relative_to(ROOT))
            low = rel.lower()

            if low in seen and seen[low] != rel:
                fail(f"Case collision: {seen[low]} vs {rel}")
            else:
                seen[low] = rel


def main():
    check_module_json()
    check_absolute_paths()
    check_missing_files()
    check_case_sensitivity()

    if WARNINGS:
        print("WARNINGS:")
        for w in WARNINGS:
            print(" -", w)

    if ERRORS:
        print("ERRORS:")
        for e in ERRORS:
            print(" -", e)
        sys.exit(1)

    print("Validation passed.")


if __name__ == "__main__":
    main()